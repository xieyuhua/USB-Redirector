/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IlllIllII
#define IlllIllII
struct llllll;typedef void(*urb_chain_complete_t)(struct llllll*);struct llllll{
spinlock_t lock;struct usb_device*IlIlII;int pipe;int IlIllIl;int IlIlIllI;int 
status;size_t llllllIll;atomic_t IlIlIlII;void*context;urb_chain_complete_t 
complete;size_t IlIII;
struct urb*IIIlII[(0x178b+664-0x1a23)];};struct IIIlI{void*transfer_buffer;
size_t transfer_buffer_length;
size_t actual_length;
unsigned int number_of_packets;
};struct IIlIIll{size_t IlIII;
struct IIIlI IllIIl[(0x36d+5763-0x19f0)];};struct llllll*IlIlIlIlI(int pipe,int 
interval,int IlIlIllI,int IlIllIl,struct usb_device*IlIlII,struct IIlIIll*llIllI
,void*context,urb_chain_complete_t complete,gfp_t lIIIl);void llIllIlll(struct 
llllll*llIlI);int lIIllIIII(struct llllll*llIlI);int llllllIII(struct llllll*
llIlI);int llllIlIll(struct llllll*llIlI);int lIlIllIll(struct llllll*llIlI);int
 lllIlIIIl(struct llllll*llIlI);int llIIllllI(struct llllll*llIlI,struct urb*
IlllI);struct IIlIIll*IIIllIlIl(size_t length,int llllIIlI);struct IIlIIll*
lIIIIlIll(size_t length,IllllIlI*lIIIIIll,IIIIl IllIllIIl);size_t IIIlllIIl(
struct IIlIIll*llIlI,const void*IIIlI,size_t length);size_t lIlIlIlII(struct 
IIlIIll*llIlI,void*IIIlI,size_t length);void IllIllllI(struct IIlIIll*llIlI);
size_t lIlIlllIIl(struct IIlIIll*llIlI,IllllIlI*lIIIIIll,IIIIl IllIllIIl);size_t
 lIllIIIIIl(struct IIlIIll*llIlI,IllllIlI*lIIIIIll,IIIIl IllIllIIl);
#endif 

