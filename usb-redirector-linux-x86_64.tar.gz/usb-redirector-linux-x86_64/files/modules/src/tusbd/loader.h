/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef lllIIlIll
#define lllIIlIll
#ifdef _USBD_ENABLE_STUB_

struct lIIIIIlI{struct list_head entry;struct IllIllll lIIll;};int IllllIll(
struct usb_device*llIII);void IllIIIIIl(struct list_head*lIlllIII);void llIllIlI
(void);
struct IllIIIll{struct list_head entry;struct lIllIIII IIIIllI;};IIIIl lIlllIlIl
(struct usb_device*llIII);void IllIllIlI(struct list_head*IlllIIII);void 
IlIlIIllI(void);
struct IlIlIIIl{struct list_head entry;struct usb_device*llIII;const char*serial
;const char*lllllI;const char*llIIllI;};int IIllIIll(struct usb_device*lIIlI,
const char**IIlIlllII,const char**IllllIIII,const char**IIIlIIlll);void 
IIIlIIllI(struct usb_device*llIII);void IIlIIIllI(void);int IIlIlllIl(struct 
usb_interface*IIIIII);int lIIlllIl(struct usb_device*llIII);void lIIllllI(struct
 usb_device*llIII,int IIIIIlII);struct usb_device*lllllIII(const char*lllllI);
#endif 
#endif 

