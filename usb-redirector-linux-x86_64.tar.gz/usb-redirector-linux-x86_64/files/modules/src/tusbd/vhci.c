/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifdef _USBD_ENABLE_VHCI_
#include "usbd.h"
#include <linux/platform_device.h>
#include <linux/dma-mapping.h>
#include <linux/kernel.h>
#include <linux/highmem.h>
#include <asm/page.h>
#include <asm/unaligned.h>
struct IIIlll*IllIllIl=NULL;struct usb_hcd*IlllllI=NULL;
#if KERNEL_GT_EQ((0xa62+459-0xc2b),(0xac7+4576-0x1ca1),(0x3b4+6607-0x1d5c)) || \
RHEL_RELEASE_GT_EQ((0x147b+4109-0x2482),(0x176+1162-0x5fd)) 
struct usb_hcd*lIIIIII=NULL;
#define IlIllII(lIIllI) (((lIIllI)->speed == HCD_USB3) ? "\x75\x73\x62\x33" : \
"\x75\x73\x62\x32")
#else
#define IlIllII(lIIllI) "\x55\x53\x42\x32"
#endif
#if defined(CONFIG_X86_32) && !defined(_USBD_VHCI_NO_DMA_)
int lIIlIlIl=(0x147c+1567-0x1a9b);
#endif
#ifdef _USBD_DEBUG_MEMORY_
extern atomic_t lllllllll;extern atomic_t lIllIIlIl;extern atomic_t llIlIIllI;
extern atomic_t IllIlIIl;extern atomic_t IIlIIIIII;
#endif 


static int IlIlIIIII(struct platform_device*);static int IIllIIllI(struct 
platform_device*);static void lllIlIIll(struct device*dev);static int IIlIIlIll(
struct usb_hcd*IllIl);static int lIIllIIll(struct usb_hcd*IllIl);static void 
IllIlllII(struct usb_hcd*IllIl);static int llllIIlll(struct usb_hcd*IllIl);
#if KERNEL_LT((0x727+4145-0x1756),(0xd67+4779-0x200c),(0x152+8978-0x244c))
static int lIllIlII(struct usb_hcd*IllIl,struct urb*urb);static int lIIIIllI(
struct usb_hcd*IllIl,struct usb_host_endpoint*ep,struct urb*urb,gfp_t lIIIl);
#else
static int lIllIlII(struct usb_hcd*IllIl,struct urb*urb,int status);static int 
lIIIIllI(struct usb_hcd*IllIl,struct urb*urb,gfp_t lIIIl);
#endif
static void IlIIIlIlI(struct usb_hcd*IllIl,struct usb_host_endpoint*ep);static 
int IIlllIIlI(struct usb_hcd*IllIl,u16 IIlIlIIll,u16 wValue,u16 wIndex,char*
IIIlI,u16 wLength);static int IIIllIlII(struct usb_hcd*IllIl,char*IIIlI);static 
int IIIlllIlI(struct usb_hcd*IllIl);static int IIlIlIlII(struct usb_hcd*IllIl);
#if KERNEL_GT_EQ((0x1a44+1319-0x1f69),(0x243+3588-0x1041),(0xb96+861-0xecc)) || \
RHEL_RELEASE_GT_EQ((0x1d2c+2012-0x2502),(0xf3c+1664-0x15b9)) 
static int IIllIlllI(struct usb_hcd*IllIl,struct usb_device*llIII,struct 
usb_host_endpoint**IlllllIIl,unsigned int lllllIlII,unsigned int IlIlllIlIl,
gfp_t lIIIl);static int IlIlIIIIl(struct usb_hcd*IllIl,struct usb_device*llIII,
struct usb_host_endpoint**IlllllIIl,unsigned int lllllIlII,gfp_t lIIIl);
#endif
static int llllIllII(struct lIIIII*llllI,int lIllI,int IllIllI,int lIlIIIl);
static int llIlIlIIl(struct lIIIII*llllI,int lIllI,int IllIllI);static void 
lIlIIll(struct lIIIII*llllI,int lIllI,int IIIlIIll);static void IlIIllI(struct 
lIIIII*llllI,int lIllI,int llllII,int lIlIIIl);
#if KERNEL_GT_EQ((0x74c+3923-0x169d),(0x139+8183-0x212a),(0x7b1+1109-0xbdf)) || \
RHEL_RELEASE_GT_EQ((0x1080+1592-0x16b2),(0x1260+158-0x12fb)) 
static int IIllllIlI(struct lIIIII*llllI,int lIllI,int IllIllI,int lIlIIIl);
static int IIIIlIlll(struct lIIIII*llllI,int lIllI,int IllIllI);static void 
llllllI(struct lIIIII*llllI,int lIllI,int llllII,int lIlIIIl);static void 
IlllIII(struct lIIIII*llllI,int lIllI,int IIIlIIll);static void lIlIlIl(struct 
lIIIII*llllI,int lIllI,int lIIIllIll);
#endif
#define IIIlllI(IllIl) ((struct lIIIII*)(IllIl->hcd_priv))
static struct platform_driver llIlIlIlI={.probe=IlIlIIIII,.remove=IIllIIllI,.
driver={.name=llIllIl,.owner=THIS_MODULE,},};static struct platform_device 
IlIlIIlII={.name=llIllIl,.id=-(0x45d+4296-0x1524),.dev={
.release=lllIlIIll,},};static struct hc_driver IIllllllI={.description=llIllIl,.
product_desc=
"\x56\x69\x72\x74\x75\x61\x6c\x20\x55\x53\x42\x20\x48\x6f\x73\x74\x20\x43\x6f\x6e\x74\x72\x6f\x6c\x6c\x65\x72"
,.hcd_priv_size=sizeof(struct lIIIII),
#if KERNEL_GT_EQ((0x5aa+4134-0x15ce),(0x19c3+2470-0x2363),(0x17ba+3896-0x26cb)) \
|| RHEL_RELEASE_GT_EQ((0xa0d+1165-0xe94),(0xfc2+3062-0x1bb5)) 
.flags=HCD_USB3|HCD_SHARED,
#else
.flags=HCD_USB2,
#endif
.reset=IIlIIlIll,.start=lIIllIIll,.stop=IllIlllII,.urb_enqueue=lIIIIllI,.
urb_dequeue=lIllIlII,.endpoint_disable=IlIIIlIlI,.get_frame_number=llllIIlll,.
hub_status_data=IIIllIlII,.hub_control=IIlllIIlI,.bus_suspend=IIIlllIlI,.
bus_resume=IIlIlIlII,
#if KERNEL_GT_EQ((0x111c+3812-0x1ffe),(0x891+6720-0x22cb),(0xa36+2642-0x1461)) \
|| RHEL_RELEASE_GT_EQ((0xf37+2074-0x174b),(0x17b5+1279-0x1cb1)) 
.alloc_streams=IIllIlllI,.free_streams=IlIlIIIIl,
#endif
};static struct list_head IlllIll;static spinlock_t lllIIl;
#if defined(CONFIG_X86_32) && !defined(_USBD_VHCI_NO_DMA_)
#  if KERNEL_LT((0xdaa+4539-0x1f63),(0x342+5368-0x1834),(0xef8+216-0xfb8))
static u64 IllIIllll=DMA_32BIT_MASK;
#  else
static u64 IllIIllll=DMA_BIT_MASK((0x639+853-0x96e));
#  endif
#endif
static int IlIlIIIII(struct platform_device*IlIlII){struct lIIIII*llllI;int 
IIIll=(0x191+6606-0x1b5f);int i;Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x64\x72\x69\x76\x65\x72\x5f\x70\x72\x6f\x62\x65\x3a\x20\x2b\x2b" "\n"
);do
{
#if defined(CONFIG_X86_32) && !defined(_USBD_VHCI_NO_DMA_)
if(lIIlIlIl){IlIlII->dev.dma_mask=&IllIIllll;}
#endif

IlllllI=usb_create_hcd(&IIllllllI,&IlIlII->dev,llIIIl(&IlIlII->dev));if(IlllllI
==NULL){IIIll=-ENOMEM;break;}
#if KERNEL_GT_EQ((0xbca+861-0xf25),(0x770+2831-0x1279),(0x1e1f+2150-0x266b))
IlllllI->has_tt=(0x73a+7373-0x2406);
#endif
llllI=IIIlllI(IlllllI);memset(llllI,(0x6bb+1784-0xdb3),sizeof(*llllI));llllI->
IllIl=IlllllI;spin_lock_init(&llllI->lock);for(i=(0x8a3+2737-0x1354);i<lIllIll;i
++){IlIIllI(llllI,i,IIlIIllI,(0x71f+2935-0x1296));}IIIll=usb_add_hcd(IlllllI,
(0xe8d+2885-0x19d2),(0x483+7325-0x2120));if(IIIll!=(0x14b9+1635-0x1b1c)){break;}
#if (KERNEL_GT_EQ((0x1ef0+905-0x2276),(0xf1+3558-0xed7),(0x9b7+5999-0x2126)) && \
KERNEL_LT_EQ((0x850+6712-0x2285),(0x1f72+1460-0x2523),(0xa9a+6810-0x2534))) || (\
RHEL_RELEASE_GT_EQ((0x9c1+4731-0x1c36),(0x1e9+7870-0x20a4)) && RHEL_RELEASE_LT(\
(0x164b+2219-0x1eef),(0x1233+3628-0x205f)))



if(IlllllI->irq==(0x2224+968-0x25ec)){IlllllI->irq=-(0x16a6+1844-0x1dd9);}
#endif
#if KERNEL_GT_EQ((0x151f+117-0x1592),(0xb96+5921-0x22b1),(0x258+2625-0xc72)) || \
RHEL_RELEASE_GT_EQ((0xf0d+5367-0x23fe),(0xdb5+209-0xe83)) 

lIIIIII=usb_create_shared_hcd(&IIllllllI,&IlIlII->dev,llIIIl(&IlIlII->dev),
IlllllI);if(lIIIIII==NULL){IIIll=-ENOMEM;break;}llllI=IIIlllI(lIIIIII);memset(
llllI,(0x3bd+3396-0x1101),sizeof(*llllI));llllI->IllIl=lIIIIII;spin_lock_init(&
llllI->lock);for(i=(0x1731+1691-0x1dcc);i<lIllIll;i++){llllllI(llllI,i,IIlIIllI,
(0x177c+1542-0x1d82));}IIIll=usb_add_hcd(lIIIIII,(0x351+1462-0x907),
(0x7f9+6915-0x22fc));if(IIIll!=(0x915+7531-0x2680)){break;}IIIlllI(IlllllI)->
IlllIlll=lIIIIII;IIIlllI(lIIIIII)->IlllIlll=IlllllI;
#endif 
}while((0x320+1051-0x73b));if(IIIll!=(0x786+7136-0x2366)){if(IlllllI){
usb_put_hcd(IlllllI);IlllllI=NULL;}
#if KERNEL_GT_EQ((0x191d+2998-0x24d1),(0x1720+779-0x1a25),(0x898+7327-0x2510)) \
|| RHEL_RELEASE_GT_EQ((0x102c+2450-0x19b8),(0x819+7538-0x2588)) 
if(lIIIIII){usb_put_hcd(lIIIIII);lIIIIII=NULL;}
#endif
}Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x64\x72\x69\x76\x65\x72\x5f\x70\x72\x6f\x62\x65\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x20\x3d\x20\x25\x64" "\n"
,IIIll);return IIIll;}static int IIllIIllI(struct platform_device*IlIlII){struct
 usb_hcd*IllIl=platform_get_drvdata(IlIlII);struct lIIIII*llllI=IIIlllI(IllIl);
Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x64\x72\x69\x76\x65\x72\x5f\x72\x65\x6d\x6f\x76\x65\x5b\x25\x73\x5d\x3a\x20\x2b\x2b" "\n"
,IlIllII(IllIl));if(llllI->IlllIlll){usb_remove_hcd(llllI->IlllIlll);usb_put_hcd
(llllI->IlllIlll);llllI->IlllIlll=NULL;}usb_remove_hcd(IllIl);usb_put_hcd(IllIl)
;Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x64\x72\x69\x76\x65\x72\x5f\x72\x65\x6d\x6f\x76\x65\x3a\x20\x2d\x2d" "\n"
);return(0xcb2+15-0xcc1);}static void lllIlIIll(struct device*dev){return;}
static int IIlIIlIll(struct usb_hcd*IllIl){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x72\x65\x73\x65\x74\x5b\x25\x73\x5d" "\n"
,IlIllII(IllIl));


#if KERNEL_GT_EQ((0x144a+4457-0x25b1),(0x16ec+2066-0x1ef8),(0x8ed+3679-0x1725)) \
|| RHEL_RELEASE_GT_EQ((0x1171+2742-0x1c21),(0x1bc9+2012-0x23a2)) 
if(usb_hcd_is_primary_hcd(IllIl)){
Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x72\x65\x73\x65\x74\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x75\x70\x20\x55\x53\x42\x32\x20\x68\x63\x64" "\n"
);IllIl->speed=HCD_USB2;IllIl->self.root_hub->speed=USB_SPEED_HIGH;}
#endif
#if KERNEL_GT_EQ((0x114b+5405-0x2665),(0x12ad+3924-0x21fb),(0x1bdd+2534-0x25c3))\
 || RHEL_RELEASE_GT_EQ((0x13c7+3751-0x2267),(0x19a+6612-0x1b6e))
if(!usb_hcd_is_primary_hcd(IllIl)){

IllIl->self.no_stop_on_short=(0x1563+3171-0x21c5);}
#endif
return(0x762+7821-0x25ef);}static int lIIllIIll(struct usb_hcd*IllIl){int i;
Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x73\x74\x61\x72\x74\x5b\x25\x73\x5d" "\n"
,IlIllII(IllIl));IllIl->power_budget=(0x431+3949-0x139e);IllIl->state=
HC_STATE_RUNNING;IllIl->uses_new_polling=(0x11d0+1973-0x1984);for(i=
(0x240f+683-0x26ba);i<lIllIll;i++){
#if KERNEL_GT_EQ((0x1191+5149-0x25ac),(0x37+1741-0x6fe),(0xedd+650-0x1140)) || \
RHEL_RELEASE_GT_EQ((0xe2+4846-0x13ca),(0x88a+3384-0x15bf)) 
if(IllIl->speed==HCD_USB3){llllllI(IIIlllI(IllIl),i,IlIlIIII,
(0x128f+2351-0x1bbe));}else
#endif
{IlIIllI(IIIlllI(IllIl),i,IlIlIIII,(0x140c+2950-0x1f92));}}return
(0xea+8808-0x2352);}static void IllIlllII(struct usb_hcd*IllIl){int i;Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x73\x74\x6f\x70\x5b\x25\x73\x5d" "\n",
IlIllII(IllIl));for(i=(0x1a13+727-0x1cea);i<lIllIll;i++){
#if KERNEL_GT_EQ((0x101+1701-0x7a4),(0x18dd+1630-0x1f35),(0x9aa+686-0xc31)) || \
RHEL_RELEASE_GT_EQ((0x92a+2726-0x13ca),(0xf14+5488-0x2481)) 
if(IllIl->speed==HCD_USB3){llllllI(IIIlllI(IllIl),i,llIllllI,(0xa9f+4284-0x1b5b)
);}else
#endif
{IlIIllI(IIIlllI(IllIl),i,llIllllI,(0x935+1868-0x1081));}}}static int llllIIlll(
struct usb_hcd*IllIl){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x67\x65\x74\x5f\x66\x72\x61\x6d\x65\x5f\x6e\x75\x6d\x62\x65\x72\x5b\x25\x73\x5d" "\n"
,IlIllII(IllIl));return(0x294+1513-0x87d);}int llllIIIll(struct lIlIIl*lIIII,
struct lIlIlI**llIIllIl,struct urb*IlllI){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x61\x64\x64\x5f\x75\x72\x62\x3a\x20\x75\x72\x62\x3d\x25\x70" "\n"
,IlllI);if(*llIIllIl){struct llIIlll*IllIlI;Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x61\x64\x64\x5f\x75\x72\x62\x3a\x20\x65\x78\x69\x73\x74\x69\x6e\x67\x20\x70\x76\x72\x65\x71" "\n"
);IllIlI=IllIIlI(sizeof(struct llIIlll),GFP_ATOMIC);if(IllIlI){IllIlI->IlllI=
IlllI;list_add_tail(&IllIlI->llIIII,&(*llIIllIl)->IIIIlll);}else{Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x61\x64\x64\x5f\x75\x72\x62\x3a\x20\x6e\x6f\x20\x6d\x65\x6d\x6f\x72\x79\x20\x66\x6f\x72\x20\x75\x72\x62\x5f\x6c\x69\x73\x74" "\n"
);return-ENOMEM;}}else{Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x61\x64\x64\x5f\x75\x72\x62\x3a\x20\x6e\x65\x77\x20\x70\x76\x72\x65\x71" "\n"
);*llIIllIl=lIIIIIlll(lIIII,GFP_ATOMIC);if(*llIIllIl==NULL){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x61\x64\x64\x5f\x75\x72\x62\x3a\x20\x6e\x6f\x20\x6d\x65\x6d\x6f\x72\x79\x20\x66\x6f\x72\x20\x71\x75\x65\x75\x65\x5f\x65\x6e\x74\x72\x79" "\n"
);return-ENOMEM;}else{(*llIIllIl)->urb.IlllI=IlllI;list_add_tail(&(*llIIllIl)->
urb.llIIII,&(*llIIllIl)->IIIIlll);}}return(0xc49+1111-0x10a0);}
#if KERNEL_LT((0x409+868-0x76b),(0x1d44+2459-0x26d9),(0x727+6580-0x20c3))
static int lIIIIllI(struct usb_hcd*IllIl,struct usb_host_endpoint*ep,struct urb*
urb,gfp_t lIIIl)
#else
static int lIIIIllI(struct usb_hcd*IllIl,struct urb*urb,gfp_t lIIIl)
#endif
{int IIIll=-EINPROGRESS;struct lIIIII*llllI=IIIlllI(IllIl);struct lIlIIl*lIIII=
NULL;struct lIlIlI*IIIII=NULL;unsigned long flags;int IlIlIIlIl=
(0x1f9d+1754-0x2677);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x65\x6e\x71\x75\x65\x75\x65\x5b\x25\x73\x5d\x3a\x20\x2b\x2b\x20\x75\x72\x62\x3d\x30\x78\x25\x70\x20\x75\x73\x62\x5f\x64\x65\x76\x69\x63\x65\x3d\x30\x78\x25\x70\x20\x70\x61\x72\x65\x6e\x74\x3d\x30\x78\x25\x70\x20\x64\x65\x76\x6e\x75\x6d\x3d\x25\x64\x20\x6e\x75\x6d\x5f\x73\x67\x73\x3d\x25\x64" "\n"
,IlIllII(IllIl),urb,urb->dev,urb->dev->dev.parent,urb->dev->devnum,
#if KERNEL_GT_EQ((0x22f+6439-0x1b54),(0xc44+2659-0x16a1),(0x48b+5576-0x1a34))
urb->num_sgs);
#else
(0x15d9+347-0x1734));
#endif
IIlIIIIlI("\x45\x4e\x51\x55\x45\x55\x45",urb,(0x11b+7080-0x1cc3),
(0x29f+533-0x4b3));do
{
#if KERNEL_GT_EQ((0x1841+591-0x1a8e),(0x154f+2300-0x1e45),(0x153f+3047-0x210e))
struct usb_host_endpoint*ep=urb->ep;
#endif
spin_lock_irqsave(&llllI->lock,flags);
#if KERNEL_GT_EQ((0x12d5+1672-0x195b),(0x1fa1+1639-0x2602),(0x16c7+963-0x1a72))


IIIll=usb_hcd_link_urb_to_ep(IllIl,urb);
#else
spin_lock(&urb->lock);IIIll=(urb->status==-EINPROGRESS)?(0x81f+3062-0x1415):urb
->status;spin_unlock(&urb->lock);
#endif
if(IIIll!=(0x14cd+3306-0x21b7)){spin_unlock_irqrestore(&llllI->lock,flags);Illll
(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x65\x6e\x71\x75\x65\x75\x65\x3a\x20\x75\x72\x62\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x75\x6e\x6c\x69\x6e\x6b\x65\x64" "\n"
);break;}
#if KERNEL_GT_EQ((0x16cf+2753-0x218e),(0x80+4131-0x109d),(0x106c+907-0x13d0)) ||\
 RHEL_RELEASE_GT_EQ((0x679+3559-0x145a),(0x1362+3094-0x1f75)) 








if(IllIl->speed==HCD_USB3){
lIIII=IIlIlIllI(IllIl,urb->dev->portnum);}else
#endif
{
lIIII=IllIlllIl(IllIl,usb_pipedevice(urb->pipe));}if(lIIII==NULL){
#if KERNEL_GT_EQ((0x7bb+6829-0x2266),(0x405+1838-0xb2d),(0x1342+3777-0x21eb))
usb_hcd_unlink_urb_from_ep(IllIl,urb);
#endif
spin_unlock_irqrestore(&llllI->lock,flags);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x65\x6e\x71\x75\x65\x75\x65\x3a\x20\x64\x65\x76\x69\x63\x65\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
);IIIll=-ENODEV;break;}if(usb_pipedevice(urb->pipe)==(0x299+6041-0x1a32)&&
usb_pipetype(urb->pipe)==PIPE_CONTROL){struct usb_ctrlrequest*llIlll=(struct 
usb_ctrlrequest*)urb->setup_packet;if(!llIlll){
#if KERNEL_GT_EQ((0xd74+4522-0x1f1c),(0x191+6014-0x1909),(0x20b1+1197-0x2546))
usb_hcd_unlink_urb_from_ep(IllIl,urb);
#endif
spin_unlock_irqrestore(&llllI->lock,flags);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x65\x6e\x71\x75\x65\x75\x65\x3a\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x63\x6f\x6e\x74\x72\x6f\x6c\x20\x74\x72\x61\x6e\x73\x66\x65\x72\x20\x75\x72\x62" "\n"
);IIIll=-EINVAL;break;}if(llIlll->bRequest==USB_REQ_SET_ADDRESS){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x65\x6e\x71\x75\x65\x75\x65\x3a\x20\x55\x53\x42\x5f\x52\x45\x51\x5f\x53\x45\x54\x5f\x41\x44\x44\x52\x45\x53\x53\x20\x61\x64\x64\x72\x65\x73\x73\x3d\x25\x64" "\n"
,llIlll->wValue);lIIII->lllIIlI=le16_to_cpu(llIlll->wValue);
#if KERNEL_GT_EQ((0x331+6311-0x1bd6),(0xb0b+5034-0x1eaf),(0xd89+5239-0x21e8))
usb_hcd_unlink_urb_from_ep(IllIl,urb);
#endif
spin_unlock(&llllI->lock);
#if KERNEL_LT((0x165d+3412-0x23af),(0x239+1235-0x706),(0x84+2569-0xa75))

spin_lock(&urb->lock);if(urb->status==-EINPROGRESS){urb->status=
(0x8c0+2264-0x1198);}spin_unlock(&urb->lock);
#else

#endif
#if KERNEL_LT((0x54d+6921-0x2054),(0x1a37+95-0x1a90),(0xfc+1690-0x783))
usb_hcd_giveback_urb(lIIII->parent,urb,NULL);
#elif KERNEL_LT((0x103+3017-0xcca),(0x1740+3149-0x2387),(0xe20+5868-0x24f4))
usb_hcd_giveback_urb(lIIII->parent,urb);
#else
usb_hcd_giveback_urb(lIIII->parent,urb,(0x146b+3261-0x2128));
#endif
local_irq_restore(flags);IIIll=(0xd9+4038-0x109f);break;}}IIIII=ep->hcpriv;IIIll
=llllIIIll(lIIII,&IIIII,urb);if(IIIll!=(0x5b4+4733-0x1831)){
#if KERNEL_GT_EQ((0x2d4+6009-0x1a4b),(0x149a+4012-0x2440),(0x1786+1680-0x1dfe))
usb_hcd_unlink_urb_from_ep(IllIl,urb);
#endif
spin_unlock_irqrestore(&llllI->lock,flags);break;}urb->hcpriv=IIIII;if((
usb_pipetype(urb->pipe)==PIPE_BULK)&&((urb->transfer_flags&URB_NO_INTERRUPT)||(
lIIII->vid==(0x8c7+8225-0x2434)&&lIIII->lIllIIl==(0x1460+4423-0x24b3)))&&
((usb_pipein(urb->pipe)&&(urb->transfer_flags&URB_SHORT_NOT_OK))||(usb_pipeout(
urb->pipe)&&!(urb->transfer_flags&URB_ZERO_PACKET)))){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x65\x6e\x71\x75\x65\x75\x65\x3a\x20\x6d\x65\x72\x67\x65\x20\x73\x70\x6c\x69\x74\x74\x65\x64\x20\x75\x72\x62" "\n"
);if(ep->hcpriv==NULL){ep->hcpriv=IIIII;
spin_lock(&lIIII->IlllII);list_add_tail(&IIIII->llllIl,&lIIII->llllIll);
spin_unlock(&lIIII->IlllII);}}else{spin_lock(&lIIII->IlllII);if(ep->hcpriv){ep->
hcpriv=NULL;
list_del(&IIIII->llllIl);}list_add_tail(&IIIII->llllIl,&lIIII->lIlIIII);
IlIlIIlIl=(0x63d+2672-0x10ac);spin_unlock(&lIIII->IlllII);}
spin_unlock_irqrestore(&llllI->lock,flags);if(IlIlIIlIl){wake_up(&lIIII->IIIIlI)
;}IIIll=-EINPROGRESS;}while((0x1ed3+1188-0x2377));if(lIIII){
lIlIlIIl(lIIII);}if(IIIll==-EINPROGRESS){
Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x65\x6e\x71\x75\x65\x75\x65\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,(0xe5c+2957-0x19e9));return(0x396+386-0x518);}Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x65\x6e\x71\x75\x65\x75\x65\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}
#if KERNEL_LT((0x8c3+5058-0x1c83),(0x1d2+5722-0x1826),(0x111f+4997-0x248c))
static int lIllIlII(struct usb_hcd*IllIl,struct urb*urb)
#else
static int lIllIlII(struct usb_hcd*IllIl,struct urb*urb,int status)
#endif
{struct lIIIII*llllI=IIIlllI(IllIl);struct lIlIlI*IIIII;IIlIl IlIlI;int IIIll=
(0x2ec+3346-0xffe);int unlinked;unsigned long flags;Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x64\x65\x71\x75\x65\x75\x65\x5b\x25\x73\x5d\x3a\x20\x2b\x2b\x20\x75\x72\x62\x3d\x30\x78\x25\x70" "\n"
,IlIllII(IllIl),urb);do
{spin_lock_irqsave(&llllI->lock,flags);
#if KERNEL_GT_EQ((0xbd5+6926-0x26e1),(0x1124+2040-0x1916),(0xf86+2034-0x1760))
IIIll=usb_hcd_check_unlink_urb(IllIl,urb,status);if(IIIll!=(0x950+6208-0x2190)){

spin_unlock_irqrestore(&llllI->lock,flags);break;}
#endif
IIIII=(struct lIlIlI*)urb->hcpriv;if(!IIIII){

Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x64\x65\x71\x75\x65\x75\x65\x3a\x20\x6e\x6f\x20\x64\x65\x76\x69\x63\x65\x21" "\n"
);spin_unlock_irqrestore(&llllI->lock,flags);break;}spin_lock(&IIIII->lIIII->
IlllII);unlinked=IllIlIIlI(IIIII);spin_unlock(&IIIII->lIIII->IlllII);
spin_unlock_irqrestore(&llllI->lock,flags);if(unlinked){
#if KERNEL_LT((0x16b+7552-0x1ee9),(0x69c+7692-0x24a2),(0xcec+6365-0x25b1))
lIIIllII(IIIII,-ECONNRESET);
#else
lIIIllII(IIIII,status);
#endif
IlIlI=IllIIlI(sizeof(IIIlIIIll),GFP_ATOMIC);if(!IlIlI){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x64\x65\x71\x75\x65\x75\x65\x3a\x20\x6e\x6f\x20\x6d\x65\x6d\x6f\x72\x79\x20\x66\x6f\x72\x20\x75\x6e\x72\x62" "\n"
);lllIllII(IIIII);break;}IlIlI->lllII.IIllll=IIIII->lllIl;IlIlI->lllII.lIIIlll=
(0x3e2+3198-0x1060);IlIlI->lllII.IlIll=sizeof(IIIlIIIll);IlIlI->lllII.IIIIIIl=
llIIlIIl;IlIlI->lllII.Status=(0x116+5162-0x1540);IlIlI->lllII.Context=
(0x1a25+2957-0x25b2);INIT_LIST_HEAD(&IIIII->IIIIlll);IIIII->urb.IlllI=NULL;IIIII
->IlIlI=IlIlI;spin_lock_irqsave(&IIIII->lIIII->IlllII,flags);list_add_tail(&
IIIII->llllIl,&IIIII->lIIII->lIlIIII);spin_unlock_irqrestore(&IIIII->lIIII->
IlllII,flags);wake_up(&IIIII->lIIII->IIIIlI);}else{

Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x64\x65\x71\x75\x65\x75\x65\x3a\x20\x75\x72\x62\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x71\x75\x65\x75\x65" "\n"
);}}while((0x1480+4168-0x24c8));Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x72\x62\x5f\x64\x65\x71\x75\x65\x75\x65\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}void IlIIIlIlI(struct usb_hcd*IllIl,struct 
usb_host_endpoint*ep){unsigned long flags;struct lIIIII*llllI=IIIlllI(IllIl);
Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x5b\x25\x73\x5d\x3a\x20\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x65\x6e\x64\x70\x6f\x69\x6e\x74\x5f\x64\x69\x73\x61\x62\x6c\x65\x2b\x2b\x20\x65\x70\x3d\x25\x70" "\n"
,IlIllII(IllIl),ep);spin_lock_irqsave(&llllI->lock,flags);if(ep->hcpriv){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x63\x6c\x65\x61\x6e\x69\x6e\x67\x20\x75\x70\x20\x68\x63\x70\x72\x69\x76" "\n"
);ep->hcpriv=NULL;}spin_unlock_irqrestore(&llllI->lock,flags);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x65\x6e\x64\x70\x6f\x69\x6e\x74\x5f\x64\x69\x73\x61\x62\x6c\x65\x2d\x2d" "\n"
);}
#if KERNEL_GT_EQ((0x5b+5678-0x1687),(0x64+2101-0x893),(0x1f0+1588-0x7fd)) || \
RHEL_RELEASE_GT_EQ((0xd01+6352-0x25cb),(0x19bc+1136-0x1e29)) 
#define Illllllll \
		( USB_PORT_STAT_C_CONNECTION \
		| USB_PORT_STAT_C_ENABLE \
		| USB_PORT_STAT_C_SUSPEND \
		| USB_PORT_STAT_C_OVERCURRENT \
		| USB_PORT_STAT_C_RESET \
		| USB_PORT_STAT_C_BH_RESET \
		| USB_PORT_STAT_C_LINK_STATE \
		| USB_PORT_STAT_C_CONFIG_ERROR )
#else
#define Illllllll \
		( USB_PORT_STAT_C_CONNECTION \
		| USB_PORT_STAT_C_ENABLE \
		| USB_PORT_STAT_C_SUSPEND \
		| USB_PORT_STAT_C_OVERCURRENT \
		| USB_PORT_STAT_C_RESET )
#endif
#if KERNEL_GT_EQ((0x1740+2172-0x1fba),(0x2ca+888-0x63c),(0xba+4271-0x1142)) || \
RHEL_RELEASE_GT_EQ((0x17f7+3414-0x2547),(0x8f1+1933-0x107b)) 
size_t IIIlIIlIlI(void*IIIlI,size_t IIlIIl){struct{struct usb_bos_descriptor 
lIlIlIll;struct usb_ss_cap_descriptor ss_cap;}__packed lIIIIIl;memset(&lIIIIIl,
(0x7e5+3567-0x15d4),sizeof(lIIIIIl));lIIIIIl.lIlIlIll.bLength=USB_DT_BOS_SIZE,
lIIIIIl.lIlIlIll.bDescriptorType=USB_DT_BOS,lIIIIIl.lIlIlIll.wTotalLength=
cpu_to_le16(sizeof(lIIIIIl)),lIIIIIl.lIlIlIll.bNumDeviceCaps=(0xb13+7128-0x26ea)
,lIIIIIl.ss_cap.bLength=USB_DT_USB_SS_CAP_SIZE,lIIIIIl.ss_cap.bDescriptorType=
USB_DT_DEVICE_CAPABILITY,lIIIIIl.ss_cap.bDevCapabilityType=USB_SS_CAP_TYPE,
lIIIIIl.ss_cap.wSpeedSupported=cpu_to_le16(USB_5GBPS_OPERATION),lIIIIIl.ss_cap.
bFunctionalitySupport=ilog2(USB_5GBPS_OPERATION),IIlIIl=min_t(size_t,sizeof(
lIIIIIl),IIlIIl);memcpy(IIIlI,&lIIIIIl,IIlIIl);return IIlIIl;}size_t llIllIlIl(
void*IIIlI,size_t IIlIIl){struct usb_hub_descriptor desc;memset(&desc,
(0xf31+3548-0x1d0d),sizeof(desc));desc.bDescLength=(0x685+2841-0x1192);desc.
bDescriptorType=(0x16bc+3979-0x261d);desc.bNbrPorts=lIllIll;
desc.wHubCharacteristics=cpu_to_le16((0x111a+4725-0x238e));desc.u.ss.
bHubHdrDecLat=(0x24ba+3-0x24b9);
desc.u.ss.DeviceRemovable=cpu_to_le16(65534&(65535>>((0x2228+337-0x236a)-lIllIll
)));IIlIIl=min_t(size_t,desc.bDescLength,IIlIIl);memcpy(IIIlI,&desc,IIlIIl);
return IIlIIl;}
#endif 
size_t lllIIIlll(void*IIIlI,size_t IIlIIl){__u8*IllIIIlI;struct 
usb_hub_descriptor desc;memset(&desc,(0x2a9+7846-0x214f),sizeof(desc));desc.
bDescLength=(0x36a+649-0x5ec)+IIIllIIl*(0x17a9+1450-0x1d51);desc.bDescriptorType
=(0x1329+3147-0x1f4b);desc.bNbrPorts=lIllIll;desc.wHubCharacteristics=
cpu_to_le16((0x1782+133-0x1806));
#if KERNEL_GT_EQ((0x1bf0+450-0x1db0),(0x45a+7618-0x2216),(0xf92+326-0x10b1)) || \
RHEL_RELEASE_GT_EQ((0x85c+4649-0x1a7f),(0x1e11+195-0x1ed2))
IllIIIlI=desc.u.hs.DeviceRemovable;
#else
IllIIIlI=desc.DeviceRemovable;
#endif
memset(&IllIIIlI[(0x3cd+7386-0x20a7)],(0x164+8044-0x20d0),IIIllIIl);memset(&
IllIIIlI[IIIllIIl],(0x1b4d+463-0x1c1d),IIIllIIl);IIlIIl=min_t(size_t,desc.
bDescLength,IIlIIl);memcpy(IIIlI,&desc,IIlIIl);return IIlIIl;}static int 
IIlllIIlI(struct usb_hcd*IllIl,u16 IIlIlIIll,u16 wValue,u16 wIndex,char*IIIlI,
u16 wLength){struct lIIIII*llllI=IIIlllI(IllIl);int IIIll=(0x1815+2237-0x20d2);
int lIllI=-(0x16e9+2884-0x222c);int IlllIIIlI=(0x1732+1558-0x1d48);unsigned long
 flags;Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x5b\x25\x73\x5d\x3a\x20\x2b\x2b" "\n"
,IlIllII(IllIl));if(!test_bit(HCD_FLAG_HW_ACCESSIBLE,&IllIl->flags)){return-
ETIMEDOUT;}spin_lock_irqsave(&llllI->lock,flags);switch(IIlIlIIll){case 
GetHubDescriptor:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x47\x65\x74\x48\x75\x62\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72" "\n"
);
#if KERNEL_GT_EQ((0x598+7132-0x2172),(0x1686+529-0x1891),(0x8b1+733-0xb67)) || \
RHEL_RELEASE_GT_EQ((0x1e97+1832-0x25b9),(0xa9a+3197-0x1714)) 
if(IllIl->speed==HCD_USB3){if((wValue>>(0x3bc+7303-0x203b))!=USB_DT_SS_HUB){
IIIll=-EPIPE;break;}

llIllIlIl(IIIlI,wLength);}else
#endif
{if((wValue>>(0xeef+4599-0x20de))!=USB_DT_HUB){IIIll=-EPIPE;break;}lllIIIlll(
IIIlI,wLength);}break;
#if KERNEL_GT_EQ((0x1557+346-0x16af),(0xf93+3882-0x1eb7),(0xc54+4108-0x1c39)) ||\
 RHEL_RELEASE_GT_EQ((0x530+6161-0x1d3b),(0x12ca+2098-0x1af9)) 
case DeviceRequest|USB_REQ_GET_DESCRIPTOR:if(IllIl->speed!=HCD_USB3){IIIll=-
EPIPE;break;}if((wValue>>(0xff7+1212-0x14ab))!=USB_DT_BOS){IIIll=-EPIPE;break;}
IIIll=IIIlIIlIlI(IIIlI,wLength);break;case GetPortErrorCount:
if(IllIl->speed!=HCD_USB3){IIIll=-EPIPE;break;}
*(__le16*)IIIlI=cpu_to_le16((0xa30+4317-0x1b0d));break;case SetHubDepth:
if(IllIl->speed!=HCD_USB3){IIIll=-EPIPE;break;}
break;
#endif
case GetHubStatus:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x47\x65\x74\x48\x75\x62\x53\x74\x61\x74\x75\x73" "\n"
);*(__le32*)IIIlI=cpu_to_le32((0x927+7101-0x24e4));break;case SetHubFeature:
Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x53\x65\x74\x48\x75\x62\x46\x65\x61\x74\x75\x72\x65" "\n"
);
IIIll=-EPIPE;break;case ClearHubFeature:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x65\x61\x72\x48\x75\x62\x46\x65\x61\x74\x75\x72\x65" "\n"
);
break;case GetPortStatus:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x47\x65\x74\x50\x6f\x72\x74\x53\x74\x61\x74\x75\x73" "\n"
);lIllI=(wIndex&(0x3df+8910-0x25ae))-(0x634+7971-0x2556);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x70\x6f\x72\x74\x3d\x25\x64" "\n"
,lIllI);if(lIllI<(0x7f+5752-0x16f7)||lIllI>=lIllIll){lIllI=-(0x788+1836-0xeb3);
IIIll=-EPIPE;break;}
if(llllI->llIlIII[lIllI]&&time_after_eq(jiffies,llllI->llIlIII[lIllI])){if(llllI
->lIlIIIlI[lIllI]==IIllllI){llllI->lllllIl[lIllI]->lllIIlI=(0x148c+1696-0x1b2c);
}
#if KERNEL_GT_EQ((0x66f+4628-0x1881),(0x3b6+4705-0x1611),(0xb7+2055-0x897)) || \
RHEL_RELEASE_GT_EQ((0x1a6c+3014-0x262c),(0x849+2271-0x1125)) 
if(IllIl->speed==HCD_USB3){llllllI(llllI,lIllI,lIIIlllI,(0xb67+3066-0x1761));}
else
#endif
{IlIIllI(llllI,lIllI,lIIIlllI,(0xbfb+6847-0x26ba));}}((__le16*)IIIlI)[
(0xe58+5636-0x245c)]=cpu_to_le16(llllI->IIlllIl[lIllI]);((__le16*)IIIlI)[
(0x364+8791-0x25ba)]=cpu_to_le16(llllI->lIIlIII[lIllI]);break;case 
SetPortFeature:lIllI=(wIndex&(0xa9b+1019-0xd97))-(0xb81+4502-0x1d16);if(lIllI<
(0x7f8+7014-0x235e)||lIllI>=lIllIll){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x70\x6f\x72\x74\x20\x6e\x75\x6d\x62\x65\x72\x20\x28\x25\x64\x29" "\n"
,lIllI);lIllI=-(0x18e2+522-0x1aeb);IIIll=-EPIPE;break;}
#if KERNEL_GT_EQ((0xfcd+1054-0x13e9),(0x1b3d+1485-0x2104),(0x14db+4291-0x2577)) \
|| RHEL_RELEASE_GT_EQ((0xd2c+4689-0x1f77),(0x44b+957-0x805)) 
if(IllIl->speed==HCD_USB3){IIIll=IIllllIlI(llllI,lIllI,wValue,wIndex>>
(0x7ba+4802-0x1a74));}else
#endif
{IIIll=llllIllII(llllI,lIllI,wValue,wIndex>>(0xae1+4140-0x1b05));}break;case 
ClearPortFeature:lIllI=(wIndex&(0xaed+799-0xd0d))-(0x6c4+5754-0x1d3d);if(lIllI<
(0xe53+1381-0x13b8)||lIllI>=lIllIll){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x70\x6f\x72\x74\x20\x6e\x75\x6d\x62\x65\x72\x20\x28\x25\x64\x29" "\n"
,lIllI);lIllI=-(0x20c+6379-0x1af6);IIIll=-EPIPE;break;}
#if KERNEL_GT_EQ((0x61b+1318-0xb3f),(0x1238+2386-0x1b84),(0xf47+4804-0x21e4)) ||\
 RHEL_RELEASE_GT_EQ((0x1a02+1401-0x1f75),(0x416+53-0x448)) 
if(IllIl->speed==HCD_USB3){IIIll=IIIIlIlll(llllI,lIllI,wValue);}else
#endif
{IIIll=llIlIlIIl(llllI,lIllI,wValue);}break;default:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x52\x65\x71\x3d\x30\x78\x25\x30\x34\x58\x20\x56\x61\x6c\x75\x65\x3d\x30\x78\x25\x30\x34\x58\x20\x49\x6e\x64\x65\x78\x3d\x30\x78\x25\x30\x34\x58\x69\x20\x4c\x65\x6e\x67\x74\x68\x3d\x25\x64" "\n"
,IIlIlIIll,wValue,wIndex,wLength);
IIIll=-EPIPE;break;}
IlllIIIlI=(lIllI!=-(0x373+3486-0x1110))&&((llllI->lIIlIII[lIllI]&Illllllll)!=
(0x17bf+2823-0x22c6));spin_unlock_irqrestore(&llllI->lock,flags);if(IlllIIIlI){
usb_hcd_poll_rh_status(IllIl);}Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x20\x3d\x20\x25\x64" "\n"
,IIIll);return IIIll;}static int llllIllII(struct lIIIII*llllI,int lIllI,int 
IllIllI,int lIlIIIl){int IIIll=(0xfe4+2760-0x1aac);switch(IllIllI){case 
USB_PORT_FEAT_ENABLE:Illll(
"\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x45\x4e\x41\x42\x4c\x45\x29" "\n"
,lIllI);


IIIll=-EPIPE;break;case USB_PORT_FEAT_SUSPEND:Illll(
"\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x53\x55\x53\x50\x45\x4e\x44\x29" "\n"
,lIllI);




IlIIllI(llllI,lIllI,IlllIIIIl,(0x1834+1308-0x1d50));break;case 
USB_PORT_FEAT_RESET:Illll(
"\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x52\x45\x53\x45\x54\x29" "\n"
,lIllI);





IlIIllI(llllI,lIllI,IIIIIIIl,(0xb3+6218-0x18fd));if(llllI->lllllIl[lIllI]&&llllI
->lllllIl[lIllI]->lllIIlI>(0x4b6+2038-0xcac)){IIllIlll(llllI->lllllIl[lIllI]);}
break;case USB_PORT_FEAT_POWER:Illll(
"\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x50\x4f\x57\x45\x52\x29" "\n"
,lIllI);


IlIIllI(llllI,lIllI,IIlIlIII,(0x6e7+115-0x75a));break;case USB_PORT_FEAT_TEST:
Illll(
"\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x54\x45\x53\x54\x29" "\n"
,lIllI);
break;case USB_PORT_FEAT_INDICATOR:Illll(
"\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x49\x4e\x44\x49\x43\x41\x54\x4f\x52\x29" "\n"
,lIllI);
break;case USB_PORT_FEAT_CONNECTION:case USB_PORT_FEAT_OVER_CURRENT:case 
USB_PORT_FEAT_C_CONNECTION:case USB_PORT_FEAT_C_OVER_CURRENT:case 
USB_PORT_FEAT_C_RESET:case USB_PORT_FEAT_LOWSPEED:case USB_PORT_FEAT_C_ENABLE:
case USB_PORT_FEAT_C_SUSPEND:


break;default:
Illll(
"\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x20\x25\x64\x29" "\n"
,lIllI,IllIllI);IIIll=-EPIPE;break;}return IIIll;}static int llIlIlIIl(struct 
lIIIII*llllI,int lIllI,int IllIllI){int IIIll=(0x1674+1951-0x1e13);switch(
IllIllI){case USB_PORT_FEAT_ENABLE:Illll(
"\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x45\x4e\x41\x42\x4c\x45\x29" "\n"
,lIllI);



IlIIllI(llllI,lIllI,IIllIIIl,(0x17f9+1498-0x1dd3));break;case 
USB_PORT_FEAT_SUSPEND:Illll(
"\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x53\x55\x53\x50\x45\x4e\x44\x29" "\n"
,lIllI);



IlIIllI(llllI,lIllI,lllIIIIlI,(0xc1b+564-0xe4f));break;case USB_PORT_FEAT_POWER:
Illll(
"\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x50\x4f\x57\x45\x52\x29" "\n"
,lIllI);

IlIIllI(llllI,lIllI,IIllIllI,(0x1aa+1096-0x5f2));break;case 
USB_PORT_FEAT_C_CONNECTION:Illll(
"\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x43\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x29" "\n"
,lIllI);IlIIllI(llllI,lIllI,lIllllIl,(0xff2+4550-0x21b8));break;case 
USB_PORT_FEAT_C_ENABLE:Illll(
"\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x43\x5f\x45\x4e\x41\x42\x4c\x45\x29" "\n"
,lIllI);IlIIllI(llllI,lIllI,lIlIIlIII,(0xf64+5227-0x23cf));break;case 
USB_PORT_FEAT_C_SUSPEND:Illll(
"\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x43\x5f\x53\x55\x53\x50\x45\x4e\x44\x29" "\n"
,lIllI);IlIIllI(llllI,lIllI,lIllIIlII,(0x3cc+4324-0x14b0));break;case 
USB_PORT_FEAT_C_OVER_CURRENT:Illll(
"\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x43\x5f\x4f\x56\x45\x52\x5f\x43\x55\x52\x52\x45\x4e\x54\x29" "\n"
,lIllI);
break;case USB_PORT_FEAT_C_RESET:Illll(
"\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x43\x5f\x52\x45\x53\x45\x54\x29" "\n"
,lIllI);IlIIllI(llllI,lIllI,llIllIll,(0x5e1+3649-0x1422));break;case 
USB_PORT_FEAT_INDICATOR:Illll(
"\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x49\x4e\x44\x49\x43\x41\x54\x4f\x52\x29" "\n"
,lIllI);
break;case USB_PORT_FEAT_CONNECTION:case USB_PORT_FEAT_OVER_CURRENT:case 
USB_PORT_FEAT_RESET:case USB_PORT_FEAT_TEST:


break;default:Illll(
"\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x20\x25\x64\x29" "\n"
,lIllI,IllIllI);IIIll=-EPIPE;break;}return IIIll;}
#if KERNEL_GT_EQ((0x74c+1053-0xb67),(0x140f+3052-0x1ff5),(0x15a5+3527-0x2345)) \
|| RHEL_RELEASE_GT_EQ((0xf7a+671-0x1213),(0x21a6+74-0x21ed)) 
static int IIllllIlI(struct lIIIII*llllI,int lIllI,int IllIllI,int lIlIIIl){int 
IIIll=(0x793+3504-0x1543);switch(IllIllI){case USB_PORT_FEAT_BH_PORT_RESET:Illll
(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x42\x48\x5f\x50\x4f\x52\x54\x5f\x52\x45\x53\x45\x54\x29" "\n"
,lIllI);







llllllI(llllI,lIllI,IIIIIIIl,(0x9b7+1529-0xfb0));if(llllI->lllllIl[lIllI]&&llllI
->lllllIl[lIllI]->lllIIlI>(0x1061+5605-0x2646)){IIllIlll(llllI->lllllIl[lIllI]);
}break;case USB_PORT_FEAT_RESET:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x52\x45\x53\x45\x54\x29" "\n"
,lIllI);





llllllI(llllI,lIllI,IIIIIIIl,(0xdaa+5183-0x21e9));if(llllI->lllllIl[lIllI]&&
llllI->lllllIl[lIllI]->lllIIlI>(0x1277+2426-0x1bf1)){IIllIlll(llllI->lllllIl[
lIllI]);}break;case USB_PORT_FEAT_LINK_STATE:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x4c\x49\x4e\x4b\x5f\x53\x54\x41\x54\x45\x2c\x20\x30\x78\x25\x30\x34\x78\x29" "\n"
,lIllI,lIlIIIl);


llllllI(llllI,lIllI,lIllIIlI,lIlIIIl);break;case USB_PORT_FEAT_POWER:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x50\x4f\x57\x45\x52\x29" "\n"
,lIllI);

llllllI(llllI,lIllI,IIlIlIII,(0x526+1554-0xb38));break;case 
USB_PORT_FEAT_U1_TIMEOUT:case USB_PORT_FEAT_U2_TIMEOUT:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x55\x31\x2f\x55\x32\x5f\x54\x49\x4d\x45\x4f\x55\x54\x29" "\n"
,lIllI);


break;case USB_PORT_FEAT_REMOTE_WAKE_MASK:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x52\x45\x4d\x4f\x54\x45\x5f\x57\x41\x4b\x45\x5f\x4d\x41\x53\x4b\x29" "\n"
,lIllI);

break;case USB_PORT_FEAT_FORCE_LINKPM_ACCEPT:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x46\x4f\x52\x43\x45\x5f\x4c\x49\x4e\x4b\x50\x4d\x5f\x41\x43\x43\x45\x50\x54\x29" "\n"
,lIllI);
break;case USB_PORT_FEAT_CONNECTION:case USB_PORT_FEAT_OVER_CURRENT:case 
USB_PORT_FEAT_C_CONNECTION:case USB_PORT_FEAT_C_OVER_CURRENT:case 
USB_PORT_FEAT_C_RESET:case USB_PORT_FEAT_C_PORT_LINK_STATE:case 
USB_PORT_FEAT_C_PORT_CONFIG_ERROR:case USB_PORT_FEAT_C_BH_PORT_RESET:


break;default:
Illll(
"\x53\x65\x74\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x20\x25\x64\x29" "\n"
,lIllI,IllIllI);IIIll=-EPIPE;break;}return IIIll;}static int IIIIlIlll(struct 
lIIIII*llllI,int lIllI,int IllIllI){int IIIll=(0x6fd+4103-0x1704);switch(IllIllI
){case USB_PORT_FEAT_POWER:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x50\x4f\x57\x45\x52\x29" "\n"
,lIllI);

llllllI(llllI,lIllI,IIllIllI,(0x36d+1311-0x88c));break;case 
USB_PORT_FEAT_C_CONNECTION:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x43\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x29" "\n"
,lIllI);llllllI(llllI,lIllI,lIllllIl,(0x179a+1640-0x1e02));break;case 
USB_PORT_FEAT_C_OVER_CURRENT:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x43\x5f\x4f\x56\x45\x52\x5f\x43\x55\x52\x52\x45\x4e\x54\x29" "\n"
,lIllI);
break;case USB_PORT_FEAT_C_RESET:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x43\x5f\x52\x45\x53\x45\x54\x29" "\n"
,lIllI);llllllI(llllI,lIllI,llIllIll,(0x188+7048-0x1d10));break;case 
USB_PORT_FEAT_C_PORT_LINK_STATE:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x43\x5f\x50\x4f\x52\x54\x5f\x4c\x49\x4e\x4b\x5f\x53\x54\x41\x54\x45\x29" "\n"
,lIllI);llllllI(llllI,lIllI,llIIllIlI,(0x14f8+2779-0x1fd3));break;case 
USB_PORT_FEAT_C_PORT_CONFIG_ERROR:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x43\x5f\x50\x4f\x52\x54\x5f\x43\x4f\x4e\x46\x49\x47\x5f\x45\x52\x52\x4f\x52\x29" "\n"
,lIllI);
break;case USB_PORT_FEAT_C_BH_PORT_RESET:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x43\x5f\x42\x48\x5f\x50\x4f\x52\x54\x5f\x52\x45\x53\x45\x54\x29" "\n"
,lIllI);llllllI(llllI,lIllI,llllIIlIl,(0x1005+2014-0x17e3));break;case 
USB_PORT_FEAT_FORCE_LINKPM_ACCEPT:Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x55\x53\x42\x5f\x50\x4f\x52\x54\x5f\x46\x45\x41\x54\x5f\x46\x4f\x52\x43\x45\x5f\x4c\x49\x4e\x4b\x50\x4d\x5f\x41\x43\x43\x45\x50\x54\x29" "\n"
,lIllI);
break;case USB_PORT_FEAT_CONNECTION:case USB_PORT_FEAT_OVER_CURRENT:case 
USB_PORT_FEAT_RESET:case USB_PORT_FEAT_LINK_STATE:case USB_PORT_FEAT_U1_TIMEOUT:
case USB_PORT_FEAT_U2_TIMEOUT:case USB_PORT_FEAT_REMOTE_WAKE_MASK:case 
USB_PORT_FEAT_BH_PORT_RESET:


break;default:Illll(
"\x43\x6c\x65\x61\x72\x50\x6f\x72\x74\x46\x65\x61\x74\x75\x72\x65\x28\x25\x64\x2c\x20\x25\x64\x29" "\n"
,lIllI,IllIllI);IIIll=-EPIPE;break;}return IIIll;}
#endif 
static int IIIllIlII(struct usb_hcd*IllIl,char*IIIlI){int IIIll=
(0x1c22+86-0x1c78);struct lIIIII*llllI=IIIlllI(IllIl);u32*lIIIlIlII=(u32*)IIIlI;
unsigned long flags;Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x73\x74\x61\x74\x75\x73\x5f\x64\x61\x74\x61\x5b\x25\x73\x5d\x2b\x2b" "\n"
,IlIllII(IllIl));spin_lock_irqsave(&llllI->lock,flags);do
{int i;int IIIIIlIlI=(0x1a96+958-0x1e54);if(!test_bit(HCD_FLAG_HW_ACCESSIBLE,&
IllIl->flags)){break;}for(i=(0x1487+1969-0x1c38);i<lIllIll;i++){if(llllI->
lIIlIII[i]&Illllllll){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x73\x74\x61\x74\x75\x73\x5f\x64\x61\x74\x61\x3a\x20\x70\x6f\x72\x74\x20\x25\x64\x20\x68\x61\x73\x20\x63\x68\x61\x6e\x67\x65\x64\x2e\x20\x77\x50\x6f\x72\x74\x53\x74\x61\x74\x75\x73\x3d\x30\x78\x25\x30\x34\x58\x20\x77\x50\x6f\x72\x74\x43\x68\x61\x6e\x67\x65\x3d\x30\x78\x25\x30\x34\x58" "\n"
,i,llllI->IIlllIl[i],llllI->lIIlIII[i]);if(IIIIIlIlI==(0x2b0+1568-0x8d0)){*
lIIIlIlII=(0x30d+643-0x590);}IIIIIlIlI=(0x1dc+3669-0x1030);
*lIIIlIlII|=(0xf04+532-0x1117)<<(i+(0x4c6+7092-0x2079));}}if(IIIIIlIlI){IIIll=
IIIllIIl;if(llllI->lIlIIIIII){usb_hcd_resume_root_hub(IllIl);}}}while(
(0xe97+3172-0x1afb));spin_unlock_irqrestore(&llllI->lock,flags);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x68\x75\x62\x5f\x73\x74\x61\x74\x75\x73\x5f\x64\x61\x74\x61\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x20\x3d\x20\x25\x64\x20\x6d\x61\x73\x6b\x20\x3d\x20\x30\x78\x25\x30\x38\x58" "\n"
,IIIll,(u32)*lIIIlIlII);return IIIll;}static int IIIlllIlI(struct usb_hcd*IllIl)
{
struct lIIIII*llllI=IIIlllI(IllIl);llllI->lIlIIIIII=(0x1b2b+1028-0x1f2e);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x62\x75\x73\x5f\x73\x75\x73\x70\x65\x6e\x64\x5b\x25\x73\x5d" "\n"
,IlIllII(IllIl));return(0xcc6+3549-0x1aa3);}static int IIlIlIlII(struct usb_hcd*
IllIl){
struct lIIIII*llllI=IIIlllI(IllIl);llllI->lIlIIIIII=(0x325+3053-0xf12);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x62\x75\x73\x5f\x72\x65\x73\x75\x6d\x65\x5b\x25\x73\x5d" "\n"
,IlIllII(IllIl));return(0xb4c+346-0xca6);}
#if KERNEL_GT_EQ((0xa5a+5105-0x1e49),(0x691+356-0x7ef),(0x1914+1564-0x1f09)) || \
RHEL_RELEASE_GT_EQ((0x162c+491-0x1811),(0xcb7+5975-0x240b)) 
static int IIllIlllI(struct usb_hcd*IllIl,struct usb_device*llIII,struct 
usb_host_endpoint**IlllllIIl,unsigned int lllllIlII,unsigned int IlIlllIlIl,
gfp_t lIIIl){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x61\x6c\x6c\x6f\x63\x5f\x73\x74\x72\x65\x61\x6d\x73\x5b\x25\x73\x5d" "\n"
,IlIllII(IllIl));
return(0x232a+981-0x26ff);}static int IlIlIIIIl(struct usb_hcd*IllIl,struct 
usb_device*llIII,struct usb_host_endpoint**IlllllIIl,unsigned int lllllIlII,
gfp_t lIIIl){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x66\x72\x65\x65\x5f\x73\x74\x72\x65\x61\x6d\x73\x5b\x25\x73\x5d" "\n"
,IlIllII(IllIl));
return(0x374+6488-0x1ccc);}
#endif 


int IlllIlIII(void){int IIIll=(0xc71+3184-0x18e1);int IlllIllll=
(0x10b6+1286-0x15bc);int IIlIIlIII=(0x23b7+754-0x26a9);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x2b\x2b" "\n"
);do
{struct sysinfo lIIlIlI;INIT_LIST_HEAD(&IlllIll);spin_lock_init(&lllIIl);
si_meminfo(&lIIlIlI);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x74\x6f\x74\x61\x6c\x72\x61\x6d\x3d\x25\x6c\x75\x20\x62\x79\x74\x65\x73\x20\x74\x6f\x74\x61\x6c\x68\x69\x67\x68\x3d\x25\x6c\x75\x20\x62\x79\x74\x65\x73" "\n"
,lIIlIlI.totalram*lIIlIlI.mem_unit,lIIlIlI.totalhigh*lIIlIlI.mem_unit);
#if defined(CONFIG_X86_32) && !defined(_USBD_VHCI_NO_DMA_)
























lIIlIlIl=(lIIlIlI.totalhigh>(0xbfb+3685-0x1a60));
#endif
IIIll=platform_driver_register(&llIlIlIlI);if(IIIll!=(0x2d4+5065-0x169d)){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x64\x72\x69\x76\x65\x72\x5f\x72\x65\x67\x69\x73\x74\x65\x72\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x6e\x75\x6d\x62\x65\x72\x20\x25\x64" "\n"
,IIIll);break;}IlllIllll=(0x1862+1077-0x1c96);IIIll=platform_device_register(&
IlIlIIlII);if(IIIll!=(0x1414+4489-0x259d)){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x64\x65\x76\x69\x63\x65\x5f\x72\x65\x67\x69\x73\x74\x65\x72\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x6e\x75\x6d\x62\x65\x72\x20\x25\x64" "\n"
,IIIll);break;}IIlIIlIII=(0x16eb+2276-0x1fce);IllIllIl=llIIIIlll();if(IllIllIl==
NULL){IIIll=-ENOMEM;Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x61\x6c\x6c\x6f\x63\x20\x6d\x69\x6e\x6f\x72\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x6e\x75\x6d\x62\x65\x72\x20\x25\x64" "\n"
,IIIll);break;}}while((0x5f2+4493-0x177f));if(IIIll!=(0x238+8749-0x2465)){if(
IllIllIl){IIIlIlIll(IllIllIl);IllIllIl=NULL;}if(IIlIIlIII){
platform_device_unregister(&IlIlIIlII);}if(IlllIllll){platform_driver_unregister
(&llIlIlIlI);}}Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x20\x3d\x20\x25\x64" "\n"
,IIIll);return IIIll;}void lllllIlll(void){Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x64\x65\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x2b\x2b" "\n"
);if(IllIllIl){IIIlIlIll(IllIllIl);IllIllIl=NULL;}spin_lock(&lllIIl);while(!
list_empty(&IlllIll)){struct lIlIIl*lIIII=(struct lIlIIl*)IlllIll.next;lllIIIlI(
lIIII);spin_unlock(&lllIIl);lIlIIlll(lIIII);lIlIlIIl(lIIII);spin_lock(&lllIIl);}
spin_unlock(&lllIIl);platform_device_unregister(&IlIlIIlII);
platform_driver_unregister(&llIlIlIlI);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x64\x65\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x2d\x2d" "\n"
);}struct lIlIIl*IlIIllllI(u16 vid,u16 lIllIIl,u16 lIIlIIl,int speed){struct 
lIlIIl*lIIII=NULL;do
{struct usb_hcd*parent;
#if KERNEL_GT_EQ((0xf0a+2553-0x1901),(0x17cc+336-0x1916),(0x1f52+419-0x20ce)) ||\
 RHEL_RELEASE_GT_EQ((0x2138+722-0x2404),(0xe83+2391-0x17d7)) 
parent=(speed>=USB_SPEED_SUPER)?lIIIIII:IlllllI;
#else
parent=IlllllI;
#endif
if(parent==NULL){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x76\x68\x63\x64\x20\x6e\x6f\x74\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64\x2e" "\n"
);break;}lIIII=lllIlII(sizeof(*lIIII),GFP_KERNEL);if(!lIIII){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x6b\x6d\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64\x2e" "\n"
);break;}if(IIIlIllII(lIIII)<(0xd9c+5342-0x227a)){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x6d\x69\x6e\x6f\x72\x20\x66\x61\x69\x6c\x65\x64\x2e" "\n"
);break;}
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&llIlIIllI);
#endif
init_waitqueue_head(&lIIII->IIIIlI);spin_lock_init(&lIIII->IlllII);
INIT_LIST_HEAD(&lIIII->llllIll);INIT_LIST_HEAD(&lIIII->lIlIIII);INIT_LIST_HEAD(&
lIIII->lllIllll);kref_init(&lIIII->IllIll);lIIII->vid=vid;lIIII->lIllIIl=lIllIIl
;lIIII->lIIlIIl=lIIlIIl;lIIII->speed=speed;lIIII->parent=parent;lIIII->lIllI=-
(0x2125+709-0x23e9);spin_lock(&lllIIl);list_add(&lIIII->llIIII,&IlllIll);
spin_unlock(&lllIIl);return lIIII;}while((0x1b80+232-0x1c68));if(lIIII){
lIlIIIlll(lIIII);lIlIll(lIIII);}return NULL;}void lIlIIlll(struct lIlIIl*lIIII){
struct list_head*IIIIlIlI;Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x72\x65\x6d\x6f\x76\x65\x2b\x2b" "\n"
);
spin_lock(&lllIIl);list_for_each(IIIIlIlI,&IlllIll){if(IIIIlIlI==&lIIII->llIIII)
{list_del_init(&lIIII->llIIII);break;}}spin_unlock(&lllIIl);


if(IIIIlIlI==&lIIII->llIIII){
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&IllIlIIl);
#endif


llIIIIlII(lIIII);lIlIlIIl(lIIII);}Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x72\x65\x6d\x6f\x76\x65\x2d\x2d" "\n"
);}void llIlIlIII(void){struct lIlIIl*lIIII;Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x72\x65\x6d\x6f\x76\x65\x5f\x61\x6c\x6c\x2b\x2b" "\n"
);spin_lock(&lllIIl);while(!list_empty(&IlllIll)){lIIII=list_entry(IlllIll.next,
struct lIlIIl,llIIII);list_del_init(&lIIII->llIIII);spin_unlock(&lllIIl);
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&IllIlIIl);
#endif
llIIIIlII(lIIII);lIlIlIIl(lIIII);spin_lock(&lllIIl);}spin_unlock(&lllIIl);Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x72\x65\x6d\x6f\x76\x65\x5f\x61\x6c\x6c\x2d\x2d" "\n"
);}int lIIlIIIII(struct lIlIIl*lIIII){int IIIll;unsigned long flags;int lIllI;
struct lIIIII*llllI;struct lIIIII*IlIlllIl;Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x70\x6c\x75\x67\x3a\x20\x2b\x2b" "\n"
);IIIll=IIlIlIIlI(lIIII);if(IIIll<(0x2219+469-0x23ee)){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x70\x6c\x75\x67\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}llllI=IIIlllI(lIIII->parent);IlIlllIl=llllI->IlllIlll?
IIIlllI(llllI->IlllIlll):NULL;spin_lock_irqsave(&llllI->lock,flags);if(IlIlllIl)
{spin_lock(&IlIlllIl->lock);}IIIll=-ENOENT;for(lIllI=(0x1ac9+2813-0x25c6);lIllI<
lIllIll;lIllI++){if((llllI->lllllIl[lIllI]==NULL)&&((IlIlllIl==NULL)||(IlIlllIl
->lllllIl[lIllI]==NULL))){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x70\x6c\x75\x67\x3a\x20\x66\x6f\x75\x6e\x64\x20\x66\x72\x65\x65\x20\x70\x6f\x72\x74\x20\x25\x64" "\n"
,lIllI);lllIIIlI(lIIII);lIIII->lIllI=lIllI;lIIII->lllIIlI=-(0x6b9+2723-0x115b);
llllI->lllllIl[lIllI]=lIIII;
#if KERNEL_GT_EQ((0x146+2033-0x935),(0x178a+3928-0x26dc),(0x5a2+2757-0x1040)) ||\
 RHEL_RELEASE_GT_EQ((0x853+2944-0x13cd),(0x765+2756-0x1226)) 
if(lIIII->parent->speed==HCD_USB3){llllllI(llllI,lIllI,IIIIlIIl,
(0x1b2a+1877-0x227f));}else
#endif
{IlIIllI(llllI,lIllI,IIIIlIIl,(0x5a8+1914-0xd22));}IIIll=(0x2a0+1353-0x7e9);
break;}}if(IlIlllIl){spin_unlock(&IlIlllIl->lock);}spin_unlock_irqrestore(&llllI
->lock,flags);if(IIIll<(0x1d3b+283-0x1e56)){
llIlIIIl(lIIII);}else{
usb_hcd_poll_rh_status(lIIII->parent);}Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x70\x6c\x75\x67\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}void llIIIIlII(struct lIlIIl*lIIII){unsigned long flags;
struct lIIIII*llllI=IIIlllI(lIIII->parent);Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x75\x6e\x70\x6c\x75\x67\x3a\x20\x2b\x2b" "\n"
);
llIlIIIl(lIIII);spin_lock_irqsave(&llllI->lock,flags);if(lIIII->lIllI!=-
(0x18a7+3082-0x24b0)){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x75\x6e\x70\x6c\x75\x67\x3a\x20\x75\x6e\x70\x6c\x75\x67\x67\x69\x6e\x67\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x64\x65\x76\x69\x63\x65\x20\x61\x74\x20\x70\x6f\x72\x74\x20\x25\x64" "\n"
,lIIII->lIllI);

llllI->lllllIl[lIIII->lIllI]=NULL;
#if KERNEL_GT_EQ((0x2091+605-0x22ec),(0xee6+3406-0x1c2e),(0xef2+2459-0x1866)) ||\
 RHEL_RELEASE_GT_EQ((0x25d1+275-0x26de),(0xda3+3155-0x19f3)) 
if(lIIII->parent->speed==HCD_USB3){llllllI(llllI,lIIII->lIllI,llIlIllI,
(0x143+1179-0x5de));}else
#endif
{IlIIllI(llllI,lIIII->lIllI,llIlIllI,(0x53f+5237-0x19b4));}lIIII->lIllI=-
(0x7a4+4939-0x1aee);spin_unlock_irqrestore(&llllI->lock,flags);
usb_hcd_poll_rh_status(lIIII->parent);IIlllIIII(lIIII,-ENODEV);lIlIlIIl(lIIII);}
else{spin_unlock_irqrestore(&llllI->lock,flags);}Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x75\x6e\x70\x6c\x75\x67\x3a\x20\x2d\x2d" "\n"
);}struct lIlIIl*IIlIIllII(int IIlIII){struct lIlIIl*lIIII;Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x66\x69\x6e\x64\x31\x3a\x20\x2b\x2b" "\n"
);spin_lock(&lllIIl);list_for_each_entry(lIIII,&IlllIll,llIIII){if(lIIlIllI(
lIIII->IllII)==IIlIII){lllIIIlI(lIIII);spin_unlock(&lllIIl);Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x66\x69\x6e\x64\x31\x3a\x20\x2d\x2d\x20\x66\x6f\x75\x6e\x64\x21" "\n"
);return lIIII;}}spin_unlock(&lllIIl);Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x66\x69\x6e\x64\x31\x3a\x20\x2d\x2d\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
);return NULL;}
struct lIlIIl*IllIlllIl(struct usb_hcd*IllIl,int lllIIlI){struct lIIIII*llllI=
IIIlllI(IllIl);struct lIlIIl*lIIII=NULL;int lIllI;Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x66\x69\x6e\x64\x32\x28\x29\x3a\x20\x2b\x2b\x20\x61\x64\x64\x72\x65\x73\x73\x20\x3d\x20\x25\x64" "\n"
,lllIIlI);if(llllI==NULL){return NULL;}if(lllIIlI<(0x600+3660-0x144c)){return 
NULL;}for(lIllI=(0x782+6951-0x22a9);lIllI<lIllIll;lIllI++){if(llllI->lllllIl[
lIllI]&&llllI->lllllIl[lIllI]->lllIIlI==lllIIlI){lIIII=llllI->lllllIl[lIllI];
lllIIIlI(lIIII);break;}}Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x66\x69\x6e\x64\x32\x3a\x20\x2d\x2d\x20\x25\x73" "\n"
,lIIII?"\x66\x6f\x75\x6e\x64":"\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64");return 
lIIII;}
struct lIlIIl*IIlIlIllI(struct usb_hcd*IllIl,int lIllI){struct lIIIII*llllI=
IIIlllI(IllIl);struct lIlIIl*lIIII=NULL;Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x66\x69\x6e\x64\x33\x28\x29\x3a\x20\x2b\x2b\x20\x70\x6f\x72\x74\x20\x3d\x20\x25\x64" "\n"
,lIllI);if(llllI==NULL){return NULL;}if(lIllI<=(0x378+7586-0x211a)||lIllI>
lIllIll){return NULL;}lIllI--;
if(llllI->lllllIl[lIllI]){lIIII=llllI->lllllIl[lIllI];lllIIIlI(lIIII);}Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x66\x69\x6e\x64\x33\x3a\x20\x2d\x2d\x20\x25\x73" "\n"
,lIIII?"\x66\x6f\x75\x6e\x64":"\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64");return 
lIIII;}void IIllIlll(struct lIlIIl*lIIII){IIlIl IlIlI;struct lIlIlI*IIIII;
unsigned long flags;IlIlI=IllIIlI(sizeof(IIIllllIl),GFP_ATOMIC);if(!IlIlI){Illll
(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x73\x65\x6e\x64\x5f\x72\x65\x73\x65\x74\x5f\x70\x6f\x72\x74\x3a\x20\x6e\x6f\x20\x6d\x65\x6d\x6f\x72\x79" "\n"
);return;}IIIII=lIIIIIlll(lIIII,GFP_ATOMIC);if(!IIIII){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x73\x65\x6e\x64\x5f\x72\x65\x73\x65\x74\x5f\x70\x6f\x72\x74\x3a\x20\x6e\x6f\x20\x6d\x65\x6d\x6f\x72\x79" "\n"
);lIlIll(IlIlI);return;}IlIlI->lllII.IIllll=IIIII->lllIl;IlIlI->lllII.lIIIlll=
(0xc21+4106-0x1c2b);IlIlI->lllII.IlIll=sizeof(IIIllllIl);IlIlI->lllII.IIIIIIl=
IIIlllII;IlIlI->lllII.Status=(0x397+4467-0x150a);IlIlI->lllII.Context=lIIII->
lIllI;IIIII->IlIlI=IlIlI;spin_lock_irqsave(&lIIII->IlllII,flags);list_add_tail(&
IIIII->llllIl,&lIIII->lIlIIII);spin_unlock_irqrestore(&lIIII->IlllII,flags);
wake_up(&lIIII->IIIIlI);}struct lIlIlI*lIIIIIlll(struct lIlIIl*lIIII,gfp_t lIIIl
){struct lIlIlI*IIIII;IIIII=lllIlII(sizeof(struct lIlIlI),lIIIl);if(!IIIII){
Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x6e\x6f\x20\x6d\x65\x6d\x6f\x72\x79" "\n"
);return NULL;}
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&lllllllll);
#endif
INIT_LIST_HEAD(&IIIII->llllIl);INIT_LIST_HEAD(&IIIII->IIIIlll);INIT_LIST_HEAD(&
IIIII->urb.llIIII);IIIII->lllIl=lllIlIlll();IIIII->lIIII=lllIIIlI(lIIII);return 
IIIII;}void lllIllII(struct lIlIlI*IIIII){


#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&lIllIIlIl);
#endif
if(IIIII->lIIII){lIlIlIIl(IIIII->lIIII);}lIlIll(IIIII);}
int IllIlIIlI(struct lIlIlI*IIIII){struct usb_host_endpoint*ep;struct lIlIlI*
lIIlIll;if(!list_empty(&IIIII->IIIIlll)){struct llIIlll*IllIlI=list_entry(IIIII
->IIIIlll.next,struct llIIlll,llIIII);
#if KERNEL_LT((0x11b8+2358-0x1aec),(0xe66+2633-0x18a9),(0x2af+1472-0x857))
ep=(usb_pipein(IllIlI->IlllI->pipe)?IllIlI->IlllI->dev->ep_in:IllIlI->IlllI->dev
->ep_out)[usb_pipeendpoint(IllIlI->IlllI->pipe)];
#else
ep=IllIlI->IlllI->ep;
#endif

if(ep&&ep->hcpriv==IIIII){ep->hcpriv=NULL;

list_del_init(&IIIII->llllIl);return(0x101c+1241-0x14f4);}}
list_for_each_entry(lIIlIll,&IIIII->lIIII->llllIll,llllIl){if(lIIlIll==IIIII){
list_del_init(&IIIII->llllIl);return(0x629+1778-0xd1a);}}
list_for_each_entry(lIIlIll,&IIIII->lIIII->lllIllll,llllIl){if(lIIlIll==IIIII){
list_del_init(&IIIII->llllIl);return(0xc23+3750-0x1ac8);}}
list_for_each_entry(lIIlIll,&IIIII->lIIII->lIlIIII,llllIl){if(lIIlIll==IIIII){
list_del_init(&IIIII->llllIl);return(0xcbb+4041-0x1c83);}}return
(0xa83+5997-0x21f0);}int lIlIllIl(struct lIlIlI*IIIII){struct llIIlll*IllIlI;
list_for_each_entry(IllIlI,&IIIII->IIIIlll,llIIII){
#if KERNEL_LT((0xdd4+591-0x1021),(0x13aa+652-0x1630),(0x22f+3456-0xf97))
spin_lock(&IllIlI->IlllI->lock);if(IllIlI->IlllI->status!=-EINPROGRESS){
spin_unlock(&IllIlI->IlllI->lock);return(0xb40+6327-0x23f6);}spin_unlock(&IllIlI
->IlllI->lock);
#else
if(IllIlI->IlllI->unlinked){return(0x2bb+4664-0x14f2);}
#endif
}return(0x46b+7004-0x1fc7);}void IIlllIIII(struct lIlIIl*lIIII,int status){
unsigned long flags;struct list_head IIIIllIl;struct lIlIlI*IIIII;INIT_LIST_HEAD
(&IIIIllIl);spin_lock_irqsave(&IIIlllI(lIIII->parent)->lock,flags);spin_lock(&
lIIII->IlllII);list_for_each_entry(IIIII,&lIIII->llllIll,llllIl){struct llIIlll*
llIIll;list_for_each_entry(llIIll,&IIIII->IIIIlll,llIIII){struct 
usb_host_endpoint*ep;
#if KERNEL_LT((0xa45+5722-0x209d),(0x58d+1936-0xd17),(0x108+8538-0x224a))
ep=(usb_pipein(llIIll->IlllI->pipe)?llIIll->IlllI->dev->ep_in:llIIll->IlllI->dev
->ep_out)[usb_pipeendpoint(llIIll->IlllI->pipe)];
#else
ep=llIIll->IlllI->ep;
#endif
if(ep)ep->hcpriv=NULL;}}list_splice_init(&lIIII->llllIll,&IIIIllIl);
list_splice_init(&lIIII->lIlIIII,&IIIIllIl);list_splice_init(&lIIII->lllIllll,&
IIIIllIl);spin_unlock(&lIIII->IlllII);spin_unlock_irqrestore(&IIIlllI(lIIII->
parent)->lock,flags);while(!list_empty(&IIIIllIl)){struct lIlIlI*IIIII=
list_entry(IIIIllIl.next,struct lIlIlI,llllIl);list_del_init(&IIIII->llllIl);
lIIIllII(IIIII,status);lllIllII(IIIII);}}void lIIIllII(struct lIlIlI*IIIII,int 
status){struct lIlIIl*lIIII=IIIII->lIIII;
#if KERNEL_GT_EQ((0x119f+1039-0x15ac),(0x649+4484-0x17c7),(0x96c+6407-0x225b))
struct lIIIII*llllI=IIIlllI(lIIII->parent);
#endif
unsigned long flags;int lIIIlllll=(0x1911+1359-0x1e60);Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x67\x69\x76\x65\x62\x61\x63\x6b\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x72\x65\x71\x75\x65\x73\x74\x20\x30\x78\x25\x70\x20\x73\x74\x61\x74\x75\x73\x3d\x25\x64" "\n"
,IIIII,status);local_irq_save(flags);while(!list_empty(&IIIII->IIIIlll)){struct 
llIIlll*IllIlI=list_entry(IIIII->IIIIlll.next,struct llIIlll,llIIII);if(IllIlI->
IlllI){int lIlIlllI=status;

if(usb_pipetype(IllIlI->IlllI->pipe)==PIPE_BULK||usb_pipetype(IllIlI->IlllI->
pipe)==PIPE_INTERRUPT){






switch(lIIIlllll){case(0x1f42+1629-0x259f):if(IllIlI->IlllI->actual_length<
IllIlI->IlllI->transfer_buffer_length){if((status==(0x373+2981-0xf18))&&(IllIlI
->IlllI->transfer_flags&URB_SHORT_NOT_OK)){lIlIlllI=-EREMOTEIO;}else{lIlIlllI=
status;}lIIIlllll=(0x1583+2745-0x203b);}else if(IllIlI->llIIII.next==&IIIII->
IIIIlll){lIlIlllI=status;lIIIlllll=(0x1888+3713-0x2708);}else{lIlIlllI=
(0x12c9+509-0x14c6);}break;case(0x1534+205-0x1600):lIlIlllI=-ECONNRESET;break;}}
Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x67\x69\x76\x65\x62\x61\x63\x6b\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x67\x69\x76\x65\x62\x61\x63\x6b\x20\x75\x72\x62\x20\x30\x78\x25\x70\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,IllIlI->IlllI,lIlIlllI);
#if KERNEL_LT((0x1fc+1583-0x829),(0x223f+1141-0x26ae),(0xc0b+3400-0x193b))


spin_lock(&IllIlI->IlllI->lock);if(IllIlI->IlllI->status==-EINPROGRESS){IllIlI->
IlllI->status=lIlIlllI;}spin_unlock(&IllIlI->IlllI->lock);
#else


spin_lock(&llllI->lock);usb_hcd_unlink_urb_from_ep(lIIII->parent,IllIlI->IlllI);
spin_unlock(&llllI->lock);
#endif



IllIlI->IlllI->hcpriv=NULL;
#if KERNEL_LT((0x161+5268-0x15f3),(0xe54+138-0xed8),(0x19c+2540-0xb75))
usb_hcd_giveback_urb(lIIII->parent,IllIlI->IlllI,NULL);
#elif KERNEL_LT((0xd16+4658-0x1f46),(0x50a+8541-0x2661),(0xe7a+1173-0x12f7))
usb_hcd_giveback_urb(lIIII->parent,IllIlI->IlllI);
#else
usb_hcd_giveback_urb(lIIII->parent,IllIlI->IlllI,lIlIlllI);
#endif
}list_del_init(&IllIlI->llIIII);if(IllIlI!=&IIIII->urb){lIlIll(IllIlI);}}
local_irq_restore(flags);if(IIIII->IlIlI){if(IIIII->IlIlI->lllII.IIIIIIl==
IIIlllII){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x67\x69\x76\x65\x62\x61\x63\x6b\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x72\x65\x73\x65\x74\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64" "\n"
);lIIII->lIlllIll=(0x149+5391-0x1658);wake_up(&lIIII->IIIIlI);}Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x67\x69\x76\x65\x62\x61\x63\x6b\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x66\x72\x65\x65\x69\x6e\x67\x20\x75\x6e\x72\x62" "\n"
);lIlIll(IIIII->IlIlI);IIIII->IlIlI=NULL;}}int llIllllIl(struct lIlIIl*lIIII,
struct lIlIlI*IIIII,void*lllll,size_t IlIIIl){int IIIll=(0x3e0+4965-0x1745);if(!
list_empty(&IIIII->IIIIlll)){IIIll=IllIIlIll(&IIIII->IIIIlll,IIIII->lllIl,lllll,
IlIIIl);}else if(IIIII->IlIlI){if(IlIIIl<IIIII->IlIlI->lllII.IlIll){IIIll=-
EMSGSIZE;}else{memcpy(lllll,IIIII->IlIlI,IIIII->IlIlI->lllII.IlIll);if(IIIII->
IlIlI->lllII.IIIIIIl==IIIlllII){lIIII->lIlllIll=(0x702+6932-0x2215);}}}else{
IIIll=-EIO;}Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x70\x61\x63\x6b\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x72\x65\x73\x75\x6c\x74\x20\x3d\x20\x25\x64" "\n"
,IIIll);return IIIll;}int lllIllIIl(struct lIlIIl*lIIII,struct lIlIlI*IIIII,
IIlIl IlIlI,int*status){int IIIll;



















if((lIIII->vid==(0x13a4+434-0x1153))&&(lIIII->lIllIIl==24596)&&(lIIII->lIIlIIl==
(0x22cf+126-0x1a4d))&&(IlIlI->lllII.IIIIIIl==IIlIlllI)&&((IlIlI->lllII.Status==
lIIllllll)||(IlIlI->lllII.Status==lIIlllIlI))&&(IlIlI->llIll.Endpoint==
(0x2244+3-0x2246))&&(IlIlI->llIll.Flags&IIIllI)&&(IlIlI->llIll.IIllI>=
(0x14af+1264-0x199d))){
void*lllll=&IlIlI->llIll+(0x191+3773-0x104d);if((IlIlI->llIll.IIllI==
(0x1f12+1661-0x258d))&&(*(unsigned short*)lllll==lIIII->lIIIlllII)){return
(0x3ed+3611-0x1207);
}if(IlIlI->llIll.IIllI>=(0x2572+392-0x26f8)){lIIII->lIIIlllII=*(unsigned short*)
lllll;}}

if(!list_empty(&IIIII->IIIIlll)){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x75\x6e\x70\x61\x63\x6b\x69\x6e\x67\x20\x75\x72\x62" "\n"
);IIIll=IIIlIIIlI(IlIlI,&IIIII->IIIIlll,status);}else{*status=lIIlIlll(IlIlI->
lllII.Status);IIIll=(0x748+7906-0x262a);}return IIIll;}void lIllIlllI(struct 
kref*IllIlII){struct lIlIIl*lIIII=container_of(IllIlII,struct lIlIIl,IllIll);
Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x64\x65\x73\x74\x72\x6f\x79\x28\x70\x76\x73\x74\x75\x62\x3d\x30\x78\x25\x70\x29" "\n"
,lIIII);
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&IIlIIIIII);
#endif
lIlIIIlll(lIIII);lIlIll(lIIII);}
static inline size_t llIIIlIII(struct urb*IlllI,void*lllll){int i;void*lllIll;if
(!IlllI->transfer_buffer){return(0xbaf+3901-0x1aec);}lllIll=lllll;for(i=
(0xa90+7116-0x265c);i<IlllI->number_of_packets;i++){memcpy(IlllI->
transfer_buffer+IlllI->iso_frame_desc[i].offset,lllIll,IlllI->iso_frame_desc[i].
actual_length);lllIll+=IlllI->iso_frame_desc[i].actual_length;}return(size_t)(
lllIll-lllll);}
#if defined(CONFIG_X86_32) && !defined(_USBD_VHCI_NO_DMA_)






int lllIlIII(void*lllll,struct urb*IlllI,int IlIII){
if(IlIII==(0xda5+3873-0x1cc6)){return(0x2042+1350-0x2588);}if(lIIlIlIl&&((IlllI
->transfer_buffer==NULL)||(IlllI->transfer_flags&URB_NO_TRANSFER_DMA_MAP))&&(
IlllI->transfer_dma!=(0x6a7+3166-0x1305))&&(IlllI->transfer_dma!=~(dma_addr_t)
(0x834+1054-0xc52))){lllIIllIl(lllll,IlllI->transfer_dma,IlIII);}else if(IlllI->
transfer_buffer){memcpy(lllll,IlllI->transfer_buffer,IlIII);}else return-EINVAL;
return IlIII;}





int IIlIlIIl(struct urb*IlllI,void*lllll,int IlIII){
if(IlIII==(0x5+2891-0xb50)){return(0x1dc1+384-0x1f41);}if(lIIlIlIl&&((IlllI->
transfer_buffer==NULL)||(IlllI->transfer_flags&URB_NO_TRANSFER_DMA_MAP))&&(IlllI
->transfer_dma!=(0x8da+5951-0x2019))&&(IlllI->transfer_dma!=~(dma_addr_t)
(0x1383+4940-0x26cf))){lIIlIIlII(IlllI->transfer_dma,lllll,IlIII);}else if(IlllI
->transfer_buffer){memcpy(IlllI->transfer_buffer,lllll,IlIII);}else{return-
EINVAL;}return IlIII;}





int IIIIlIIIl(void*lllll,struct urb*IlllI,int IlIII){
if(IlIII==(0x1d32+43-0x1d5d)){return(0x1444+1264-0x1934);}
#if KERNEL_LT_EQ((0x720+5438-0x1c5c),(0x739+6711-0x216a),(0xfcb+5235-0x241c))
if(lIIlIlIl&&((IlllI->setup_packet==NULL)||(IlllI->transfer_flags&
URB_NO_SETUP_DMA_MAP))&&(IlllI->setup_dma!=(0x9ba+5022-0x1d58))&&(IlllI->
setup_dma!=~(dma_addr_t)(0xb11+6616-0x24e9))){lllIIllIl(lllll,IlllI->setup_dma,
IlIII);}else
#endif
if(IlllI->setup_packet){memcpy(lllll,IlllI->setup_packet,IlIII);}else{return-
EINVAL;}return IlIII;}





int lIIllIlll(struct urb*IlllI,void*lllll,int IlIII){
if(IlIII==(0x21c+4547-0x13df)){return(0x1099+3530-0x1e63);}
#if KERNEL_LT_EQ((0x1bf+3192-0xe35),(0x2c0+741-0x59f),(0x1fd2+1013-0x23a5))
if(lIIlIlIl&&((IlllI->setup_packet==NULL)||(IlllI->transfer_flags&
URB_NO_SETUP_DMA_MAP))&&(IlllI->setup_dma!=(0x469+3663-0x12b8))&&(IlllI->
setup_dma!=~(dma_addr_t)(0x199a+2536-0x2382))){lIIlIIlII(IlllI->setup_dma,lllll,
IlIII);}else
#endif
if(IlllI->setup_packet){memcpy(IlllI->setup_packet,lllll,IlIII);}else{return-
EINVAL;}return IlIII;}


static inline size_t lIlllllII(void*lllll,struct urb*IlllI){if(lIIlIlIl&&((IlllI
->transfer_buffer==NULL)||(IlllI->transfer_flags&URB_NO_TRANSFER_DMA_MAP))&&(
IlllI->transfer_dma!=(0x997+1220-0xe5b))&&(IlllI->transfer_dma!=~(dma_addr_t)
(0x1815+768-0x1b15))){int i;void*IIIlIIl=lllll;dma_addr_t lllIll;void*lIIlll;
unsigned long flags;unsigned long IIlllII,IIlIIl;unsigned long lIllllI,IlIIlIl,
lllIlll,lIIllIl;lllIlll=(0xabd+5398-0x1fd3);lIIlll=NULL;local_irq_save(flags);
for(i=(0x9f3+4252-0x1a8f);i<IlllI->number_of_packets;i++){IIlIIl=IlllI->
iso_frame_desc[i].length;lllIll=IlllI->transfer_dma+IlllI->iso_frame_desc[i].
offset;while(IIlIIl){lIIllIl=lllIll>>PAGE_SHIFT;if(lIIllIl!=lllIlll){if(lllIlll)
{
#if KERNEL_GT_EQ((0x8af+3365-0x15d2),(0x789+1990-0xf49),(0x1f59+1166-0x23c2))
kunmap_atomic(lIIlll);
#else
kunmap_atomic(lIIlll,KM_IRQ0);
#endif
}lllIlll=lIIllIl;
#if KERNEL_GT_EQ((0x7af+5434-0x1ce7),(0x1a68+839-0x1da9),(0x11a1+2865-0x1cad))
lIIlll=kmap_atomic(pfn_to_page(lIIllIl));
#else
lIIlll=kmap_atomic(pfn_to_page(lIIllIl),KM_IRQ0);
#endif
}lIllllI=lllIll&(PAGE_SIZE-(0x87+1949-0x823));IlIIlIl=PAGE_SIZE-lIllllI;IIlllII=
(IlIIlIl<IIlIIl)?IlIIlIl:IIlIIl;memcpy(IIIlIIl,lIIlll+lIllllI,IIlllII);lllIll+=
IIlllII;IIIlIIl+=IIlllII;IIlIIl-=IIlllII;}}if(lllIlll){
#if KERNEL_GT_EQ((0x122b+1597-0x1866),(0x158d+2072-0x1d9f),(0x13d1+4889-0x26c5))
kunmap_atomic(lIIlll);
#else
kunmap_atomic(lIIlll,KM_IRQ0);
#endif
}local_irq_restore(flags);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x70\x61\x63\x6b\x5f\x69\x73\x6f\x63\x68\x5f\x62\x75\x66\x3a\x20\x70\x61\x63\x6b\x65\x64\x3d\x25\x6c\x75" "\n"
,(unsigned long)(IIIlIIl-lllll));return(size_t)(IIIlIIl-lllll);}else if(IlllI->
transfer_buffer){return IIlIIlIl(IlllI->iso_frame_desc,IlllI->number_of_packets,
lllll,IlllI->transfer_buffer,(0x331+5820-0x19ed));}Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x70\x61\x63\x6b\x5f\x69\x73\x6f\x63\x68\x5f\x62\x75\x66\x3a\x20\x6e\x6f\x20\x62\x75\x66\x66\x65\x72" "\n"
);return(0x1442+4809-0x270b);}static inline size_t IIllIlIll(struct urb*IlllI,
void*lllll){if(lIIlIlIl&&((IlllI->transfer_buffer==NULL)||(IlllI->transfer_flags
&URB_NO_TRANSFER_DMA_MAP))&&(IlllI->transfer_dma!=(0xe90+746-0x117a))&&(IlllI->
transfer_dma!=~(dma_addr_t)(0x85d+5074-0x1c2f))){int i;void*lllIll=lllll;
dma_addr_t IIIlIIl;void*lIIlll;unsigned long flags;unsigned long IIlllII,IIlIIl;
unsigned long lIllllI,IlIIlIl,lllIlll,lIIllIl;lllIlll=(0x2cc+8684-0x24b8);lIIlll
=NULL;local_irq_save(flags);for(i=(0xf4f+3955-0x1ec2);i<IlllI->number_of_packets
;i++){IIlIIl=IlllI->iso_frame_desc[i].actual_length;IIIlIIl=IlllI->transfer_dma+
IlllI->iso_frame_desc[i].offset;while(IIlIIl){lIIllIl=IIIlIIl>>PAGE_SHIFT;if(
lIIllIl!=lllIlll){if(lllIlll){
#if KERNEL_GT_EQ((0x1655+2338-0x1f75),(0x146+2989-0xced),(0x187b+851-0x1ba9))
kunmap_atomic(lIIlll);
#else
kunmap_atomic(lIIlll,KM_IRQ0);
#endif
}lllIlll=lIIllIl;
#if KERNEL_GT_EQ((0x647+4718-0x18b3),(0x1f27+1577-0x254a),(0xa2+3741-0xf1a))
lIIlll=kmap_atomic(pfn_to_page(lIIllIl));
#else
lIIlll=kmap_atomic(pfn_to_page(lIIllIl),KM_IRQ0);
#endif
}lIllllI=IIIlIIl&(PAGE_SIZE-(0xeef+5773-0x257b));IlIIlIl=PAGE_SIZE-lIllllI;
IIlllII=(IlIIlIl<IIlIIl)?IlIIlIl:IIlIIl;memcpy(lIIlll+lIllllI,lllIll,IIlllII);
lllIll+=IIlllII;IIIlIIl+=IIlllII;IIlIIl-=IIlllII;}}if(lllIlll){
#if KERNEL_GT_EQ((0x90+4914-0x13c0),(0xc+1949-0x7a3),(0x18ab+2230-0x213c))
kunmap_atomic(lIIlll);
#else
kunmap_atomic(lIIlll,KM_IRQ0);
#endif
}local_irq_restore(flags);Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x69\x73\x6f\x63\x68\x5f\x62\x75\x66\x3a\x20\x70\x61\x63\x6b\x65\x64\x3d\x25\x6c\x75" "\n"
,(unsigned long)(lllIll-lllll));return(size_t)(lllIll-lllll);}else if(IlllI->
transfer_buffer){return llIIIlIII(IlllI,lllll);}Illll(
"\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x69\x73\x6f\x63\x68\x5f\x62\x75\x66\x3a\x20\x6e\x6f\x20\x62\x75\x66\x66\x65\x72" "\n"
);return(0x1a37+1581-0x2064);}
#else 

static inline int IIlIlIIl(struct urb*IlllI,void*lllll,int IlIII){if(!IlIII){
return(0x19b0+786-0x1cc2);}if(!IlllI->transfer_buffer){return-EINVAL;}memcpy(
IlllI->transfer_buffer,lllll,IlIII);return IlIII;}static inline int lllIlIII(
void*lllll,struct urb*IlllI,int IlIII){if(!IlIII){return(0x428+950-0x7de);}if(!
IlllI->transfer_buffer){return-EINVAL;}memcpy(lllll,IlllI->transfer_buffer,IlIII
);return IlIII;}static inline int lIIllIlll(struct urb*IlllI,void*lllll,int 
IlIII){if(!IlIII){return(0x1f43+534-0x2159);}if(!IlllI->setup_packet){return-
EINVAL;}memcpy(IlllI->setup_packet,lllll,IlIII);return IlIII;}static inline int 
IIIIlIIIl(void*lllll,struct urb*IlllI,int IlIII){if(!IlIII){return
(0x177b+1226-0x1c45);}if(!IlllI->setup_packet){return-EINVAL;}memcpy(lllll,IlllI
->setup_packet,IlIII);return IlIII;}static inline size_t lIlllllII(void*lllll,
struct urb*IlllI){if(!IlllI->transfer_buffer){return(0x15e0+3800-0x24b8);}return
 IIlIIlIl(IlllI->iso_frame_desc,IlllI->number_of_packets,lllll,IlllI->
transfer_buffer,(0xc6c+123-0xce7));}

static inline size_t IIllIlIll(struct urb*IlllI,void*lllll){return llIIIlIII(
IlllI,lllll);}
#endif 




static inline int lllllIIlll(struct list_head*IIlIllI,IlIIlI lllIl,void*lllll,
size_t IlIIIl){int IIIll=(0xf53+3655-0x1d9a);int IIIlIll=sizeof(lllIllIll);IIlIl
 IlIlI=lllll;struct llIIlll*llIIll;IlIlI->lllII.IIllll=lllIl;IlIlI->lllII.
lIIIlll=(0x3a2+2011-0xb7d);IlIlI->lllII.IlIll=IIIlIll;IlIlI->lllII.IIIIIIl=
IIlIlllI;IlIlI->lllII.Status=(0x223+7951-0x2132);IlIlI->lllII.Context=
(0x11ac+2052-0x19b0);if(IlIIIl<IlIlI->lllII.IlIll){return-EMSGSIZE;}llIIll=
list_entry(IIlIllI->prev,struct llIIlll,llIIII);IlIlI->llIll.IIllI=
(0x5dc+3693-0x1449);IlIlI->llIll.Endpoint=usb_pipeendpoint(llIIll->IlllI->pipe);
IlIlI->llIll.Flags=usb_pipein(llIIll->IlllI->pipe)?IIIllI:(0xd7d+3635-0x1bb0);
if(usb_pipein(llIIll->IlllI->pipe)&&!(llIIll->IlllI->transfer_flags&
URB_SHORT_NOT_OK)){IlIlI->llIll.Flags|=lIIIIlI;}


list_for_each_entry(llIIll,IIlIllI,llIIII){if(usb_pipeout(llIIll->IlllI->pipe)){
if(IlIIIl>=(IlIlI->lllII.IlIll+llIIll->IlllI->transfer_buffer_length)){if(
lllIlIII((char*)lllll+IlIlI->lllII.IlIll,llIIll->IlllI,llIIll->IlllI->
transfer_buffer_length)<(0xd12+6650-0x270c)){return-EINVAL;}
#if (0x295+9008-0x25c5)

lllIlIlIl("\x53\x45\x4e\x44\x3a",(char*)lllll+IlIlI->lllII.IlIll,llIIll->IlllI->
transfer_buffer_length);
#endif
}IlIlI->lllII.IlIll+=llIIll->IlllI->transfer_buffer_length;}IlIlI->llIll.IIllI+=
llIIll->IlllI->transfer_buffer_length;}if(IlIIIl<IlIlI->lllII.IlIll){return-
EMSGSIZE;}return IIIll;}static inline int IlllIlIIl(struct urb*IlllI,IlIIlI 
lllIl,void*lllll,size_t IlIIIl){int IIIll=(0x15c2+3315-0x22b5);int IIIlIll=
sizeof(lIllIlIll);IIlIl IlIlI=lllll;IlIlI->lllII.IIllll=lllIl;IlIlI->lllII.
lIIIlll=(0x1278+355-0x13db);IlIlI->lllII.IlIll=IIIlIll;IlIlI->lllII.IIIIIIl=
llIIlIII;IlIlI->lllII.Status=(0x1930+3172-0x2594);IlIlI->lllII.Context=
(0xafa+5109-0x1eef);if(IlIIIl<IlIlI->lllII.IlIll){return-EMSGSIZE;}IlIlI->llIIlI
.IIllI=IlllI->transfer_buffer_length;IlIlI->llIIlI.Interval=IlllI->interval;
IlIlI->llIIlI.Endpoint=usb_pipeendpoint(IlllI->pipe);IlIlI->llIIlI.Flags=
usb_pipein(IlllI->pipe)?IIIllI:(0x30c+8939-0x25f7);IlIlI->llIIlI.Flags|=(IlllI->
transfer_flags&URB_SHORT_NOT_OK)?(0x171f+1693-0x1dbc):lIIIIlI;if(usb_pipeout(
IlllI->pipe)){if(IlIIIl>=(IlIlI->lllII.IlIll+IlllI->transfer_buffer_length)){if(
lllIlIII((char*)lllll+IlIlI->lllII.IlIll,IlllI,IlllI->transfer_buffer_length)<
(0xbf3+1984-0x13b3)){return-EINVAL;}}IlIlI->lllII.IlIll+=IlllI->
transfer_buffer_length;}if(IlIIIl<IlIlI->lllII.IlIll){return-EMSGSIZE;}return 
IIIll;}static inline int llllIIlllI(struct urb*IlllI,IlIIlI lllIl,void*lllll,
size_t IlIIIl){int IIIll=(0xbe9+2075-0x1404);IIlIl IlIlI=lllll;int i;int IIIlIll
=sizeof(IlIIIllll)-sizeof(IllllIlI)+sizeof(IllllIlI)*IlllI->number_of_packets;
IlIlI->lllII.IIllll=lllIl;IlIlI->lllII.lIIIlll=(0x3d0+7497-0x2119);IlIlI->lllII.
IlIll=IIIlIll;IlIlI->lllII.IIIIIIl=IIIlIIII;IlIlI->lllII.Status=
(0x304+7232-0x1f44);IlIlI->lllII.Context=(0x43b+157-0x4d8);if(IlIIIl<IlIlI->
lllII.IlIll){return-EMSGSIZE;}IlIlI->llIIl.Endpoint=usb_pipeendpoint(IlllI->pipe
);IlIlI->llIIl.Flags=usb_pipein(IlllI->pipe)?IIIllI:(0x6af+8116-0x2663);IlIlI->
llIIl.Flags|=(IlllI->transfer_flags&URB_SHORT_NOT_OK)?(0xbff+1743-0x12ce):
lIIIIlI;


























IlIlI->llIIl.Flags|=lIlIIllII;
IlIlI->llIIl.IIllI=IlllI->transfer_buffer_length;IlIlI->llIIl.Interval=IlllI->
interval;IlIlI->llIIl.llIIIIIl=(0x14aa+4680-0x26f2);
IlIlI->llIIl.IIllllIl=(0xc70+4035-0x1c33);IlIlI->llIIl.llIIIIl=IlllI->
number_of_packets;for(i=(0x126d+4430-0x23bb);i<IlllI->number_of_packets;i++){
IlIlI->llIIl.llIIIlI[i].Offset=IlllI->iso_frame_desc[i].offset;IlIlI->llIIl.
llIIIlI[i].Length=IlllI->iso_frame_desc[i].length;IlIlI->llIIl.llIIIlI[i].Status
=(0x18a9+2273-0x218a);}if(usb_pipeout(IlllI->pipe)){if(IlIIIl>=(IlIlI->lllII.
IlIll+IlllI->transfer_buffer_length)){IlIlI->lllII.IlIll+=lIlllllII((char*)lllll
+IlIlI->lllII.IlIll,IlllI);}else{
IlIlI->lllII.IlIll+=IlllI->transfer_buffer_length;}}if(IlIIIl<IlIlI->lllII.IlIll
){return-EMSGSIZE;}return IIIll;}static inline int IIIIIIlIIl(struct urb*IlllI,
IlIIlI lllIl,struct usb_ctrlrequest*llllIIl,void*lllll,size_t IlIIIl){int IIIll=
(0xd15+3572-0x1b09);IIlIl IlIlI=lllll;int IIIlIll=sizeof(lIllIIIll);IlIlI->lllII
.IIllll=lllIl;IlIlI->lllII.lIIIlll=(0x68c+3761-0x153d);IlIlI->lllII.IlIll=
IIIlIll;IlIlI->lllII.IIIIIIl=lllllIlI;IlIlI->lllII.Status=(0x1ab+179-0x25e);
IlIlI->lllII.Context=(0xa59+4838-0x1d3f);if(IlIIIl<IlIlI->lllII.IlIll){return-
EMSGSIZE;}IlIlI->IIllIl.Endpoint=usb_pipeendpoint(IlllI->pipe);IlIlI->IIllIl.
Flags=usb_pipein(IlllI->pipe)?IIIllI:(0x1515+282-0x162f);if(usb_pipein(IlllI->
pipe)){IlIlI->IIllIl.Flags|=(IlllI->transfer_flags&URB_SHORT_NOT_OK)?
(0x11f3+2919-0x1d5a):lIIIIlI;}IlIlI->IIllIl.llIIIII=llllIIl->bRequestType;IlIlI
->IIllIl.lIlllIIIl=llllIIl->bRequest;IlIlI->IIllIl.llIlIIII=le16_to_cpu(llllIIl
->wValue);IlIlI->IIllIl.IlllIllIl=le16_to_cpu(llllIIl->wIndex);IlIlI->IIllIl.
IIllI=IlllI->transfer_buffer_length;if(usb_pipeout(IlllI->pipe)){if(IlIIIl>=(
IlIlI->lllII.IlIll+IlllI->transfer_buffer_length)){if(lllIlIII((char*)lllll+
IIIlIll,IlllI,IlllI->transfer_buffer_length)<(0x38+7823-0x1ec7)){return-EINVAL;}
}IlIlI->lllII.IlIll+=IlllI->transfer_buffer_length;}if(IlIIIl<IlIlI->lllII.IlIll
){return-EMSGSIZE;}return IIIll;}static inline int lIIIIllII(struct urb*IlllI,
IlIIlI lllIl,struct usb_ctrlrequest*llllIIl,int IIIllIll,void*lllll,size_t 
IlIIIl){int IIIll=(0x9f7+4240-0x1a87);IIlIl IlIlI=lllll;int IIIlIll=sizeof(
IIIllIIll);IlIlI->lllII.IIllll=lllIl;IlIlI->lllII.lIIIlll=(0x13f2+4645-0x2617);
IlIlI->lllII.IlIll=IIIlIll;IlIlI->lllII.IIIIIIl=IIIllIll?lllllIIl:IIlIIIll;IlIlI
->lllII.Status=(0x31d+7645-0x20fa);IlIlI->lllII.Context=(0x11c0+3059-0x1db3);if(
IlIIIl<IlIlI->lllII.IlIll){return-EMSGSIZE;}IlIlI->IIlllI.IIllIlIl=le16_to_cpu(
llllIIl->wIndex);IlIlI->IIlllI.IIllI=IlllI->transfer_buffer_length;IlIlI->IIlllI
.lIIlllll=(le16_to_cpu(llllIIl->wValue)>>(0x148+6770-0x1bb2))&
(0x48b+4312-0x1464);IlIlI->IIlllI.IllIIlll=le16_to_cpu(llllIIl->wValue)&
(0x4a4+1463-0x95c);switch(llllIIl->bRequestType&USB_TYPE_MASK){case 
USB_TYPE_STANDARD:IlIlI->IIlllI.llIIIII=IlIIlllIlI;break;case USB_TYPE_CLASS:
IlIlI->IIlllI.llIIIII=IlIIIllIl;break;case USB_TYPE_VENDOR:IlIlI->IIlllI.llIIIII
=llIIIIIIl;break;case USB_TYPE_RESERVED:IlIlI->IIlllI.llIIIII=llllIIllI;break;
default:IlIlI->IIlllI.llIIIII=(0x14fc+4353-0x25fd);}switch(llllIIl->bRequestType
&USB_RECIP_MASK){case USB_RECIP_DEVICE:IlIlI->IIlllI.IIIIIllI=IIllIIlII;break;
case USB_RECIP_INTERFACE:IlIlI->IIlllI.IIIIIllI=llIIlIlIl;break;case 
USB_RECIP_ENDPOINT:IlIlI->IIlllI.IIIIIllI=lIIIlIIIl;break;case USB_RECIP_OTHER:
IlIlI->IIlllI.IIIIIllI=lIIIIIlIl;break;default:IlIlI->IIlllI.llIIIII=
(0xeab+1417-0x1434);}if(!IIIllIll){if(IlIIIl>=(IlIlI->lllII.IlIll+IlllI->
transfer_buffer_length)){if(lllIlIII((char*)lllll+IIIlIll,IlllI,IlllI->
transfer_buffer_length)<(0x1289+2161-0x1afa)){return-EINVAL;}}IlIlI->lllII.IlIll
+=IlllI->transfer_buffer_length;}if(IlIIIl<IlIlI->lllII.IlIll){return-EMSGSIZE;}
return IIIll;}static inline int lIIllllIl(struct urb*IlllI,IlIIlI lllIl,struct 
usb_ctrlrequest*llllIIl,void*lllll,size_t IlIIIl){int IIIll=(0x854+225-0x935);
IIlIl IlIlI=lllll;int lllIIllI=sizeof(IIIlIIlIl);IlIlI->lllII.IIllll=lllIl;IlIlI
->lllII.lIIIlll=(0x7cf+6746-0x2229);IlIlI->lllII.IlIll=lllIIllI;IlIlI->lllII.
IIIIIIl=IIIlIIIl;IlIlI->lllII.Status=(0xa8f+820-0xdc3);IlIlI->lllII.Context=
(0xee8+2276-0x17cc);if(IlIIIl<IlIlI->lllII.IlIll){return-EMSGSIZE;}IlIlI->
llIlllI.IlllIlI=(lIllIl)le16_to_cpu(llllIIl->wIndex);IlIlI->llIlllI.IllIIII=(
lIllIl)le16_to_cpu(llllIIl->wValue);return IIIll;}static inline int llllIlIlI(
struct urb*IlllI,IlIIlI lllIl,struct usb_ctrlrequest*llllIIl,void*lllll,size_t 
IlIIIl){int IIIll=(0x12e2+2073-0x1afb);IIlIl IlIlI=lllll;int lllIIllI=sizeof(
IllIIIIlI)-sizeof(IlIlI->IIIllll.lIlllll[(0x1674+3427-0x23d7)]);IlIlI->lllII.
IIllll=lllIl;IlIlI->lllII.lIIIlll=(0x1c0a+1465-0x21c3);IlIlI->lllII.IlIll=
lllIIllI;IlIlI->lllII.IIIIIIl=IlIIIIII;IlIlI->lllII.Status=(0x835+2775-0x130c);
IlIlI->lllII.Context=(0x5c1+7994-0x24fb);if(IlIIIl<IlIlI->lllII.IlIll){return-
EMSGSIZE;}IlIlI->IIIllll.lllIlIll=(lIllIl)le16_to_cpu(llllIIl->wValue);IlIlI->
IIIllll.IIIllIlI=(0x108c+2748-0x1b48);return IIIll;}static inline int IlIIlllll(
struct urb*IlllI,IlIIlI lllIl,struct usb_ctrlrequest*llllIIl,void*lllll,size_t 
IlIIIl){int IIIll=(0x185a+3627-0x2685);IIlIl IlIlI=lllll;int lllIIllI=sizeof(
IlIllllll);IlIlI->lllII.IIllll=lllIl;IlIlI->lllII.lIIIlll=(0x5fc+425-0x7a5);
IlIlI->lllII.IlIll=lllIIllI;IlIlI->lllII.IIIIIIl=IIIIIIll;IlIlI->lllII.Status=
(0x14aa+840-0x17f2);IlIlI->lllII.Context=(0x2a1+1430-0x837);if(IlIIIl<IlIlI->
lllII.IlIll){return-EMSGSIZE;}IlIlI->llIIlII.Endpoint=llllIIl->wIndex&
(0x694+2921-0x11ee);
IlIlI->llIIlII.Flags=(llllIIl->wIndex&USB_DIR_IN)?IIIllI:(0x16b6+809-0x19df);
return IIIll;}int IllIIlIll(struct list_head*IIlIllI,IlIIlI lllIl,void*lllll,
size_t IlIIIl){int IIIll=-EINVAL;do
{struct usb_ctrlrequest llIlll;struct urb*IlllI;struct llIIlll*llIIll;llIIll=
list_entry(IIlIllI->next,struct llIIlll,llIIII);IlllI=llIIll->IlllI;if(!IlllI){
Illll(
"\x75\x73\x62\x64\x5f\x70\x61\x63\x6b\x5f\x75\x72\x62\x5f\x6c\x69\x73\x74\x3a\x20\x70\x75\x72\x62\x20\x69\x73\x20\x6e\x75\x6c\x6c\x28\x30\x78\x25\x70\x29\x2c\x20\x70\x76\x75\x72\x62\x3d\x30\x78\x25\x70\x20\x70\x75\x72\x62\x5f\x6c\x69\x73\x74\x3d\x30\x78\x25\x70" "\n"
,IlllI,llIIll,IIlIllI);break;}switch(usb_pipetype(IlllI->pipe)){case PIPE_BULK:
IIIll=lllllIIlll(IIlIllI,lllIl,lllll,IlIIIl);break;case PIPE_INTERRUPT:IIIll=
IlllIlIIl(IlllI,lllIl,lllll,IlIIIl);break;case PIPE_ISOCHRONOUS:IIIll=llllIIlllI
(IlllI,lllIl,lllll,IlIIIl);break;case PIPE_CONTROL:IIIll=IIIIlIIIl(&llIlll,IlllI
,sizeof(llIlll));if(IIIll<(0x212+758-0x508)){break;}if(IIIll!=sizeof(llIlll)){
IIIll=-EINVAL;break;}if(llIlll.bRequestType==(USB_DIR_IN|USB_TYPE_STANDARD|
USB_RECIP_DEVICE)&&llIlll.bRequest==USB_REQ_GET_DESCRIPTOR){
IIIll=lIIIIllII(IlllI,lllIl,&llIlll,(0x11e1+3099-0x1dfb),lllll,IlIIIl);}else if(
llIlll.bRequestType==(USB_DIR_OUT|USB_TYPE_STANDARD|USB_RECIP_DEVICE)&&llIlll.
bRequest==USB_REQ_SET_DESCRIPTOR){
IIIll=lIIIIllII(IlllI,lllIl,&llIlll,(0xcdf+2689-0x1760),lllll,IlIIIl);}else if(
llIlll.bRequestType==(USB_DIR_OUT|USB_TYPE_STANDARD|USB_RECIP_DEVICE)&&llIlll.
bRequest==USB_REQ_SET_CONFIGURATION){
IIIll=llllIlIlI(IlllI,lllIl,&llIlll,lllll,IlIIIl);}else if(llIlll.bRequestType==
(USB_DIR_OUT|USB_TYPE_STANDARD|USB_RECIP_INTERFACE)&&llIlll.bRequest==
USB_REQ_SET_INTERFACE){
IIIll=lIIllllIl(IlllI,lllIl,&llIlll,lllll,IlIIIl);}else if(llIlll.bRequestType==
(USB_DIR_OUT|USB_TYPE_STANDARD|USB_RECIP_ENDPOINT)&&llIlll.bRequest==
USB_REQ_CLEAR_FEATURE&&llIlll.wValue==USB_ENDPOINT_HALT){
IIIll=IlIIlllll(IlllI,lllIl,&llIlll,lllll,IlIIIl);}else{
IIIll=IIIIIIlIIl(IlllI,lllIl,&llIlll,lllll,IlIIIl);}break;default:llIlII(
"\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x70\x69\x70\x65\x20\x74\x79\x70\x65\x20\x25\x64\x20\x69\x6e\x20\x75\x72\x62" "\n"
,usb_pipetype(IlllI->pipe));IIIll=-EINVAL;break;}}while((0x1185+2542-0x1b73));if
(IIIll<(0x234+9050-0x258e)&&IIIll!=-EMSGSIZE){llIlII(
"\x62\x72\x6f\x6b\x65\x6e\x20\x75\x72\x62\x20\x64\x65\x74\x65\x63\x74\x65\x64\x2c\x20\x65\x72\x72\x6f\x72\x20\x63\x6f\x64\x65\x20\x25\x64" "\n"
,IIIll);}return IIIll;}



static inline int IlIlllIll(IIlIl IlIlI,struct urb*IlllI,int IIIllIll){int IIIll
=(0x18c6+2188-0x2152);IlllI->actual_length=min_t(IIIIl,IlllI->
transfer_buffer_length,IlIlI->IIlllI.IIllI);if(IIIllIll){IIlIlIIl(IlllI,(char*)
IlIlI+sizeof(IlIlI->IIlllI),IlllI->actual_length);}return IIIll;}static inline 
int lIIlIlIlIl(IIlIl IlIlI,struct list_head*IIlIllI){int IIIll=
(0x12f+3333-0xe34);struct llIIlll*llIIll;unsigned long IIIlIllll;unsigned char*
lllll;IIIlIllll=IlIlI->llIll.IIllI;lllll=(unsigned char*)IlIlI+sizeof(IlIlI->
llIll);


list_for_each_entry(llIIll,IIlIllI,llIIII){llIIll->IlllI->actual_length=min_t(
unsigned long,llIIll->IlllI->transfer_buffer_length,IIIlIllll);if(usb_pipein(
llIIll->IlllI->pipe)){Illll(
"\x75\x73\x62\x64\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x75\x72\x62\x5f\x62\x75\x6c\x6b\x3a\x20\x63\x6f\x70\x79\x20\x25\x64\x20\x62\x79\x74\x65\x73\x20\x74\x6f\x20\x75\x72\x62\x20\x25\x70" "\n"
,llIIll->IlllI->actual_length,llIIll->IlllI);IIlIlIIl(llIIll->IlllI,lllll,llIIll
->IlllI->actual_length);
#if (0x324+3562-0x110e)

lllIlIlIl("\x52\x45\x43\x56\x3a",lllll,llIIll->IlllI->actual_length);
#endif
}IIIlIllll-=llIIll->IlllI->actual_length;lllll+=llIIll->IlllI->actual_length;}
return IIIll;}static inline int IIIIlllllI(IIlIl IlIlI,struct urb*IlllI){int i;
int IIIll=(0xea5+838-0x11eb);lIllIl*IIllllIlII=(lIllIl*)IlIlI+IIIllllI(IlIlI);if
(IlIlI->llIIl.llIIIIl!=IlllI->number_of_packets){return-EINVAL;}IlllI->
start_frame=IlIlI->llIIl.llIIIIIl;IlllI->error_count=IlIlI->llIIl.IIllllIl;IlllI
->actual_length=(0x60+2431-0x9df);for(i=(0x1c83+2680-0x26fb);i<IlllI->
number_of_packets;i++){IlllI->iso_frame_desc[i].status=lIIlIlll(IlIlI->llIIl.
llIIIlI[i].Status);IlllI->iso_frame_desc[i].actual_length=IlIlI->llIIl.llIIIlI[i
].Length;IlllI->actual_length+=IlllI->iso_frame_desc[i].actual_length;}if(
usb_pipein(IlllI->pipe)){IIllIlIll(IlllI,IIllllIlII);}return IIIll;}static 
inline int lIIllIIIIl(IIlIl IlIlI,struct urb*IlllI){int IIIll=
(0x11d6+639-0x1455);IlllI->actual_length=min_t(IIIIl,IlllI->
transfer_buffer_length,IlIlI->IIllIl.IIllI);if(usb_pipein(IlllI->pipe)){IIlIlIIl
(IlllI,(char*)IlIlI+sizeof(IlIlI->IIllIl),IlllI->actual_length);}return IIIll;}
static inline int IlIlIlllll(IIlIl IlIlI,struct urb*IlllI){int IIIll=
(0x108b+1774-0x1779);IlllI->actual_length=min_t(IIIIl,IlllI->
transfer_buffer_length,IlIlI->llIIlI.IIllI);if(usb_pipein(IlllI->pipe)){IIlIlIIl
(IlllI,(char*)IlIlI+sizeof(IlIlI->llIIlI),IlllI->actual_length);}return IIIll;}
int IIIlIIIlI(IIlIl IlIlI,struct list_head*IIlIllI,int*status){int IIIll=
(0x132+920-0x4ca);struct llIIlll*llIIll=list_entry(IIlIllI->next,struct llIIlll,
llIIII);struct urb*IlllI=llIIll->IlllI;*status=lIIlIlll(IlIlI->lllII.Status);
switch(IlIlI->lllII.IIIIIIl){case lllllIIl:Illll(
"\x75\x73\x62\x64\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x75\x72\x62\x3a\x20\x47\x65\x74\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72" "\n"
);IIIll=IlIlllIll(IlIlI,IlllI,(0xb83+1905-0x12f3));break;case IIlIIIll:Illll(
"\x75\x73\x62\x64\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x75\x72\x62\x3a\x20\x53\x65\x74\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72" "\n"
);IIIll=IlIlllIll(IlIlI,IlllI,(0x9e9+4672-0x1c29));break;case IlIIIIII:Illll(
"\x75\x73\x62\x64\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x75\x72\x62\x3a\x20\x53\x65\x6c\x65\x63\x74\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e" "\n"
);IIIll=(0x647+4302-0x1715);break;case IIIlIIIl:Illll(
"\x75\x73\x62\x64\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x75\x72\x62\x3a\x20\x53\x65\x6c\x65\x63\x74\x49\x6e\x74\x65\x72\x66\x61\x63\x65" "\n"
);IIIll=(0x1aa+749-0x497);break;case lllllIlI:Illll(
"\x75\x73\x62\x64\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x75\x72\x62\x3a\x20\x43\x6f\x6e\x74\x72\x6f\x6c\x54\x72\x61\x6e\x73\x66\x65\x72" "\n"
);IIIll=lIIllIIIIl(IlIlI,IlllI);break;case IIlIlllI:Illll(
"\x75\x73\x62\x64\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x75\x72\x62\x3a\x20\x42\x75\x6c\x6b\x54\x72\x61\x6e\x73\x66\x65\x72" "\n"
);IIIll=lIIlIlIlIl(IlIlI,IIlIllI);break;case IIIlIIII:Illll(
"\x75\x73\x62\x64\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x75\x72\x62\x3a\x20\x49\x73\x6f\x63\x68\x54\x72\x61\x6e\x73\x66\x65\x72" "\n"
);IIIll=IIIIlllllI(IlIlI,IlllI);break;case llIIlIII:Illll(
"\x75\x73\x62\x64\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x75\x72\x62\x3a\x20\x49\x6e\x74\x65\x72\x72\x75\x70\x74\x54\x72\x61\x6e\x73\x66\x65\x72" "\n"
);IIIll=IlIlIlllll(IlIlI,IlllI);break;case IIIIIIll:Illll(
"\x75\x73\x62\x64\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x75\x72\x62\x3a\x20\x43\x6c\x65\x61\x72\x53\x74\x61\x6c\x6c" "\n"
);IIIll=(0x1c46+261-0x1d4b);break;case IIIlllII:Illll(
"\x75\x73\x62\x64\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x75\x72\x62\x3a\x20\x52\x65\x73\x65\x74\x50\x6f\x72\x74" "\n"
);IIIll=(0xe07+4093-0x1e04);break;default:Illll(
"\x75\x73\x62\x64\x5f\x75\x6e\x70\x61\x63\x6b\x5f\x75\x72\x62\x3a\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e" "\n"
);IIIll=-EINVAL;break;}return IIIll;}void IIlllIlIl(struct lIlIIl*lIIII,IIIIl*
busnum,IIIIl*devnum){if(busnum){*busnum=lIIII->parent->self.busnum;}
if(devnum){*devnum=lIIII->lllIIlI;}}
























































void IlIIllI(struct lIIIII*llllI,int lIllI,int llllII,int lIlIIIl){
switch(llllII){case IIlIIllI:case IlIlIIII:case llIllllI:lIlIIll(llllI,lIllI,
llIIllII);break;case IIllIllI:lIlIIll(llllI,lIllI,llIIllII);break;case lIllllIl:
llllI->lIIlIII[lIllI]&=~USB_PORT_STAT_C_CONNECTION;break;case lIlIIlIII:llllI->
lIIlIII[lIllI]&=~USB_PORT_STAT_C_ENABLE;break;case lIllIIlII:llllI->lIIlIII[
lIllI]&=~USB_PORT_STAT_C_SUSPEND;break;case llIllIll:llllI->lIIlIII[lIllI]&=~
USB_PORT_STAT_C_RESET;break;}
switch(llllI->lIlIIIlI[lIllI]){case llIIllII:if(llllII==IIlIlIII){lIlIIll(llllI,
lIllI,lIlIlII);}break;case lIlIlII:if(llllII==IIIIlIIl){lIlIIll(llllI,lIllI,
lIIIlIl);}break;case lIIIlIl:if(llllII==llIlIllI){lIlIIll(llllI,lIllI,lIlIlII);}
if(llllII==IIIIIIIl){lIlIIll(llllI,lIllI,IIllllI);}break;case IIllllI:if(llllII
==llIlIllI){lIlIIll(llllI,lIllI,lIlIlII);}if(llllII==IIllIIIl){lIlIIll(llllI,
lIllI,lIIIlIl);}if(llllII==lIIIlllI){lIlIIll(llllI,lIllI,IIlIIlll);}break;case 
IIlIIlll:if(llllII==llIlIllI){lIlIIll(llllI,lIllI,lIlIlII);}if(llllII==IIllIIIl)
{lIlIIll(llllI,lIllI,lIIIlIl);}if(llllII==IIIIIIIl){lIlIIll(llllI,lIllI,IIllllI)
;}if(llllII==IlllIIIIl){lIlIIll(llllI,lIllI,llIIlllll);}break;case llIIlllll:if(
llllII==llIlIllI){lIlIIll(llllI,lIllI,lIlIlII);}if(llllII==IIllIIIl){lIlIIll(
llllI,lIllI,lIIIlIl);}if(llllII==IIIIIIIl){lIlIIll(llllI,lIllI,IIllllI);}if(
llllII==lllIIIIlI||llllII==lIllIllIl){lIlIIll(llllI,lIllI,lIIIlIll);}break;case 
lIIIlIll:if(llllII==llIlIllI){lIlIIll(llllI,lIllI,lIlIlII);}if(llllII==IIllIIIl)
{lIlIIll(llllI,lIllI,lIIIlIl);}if(llllII==IIIIIIIl){lIlIIll(llllI,lIllI,IIllllI)
;}if(llllII==lIIIlllI){lIlIIll(llllI,lIllI,IIlIIlll);}break;}}static inline int 
IllllllIl(int speed){switch(speed){case USB_SPEED_HIGH:return 
USB_PORT_STAT_HIGH_SPEED;case USB_SPEED_LOW:return USB_PORT_STAT_LOW_SPEED;case 
USB_SPEED_FULL:return(0x44a+281-0x563);}return(0x16f1+2481-0x20a2);}
void lIlIIll(struct lIIIII*llllI,int lIllI,int IIIlIIll){
int IIIllIII=llllI->lIlIIIlI[lIllI];if(IIIlIIll==IIIllIII){return;}llllI->
lIlIIIlI[lIllI]=IIIlIIll;llllI->llIlIII[lIllI]=(0x21+4829-0x12fe);if(IIIllIII==
IIllllI){llllI->lIIlIII[lIllI]|=USB_PORT_STAT_C_RESET;}if(IIIllIII==lIIIlIll){
llllI->lIIlIII[lIllI]|=USB_PORT_STAT_C_SUSPEND;}switch(IIIlIIll){case llIIllII:
llllI->IIlllIl[lIllI]=(0x297+2128-0xae7);llllI->lIIlIII[lIllI]=
(0x2eb+7216-0x1f1b);
break;case lIlIlII:llllI->IIlllIl[lIllI]=USB_PORT_STAT_POWER;if(IIIllIII!=
llIIllII){llllI->lIIlIII[lIllI]|=USB_PORT_STAT_C_CONNECTION;}
if(llllI->lllllIl[lIllI]){lIlIIll(llllI,lIllI,lIIIlIl);}break;case lIIIlIl:llllI
->IIlllIl[lIllI]=USB_PORT_STAT_POWER|USB_PORT_STAT_CONNECTION;if(IIIllIII==
lIlIlII){llllI->lIIlIII[lIllI]|=USB_PORT_STAT_C_CONNECTION;}break;case IIllllI:
llllI->IIlllIl[lIllI]=USB_PORT_STAT_POWER|USB_PORT_STAT_CONNECTION|
USB_PORT_STAT_RESET;
llllI->llIlIII[lIllI]=jiffies+msecs_to_jiffies((0xcb9+713-0xf50));
llllI->llIlIII[lIllI]+=llllI->llIlIII[lIllI]?(0x337+5255-0x17be):
(0x5ea+6075-0x1da4);break;case IIlIIlll:llllI->IIlllIl[lIllI]=
USB_PORT_STAT_POWER|USB_PORT_STAT_CONNECTION|USB_PORT_STAT_ENABLE|IllllllIl(
llllI->lllllIl[lIllI]->speed);break;case llIIlllll:llllI->IIlllIl[lIllI]=
USB_PORT_STAT_POWER|USB_PORT_STAT_CONNECTION|USB_PORT_STAT_ENABLE|
USB_PORT_STAT_SUSPEND|IllllllIl(llllI->lllllIl[lIllI]->speed);break;case 
lIIIlIll:llllI->IIlllIl[lIllI]=USB_PORT_STAT_POWER|USB_PORT_STAT_CONNECTION|
USB_PORT_STAT_ENABLE|USB_PORT_STAT_SUSPEND|IllllllIl(llllI->lllllIl[lIllI]->
speed);
llllI->llIlIII[lIllI]=jiffies+msecs_to_jiffies((0x1b27+2883-0x2656));
llllI->llIlIII[lIllI]+=llllI->llIlIII[lIllI]?(0x1929+151-0x19c0):
(0x7b3+6322-0x2064);break;default:llIlII(
"\x69\x6e\x76\x61\x6c\x69\x64\x20\x6e\x65\x77\x20\x70\x6f\x72\x74\x20\x73\x74\x61\x74\x65" "\n"
);break;}}
#if KERNEL_GT_EQ((0xd4+970-0x49c),(0xb71+2353-0x149c),(0x27+8504-0x2138)) || \
RHEL_RELEASE_GT_EQ((0x112b+4442-0x227f),(0x1371+1263-0x185d)) 

























void llllllI(struct lIIIII*llllI,int lIllI,int llllII,int lIlIIIl){
switch(llllII){case IIlIIllI:case llIllllI:IlllIII(llllI,lIllI,llIIllII);return;
case lIllllIl:llllI->lIIlIII[lIllI]&=~USB_PORT_STAT_C_CONNECTION;return;case 
llIllIll:llllI->lIIlIII[lIllI]&=~USB_PORT_STAT_C_RESET;return;case llllIIlIl:
llllI->lIIlIII[lIllI]&=~USB_PORT_STAT_C_BH_RESET;return;case llIIllIlI:llllI->
lIIlIII[lIllI]&=~USB_PORT_STAT_C_LINK_STATE;return;case lIllIIlI:if(lIlIIIl==
(0xfea+4537-0x219f)){
IlllIII(llllI,lIllI,lIIIlIl);return;}break;}
switch(llllI->lIlIIIlI[lIllI]){case llIIllII:if(llllII==IlIlIIII){IlllIII(llllI,
lIllI,lIlIlII);}break;case IIIIlIll:if(llllII==IIlIlIII){IlllIII(llllI,lIllI,
lIlIlII);}if(llllII==IIIIIIIl){IlllIII(llllI,lIllI,IIllllI);}break;case lIlIlII:
if(llllII==IIllIllI){IlllIII(llllI,lIllI,IIIIlIll);}if(llllII==IIIIlIIl){IlllIII
(llllI,lIllI,IIlIIlll);}break;case lIIIlIl:if(llllII==IIllIllI){IlllIII(llllI,
lIllI,IIIIlIll);}if(llllII==IIIIIIIl){IlllIII(llllI,lIllI,IIllllI);}if(llllII==
lIllIIlI&&lIlIIIl==(0x441+6090-0x1c06)){


IlllIII(llllI,lIllI,lIlIlII);}break;case IIlIIlll:if(llllII==IIllIllI){IlllIII(
llllI,lIllI,IIIIlIll);}if(llllII==llIlIllI){IlllIII(llllI,lIllI,lIlIlII);}if(
llllII==IIIIIIIl){IlllIII(llllI,lIllI,IIllllI);}if(llllII==lIllIIlI&&lIlIIIl==
(0x4db+5837-0x1ba8)){
if(llllI->IllIIIl[lIllI]==USB_SS_PORT_LS_U3){

llllI->lIIlIII[lIllI]|=USB_PORT_STAT_C_LINK_STATE;}lIlIlIl(llllI,lIllI,
USB_SS_PORT_LS_U0);}if(llllII==lIllIIlI&&lIlIIIl==(0x52c+0-0x52b)){

if(llllI->IllIIIl[lIllI]==USB_SS_PORT_LS_U0){lIlIlIl(llllI,lIllI,
USB_SS_PORT_LS_U1);}}if(llllII==lIllIIlI&&lIlIIIl==(0x263+1157-0x6e6)){

if(llllI->IllIIIl[lIllI]==USB_SS_PORT_LS_U0){lIlIlIl(llllI,lIllI,
USB_SS_PORT_LS_U2);}}if(llllII==lIllIIlI&&lIlIIIl==(0xfe9+3133-0x1c23)){

if(llllI->IllIIIl[lIllI]==USB_SS_PORT_LS_U0||llllI->IllIIIl[lIllI]==
USB_SS_PORT_LS_U1||llllI->IllIIIl[lIllI]==USB_SS_PORT_LS_U2){

if(llllI->IllIIIl[lIllI]!=USB_SS_PORT_LS_U0){lIlIlIl(llllI,lIllI,
USB_SS_PORT_LS_U0);}lIlIlIl(llllI,lIllI,USB_SS_PORT_LS_U3);}}break;case IIllllI:
if(llllII==IIllIllI){IlllIII(llllI,lIllI,IIIIlIll);}if(llllII==llIlIllI){IlllIII
(llllI,lIllI,lIlIlII);}if(llllII==lIIIlllI){IlllIII(llllI,lIllI,IIlIIlll);}break
;}}static inline int IIIlIlIlI(int speed){switch(speed){case USB_SPEED_SUPER:
return USB_PORT_STAT_SPEED_5GBPS;default:return(0x6f1+5779-0x1d84);}return
(0x99d+1345-0xede);}
void IlllIII(struct lIIIII*llllI,int lIllI,int IIIlIIll){int IIIIlllll=llllI->
IIlllIl[lIllI];int IIIllIII=llllI->lIlIIIlI[lIllI];if(IIIlIIll==IIIllIII){return
;}llllI->lIlIIIlI[lIllI]=IIIlIIll;llllI->llIlIII[lIllI]=(0x124b+3545-0x2024);
switch(IIIlIIll){case llIIllII:lIlIlIl(llllI,lIllI,USB_SS_PORT_LS_SS_DISABLED);
llllI->IIlllIl[lIllI]=llllI->IllIIIl[lIllI];llllI->lIIlIII[lIllI]=
(0x16ef+612-0x1953);
break;case IIIIlIll:lIlIlIl(llllI,lIllI,USB_SS_PORT_LS_RX_DETECT);llllI->IIlllIl
[lIllI]=llllI->IllIIIl[lIllI];llllI->lIIlIII[lIllI]=(0x1ea8+1763-0x258b);
break;case lIIIlIl:lIlIlIl(llllI,lIllI,USB_SS_PORT_LS_SS_DISABLED);llllI->
IIlllIl[lIllI]=llllI->IllIIIl[lIllI]|USB_SS_PORT_STAT_POWER;if(IIIIlllll&
USB_PORT_STAT_CONNECTION){llllI->lIIlIII[lIllI]|=USB_PORT_STAT_C_CONNECTION;
}break;case lIlIlII:lIlIlIl(llllI,lIllI,USB_SS_PORT_LS_RX_DETECT);llllI->IIlllIl
[lIllI]=llllI->IllIIIl[lIllI]|USB_SS_PORT_STAT_POWER;if(IIIIlllll&
USB_PORT_STAT_CONNECTION){llllI->lIIlIII[lIllI]|=USB_PORT_STAT_C_CONNECTION;
}
if(llllI->lllllIl[lIllI]){IlllIII(llllI,lIllI,IIlIIlll);}break;case IIlIIlll:
lIlIlIl(llllI,lIllI,USB_SS_PORT_LS_U0);llllI->IIlllIl[lIllI]=llllI->IllIIIl[
lIllI]|USB_SS_PORT_STAT_POWER|USB_PORT_STAT_CONNECTION|USB_PORT_STAT_ENABLE|
IIIlIlIlI(llllI->lllllIl[lIllI]->speed);if(IIIllIII==IIllllI){llllI->lIIlIII[
lIllI]|=USB_PORT_STAT_C_RESET;
}if(IIIllIII==lIlIlII){llllI->lIIlIII[lIllI]|=USB_PORT_STAT_C_CONNECTION;
}break;case IIllllI:llllI->IIlllIl[lIllI]=llllI->IllIIIl[lIllI]|
USB_SS_PORT_STAT_POWER|USB_PORT_STAT_RESET|(IIIIlllll&USB_PORT_STAT_CONNECTION);

llllI->llIlIII[lIllI]=jiffies+msecs_to_jiffies((0x1b5f+770-0x1e2f));
llllI->llIlIII[lIllI]+=llllI->llIlIII[lIllI]?(0xd99+6294-0x262f):
(0x64b+8211-0x265d);break;default:Illll(
"\x69\x6e\x76\x61\x6c\x69\x64\x20\x70\x6f\x72\x74\x20\x73\x74\x61\x74\x65" "\n")
;break;}}
void lIlIlIl(struct lIIIII*llllI,int lIllI,int lIIIllIll){switch(lIIIllIll){case
 USB_SS_PORT_LS_U0:Illll(
"\x73\x65\x74\x5f\x6c\x69\x6e\x6b\x5f\x73\x74\x61\x74\x65\x20\x55\x53\x42\x5f\x53\x53\x5f\x50\x4f\x52\x54\x5f\x4c\x53\x5f\x55\x30" "\n"
);
llllI->IllIIIl[lIllI]=USB_SS_PORT_LS_U0;break;case USB_SS_PORT_LS_U1:Illll(
"\x73\x65\x74\x5f\x6c\x69\x6e\x6b\x5f\x73\x74\x61\x74\x65\x20\x55\x53\x42\x5f\x53\x53\x5f\x50\x4f\x52\x54\x5f\x4c\x53\x5f\x55\x31" "\n"
);
llllI->IllIIIl[lIllI]=USB_SS_PORT_LS_U1;break;case USB_SS_PORT_LS_U2:Illll(
"\x73\x65\x74\x5f\x6c\x69\x6e\x6b\x5f\x73\x74\x61\x74\x65\x20\x55\x53\x42\x5f\x53\x53\x5f\x50\x4f\x52\x54\x5f\x4c\x53\x5f\x55\x32" "\n"
);
llllI->IllIIIl[lIllI]=USB_SS_PORT_LS_U2;break;case USB_SS_PORT_LS_U3:Illll(
"\x73\x65\x74\x5f\x6c\x69\x6e\x6b\x5f\x73\x74\x61\x74\x65\x20\x55\x53\x42\x5f\x53\x53\x5f\x50\x4f\x52\x54\x5f\x4c\x53\x5f\x55\x33" "\n"
);
llllI->IllIIIl[lIllI]=USB_SS_PORT_LS_U3;break;case USB_SS_PORT_LS_SS_DISABLED:
Illll(
"\x73\x65\x74\x5f\x6c\x69\x6e\x6b\x5f\x73\x74\x61\x74\x65\x20\x55\x53\x42\x5f\x53\x53\x5f\x50\x4f\x52\x54\x5f\x4c\x53\x5f\x53\x53\x5f\x44\x49\x53\x41\x42\x4c\x45\x44" "\n"
);
llllI->IllIIIl[lIllI]=USB_SS_PORT_LS_SS_DISABLED;break;case 
USB_SS_PORT_LS_RX_DETECT:Illll(
"\x73\x65\x74\x5f\x6c\x69\x6e\x6b\x5f\x73\x74\x61\x74\x65\x20\x55\x53\x42\x5f\x53\x53\x5f\x50\x4f\x52\x54\x5f\x4c\x53\x5f\x52\x58\x5f\x44\x45\x54\x45\x43\x54" "\n"
);
llllI->IllIIIl[lIllI]=USB_SS_PORT_LS_RX_DETECT;break;}llllI->IIlllIl[lIllI]&=~
USB_PORT_STAT_LINK_STATE;llllI->IIlllIl[lIllI]|=llllI->IllIIIl[lIllI];}
#endif 
#endif 

