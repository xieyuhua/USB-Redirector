/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifdef _USBD_ENABLE_STUB_
#include "usbd.h"
#include "loader.h"
struct IIIlll*llIIIlII;struct list_head IlIllIll;struct mutex IllllllI;struct 
list_head IlllIIll;struct mutex IIlllIll;struct list_head lIIIIIIl;struct mutex 
IlllllIl;extern struct usb_driver lIIlllI;int IllllIll(struct usb_device*llIII){
IlllIl vid,lIllIIl,lIIlIIl;lIllIl class,lllIIIIll,llllIllIl;struct lIIIIIlI*
lIIll;int llIIllIII=(0x6b9+1074-0xaeb);int IIIIlIII=(0x1188+1123-0x15eb);const 
char*lllllI=NULL;const char*serial=NULL;const char*llIIllI=NULL;IIlll(
"\x2b\x2b" "\n");
if(strcmp(lIllIIll(llIII),llIllIl)==(0x887+2603-0x12b2)){IIlll(
"\x2d\x2d\x20\x73\x6b\x69\x70\x20\x6f\x75\x72\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x64\x65\x76\x69\x63\x65\x21" "\n"
);return(0xa06+4112-0x1a16);}vid=le16_to_cpu(llIII->descriptor.idVendor);lIllIIl
=le16_to_cpu(llIII->descriptor.idProduct);lIIlIIl=le16_to_cpu(llIII->descriptor.
bcdDevice);lIIlIIIlI(llIII,&class,&lllIIIIll,&llllIllIl);if(class==
(0x120c+2243-0x1ac6)){IIlll(
"\x2d\x2d\x20\x73\x6b\x69\x70\x20\x75\x73\x62\x20\x68\x75\x62\x21" "\n");return
(0x171+6076-0x192d);}if(IIllIIll(llIII,&lllllI,&serial,&llIIllI)){IIlll(
"\x2d\x2d\x20\x63\x61\x6e\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x69\x6e\x73\x74\x61\x6e\x63\x65\x69\x64\x21" "\n"
);return(0x21f+8544-0x237f);}IIlll(
"\x56\x3d\x25\x30\x34\x58\x20\x50\x3d\x25\x30\x34\x58\x20\x52\x3d\x25\x30\x34\x58\x20\x43\x3d\x25\x30\x32\x58\x20\x53\x3d\x25\x30\x32\x58\x20\x50\x3d\x25\x30\x32\x58\x20\x49\x44\x3d\x25\x73\x20\x53\x4e\x3d\x25\x73\x20\x49\x4e\x3d\x25\x73" "\n"
,vid,lIllIIl,lIIlIIl,class,lllIIIIll,llllIllIl,lllllI?lllllI:"\x6e\x6f\x6e\x65",
serial?serial:"\x6e\x6f\x6e\x65",llIIllI?llIIllI:"\x6e\x6f\x6e\x65");
mutex_lock(&IllllllI);list_for_each_entry(lIIll,&IlIllIll,entry){if(lIIll->lIIll
.lIlIllI&llIIlllII){if(lIIll->lIIll.IIIIIlIl!=vid){continue;}}if(lIIll->lIIll.
lIlIllI&lIlllIIII){if(lIIll->lIIll.lIIIllIl!=lIllIIl){continue;}}if(lIIll->lIIll
.lIlIllI&IIlIIlIIl){if(lIIll->lIIll.lIlIlIII!=lIIlIIl){continue;}}if(lIIll->
lIIll.lIlIllI&IlIlIlllII){if(lIIll->lIIll.llIIIIlI!=class){continue;}}if(lIIll->
lIIll.lIlIllI&IIlIIIlll){if(lIIll->lIIll.llIlllll!=lllIIIIll){continue;}}if(
lIIll->lIIll.lIlIllI&IlIIIIIIl){if(lIIll->lIIll.lllIlllI!=llllIllIl){continue;}}
if(lIIll->lIIll.lIlIllI&llIllllII){if(lllllI==NULL){continue;}if(strncmp((char*)
(&lIIll->lIIll+(0x199f+2348-0x22ca)),lllllI,lIIll->lIIll.IlllIIl)){continue;}}if
(lIIll->lIIll.lIlIllI&IlIIIIlll){if(serial==NULL){continue;}if(strncmp((char*)(&
lIIll->lIIll+(0x15b+6923-0x1c65))+lIIll->lIIll.IlllIIl,serial,lIIll->lIIll.
llIIlIll)){continue;}}if(lIIll->lIIll.lIlIllI&lIIIIlIlI){if(llIIllI==NULL){
continue;}IIlll(
"\x63\x68\x65\x63\x6b\x20\x69\x6e\x74\x73\x61\x6e\x63\x65\x20\x69\x64\x20\x25\x73\x20\x76\x73\x20\x25\x73" "\n"
,llIIllI,(char*)(&lIIll->lIIll+(0xc13+4603-0x1e0d))+lIIll->lIIll.IlllIIl+lIIll->
lIIll.llIIlIll);if(strncmp((char*)(&lIIll->lIIll+(0x47c+5327-0x194a))+lIIll->
lIIll.IlllIIl+lIIll->lIIll.llIIlIll,llIIllI,lIIll->lIIll.lIIIlIlI)){IIlll(
"\x6e\x6f\x74\x20\x6d\x61\x74\x63\x68\x65\x64\x20\x69\x6e\x74\x73\x61\x6e\x63\x65\x20\x69\x64" "\n"
);continue;}}if(lIIll->lIIll.lIlIllI&lIlIIlIll){IIIIlIII=(0x113+9423-0x25e1);
llIIllIII=(0x86c+3684-0x16cf);break;}if(lIIll->lIIll.lIlIllI&IllllllII){IIIIlIII
=(0x1281+4712-0x24e9);llIIllIII=(0x902+1845-0x1036);break;}}mutex_unlock(&
IllllllI);if(llIIllIII==(0x2026+1340-0x2562)){IIlll(
"\x2d\x2d\x20\x6e\x6f\x20\x6d\x61\x74\x63\x68" "\n");}else if(IIIIlIII){IIlll(
"\x2d\x2d\x20\x61\x6c\x6c\x6f\x77\x65\x64" "\n");}else{IIlll(
"\x2d\x2d\x20\x64\x65\x6e\x69\x65\x64" "\n");}return IIIIlIII;}void IllIIIIIl(
struct list_head*lIlllIII){struct list_head Illlll=LIST_HEAD_INIT(Illlll);

mutex_lock(&IllllllI);list_splice_init(&IlIllIll,&Illlll);list_splice_init(
lIlllIII,&IlIllIll);mutex_unlock(&IllllllI);
while(!list_empty(&Illlll)){struct lIIIIIlI*IIIlIII;IIIlIII=list_entry(Illlll.
next,struct lIIIIIlI,entry);list_del(&IIIlIII->entry);lIlIll(IIIlIII);}



}void llIllIlI(){struct list_head Illlll=LIST_HEAD_INIT(Illlll);
mutex_lock(&IllllllI);list_splice_init(&IlIllIll,&Illlll);mutex_unlock(&IllllllI
);
while(!list_empty(&Illlll)){struct lIIIIIlI*IIIlIII;IIIlIII=list_entry(Illlll.
next,struct lIIIIIlI,entry);list_del(&IIIlIII->entry);lIlIll(IIIlIII);}}IIIIl 
lIlllIlIl(struct usb_device*llIII){struct IllIIIll*IllIlIlI;IIIIl IlIlIII=
(0x9c3+2301-0x12c0);mutex_lock(&IlllllIl);list_for_each_entry(IllIlIlI,&lIIIIIIl
,entry){if(IllIlIlI->IIIIllI.IIIIIlIl!=le16_to_cpu(llIII->descriptor.idVendor)){
continue;}if(IllIlIlI->IIIIllI.lIIIllIl!=le16_to_cpu(llIII->descriptor.idProduct
)){continue;}IlIlIII=IllIlIlI->IIIIllI.IllIlIlII;break;}mutex_unlock(&IlllllIl);
return IlIlIII;}void IllIllIlI(struct list_head*IlllIIII){struct list_head 
Illlll=LIST_HEAD_INIT(Illlll);

mutex_lock(&IlllllIl);list_splice_init(&lIIIIIIl,&Illlll);list_splice_init(
IlllIIII,&lIIIIIIl);mutex_unlock(&IlllllIl);
while(!list_empty(&Illlll)){struct IllIIIll*IIIlIII;IIIlIII=list_entry(Illlll.
next,struct IllIIIll,entry);list_del(&IIIlIII->entry);lIlIll(IIIlIII);}}void 
IlIlIIllI(){struct list_head Illlll=LIST_HEAD_INIT(Illlll);
mutex_lock(&IlllllIl);list_splice_init(&lIIIIIIl,&Illlll);mutex_unlock(&IlllllIl
);
while(!list_empty(&Illlll)){struct IllIIIll*IIIlIII;IIIlIII=list_entry(Illlll.
next,struct IllIIIll,entry);list_del(&IIIlIII->entry);lIlIll(IIIlIII);}}



int IIllIIll(struct usb_device*lIIlI,const char**IIlIlllII,const char**IllllIIII
,const char**IIIlIIlll){struct IlIlIIIl*IlIlIl=NULL;struct IlIlIIIl*IlIIIllI;
mutex_lock(&IIlllIll);list_for_each_entry(IlIIIllI,&IlllIIll,entry){if(IlIIIllI
->llIII==lIIlI){IlIlIl=IlIIIllI;break;}}if(!IlIlIl){IlIlIl=lllIlII(sizeof(struct
 IlIlIIIl),GFP_KERNEL);if(!IlIlIl){mutex_unlock(&IIlllIll);return-ENOMEM;}IlIlIl
->llIII=usb_get_dev(lIIlI);IlIlIl->lllllI=llIIIl(&IlIlIl->llIII->dev);IlIlIl->
serial=lIIlI->serial;if(IlIlIl->serial&&*IlIlIl->serial&&(lIlllIlIl(lIIlI)&
IIIlIIIIII)==(0xf0d+2327-0x1824)){const char*IIIIlIlI=IlIlIl->serial;




while(*IIIIlIlI>'\x20'&&*IIIIlIlI<='\x7F'&&*IIIIlIlI!='\x2C'){IIIIlIlI++;}if(*
IIIIlIlI){
IlIlIl->llIIllI=IlIlIl->lllllI;}else{
IlIlIl->llIIllI=IlIlIl->serial;


list_for_each_entry(IlIIIllI,&IlllIIll,entry){if(IlIIIllI->llIII->serial&&
IlIIIllI->llIII->descriptor.idVendor==lIIlI->descriptor.idVendor&&IlIIIllI->
llIII->descriptor.idProduct==lIIlI->descriptor.idProduct&&strcmp(IlIIIllI->llIII
->serial,lIIlI->serial)==(0xe54+359-0xfbb)){
IlIlIl->llIIllI=IlIlIl->lllllI;break;}}}}else{
IlIlIl->llIIllI=IlIlIl->lllllI;}list_add_tail(&IlIlIl->entry,&IlllIIll);}


*IIlIlllII=IlIlIl->lllllI;*IllllIIII=IlIlIl->serial;*IIIlIIlll=IlIlIl->llIIllI;
mutex_unlock(&IIlllIll);return(0x326+2124-0xb72);}void IIIlIIllI(struct 
usb_device*llIII){struct IlIlIIIl*IlIlIl;IIlll("\x2b\x2b" "\n");mutex_lock(&
IIlllIll);list_for_each_entry(IlIlIl,&IlllIIll,entry){if(IlIlIl->llIII==llIII){
list_del(&IlIlIl->entry);usb_put_dev(IlIlIl->llIII);lIlIll(IlIlIl);break;}}
mutex_unlock(&IIlllIll);}void IIlIIIllI(){struct list_head Illlll=LIST_HEAD_INIT
(Illlll);
mutex_lock(&IIlllIll);list_splice_init(&IlllIIll,&Illlll);mutex_unlock(&IIlllIll
);
while(!list_empty(&Illlll)){struct IlIlIIIl*IlIlIl;IlIlIl=list_entry(Illlll.next
,struct IlIlIIIl,entry);list_del(&IlIlIl->entry);usb_put_dev(IlIlIl->llIII);
lIlIll(IlIlIl);}}











int IIlIlllIl(struct usb_interface*IIIIII){int IIIll;int IIIIllIIl=
(0x8f7+3792-0x17c7);int IIIIIIII=(0x8ec+6530-0x226e);
if(IIIIII->dev.driver&&to_usb_driver(IIIIII->dev.driver)==&lIIlllI){return
(0x97f+3966-0x18fd);}
IIIIIIII=(0x1b3a+1098-0x1f83);
if(IIIIII->dev.driver){usb_driver_release_interface(to_usb_driver(IIIIII->dev.
driver),IIIIII);IIIIllIIl=(0x13a2+4633-0x25ba);}
IIIll=usb_driver_claim_interface(&lIIlllI,IIIIII,(void*)-(0x9ec+6232-0x2243));if
(IIIll<(0x10f6+3237-0x1d9b)){llIlII(
"\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x63\x6c\x61\x69\x6d\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73\x2c\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,llIIIl(&IIIIII->dev),IIIll);return IIIll;}IIIll=lIIIIlllI(IIIIII,IIIIllIIl);if(
IIIll<(0x73+544-0x293)){llIlII(
"\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x61\x74\x74\x61\x63\x68\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73\x2c\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,llIIIl(&IIIIII->dev),IIIll);
usb_driver_release_interface(&lIIlllI,IIIIII);return IIIll;}return IIIIIIII;}
#if KERNEL_GT_EQ((0x1428+1723-0x1ade),(0xd27+4378-0x1e3e),(0x114a+3792-0x201a)) \
|| RHEL_RELEASE_GT_EQ((0x21c9+141-0x224e),(0x21f7+557-0x2424))
static int llIIIllll(struct device*dev,const void*IllIlIlll)
#else
static int llIIIllll(struct device*dev,void*IllIlIlll)
#endif
{const char*lllllI=IllIlIlll;if(strcmp(lllllI,llIIIl(dev))==(0xd02+4450-0x1e64))
{return(0xe7+2850-0xc08);}return(0x1e6a+723-0x213d);}struct usb_device*lllllIII(
const char*lllllI){struct device*dev;dev=bus_find_device(
#if KERNEL_LT_EQ((0x2129+1454-0x26d5),(0x1338+3470-0x20c0),(0x109+2936-0xc6f))
lIIlllI.driver.bus,
#else
lIIlllI.drvwrap.driver.bus,
#endif
NULL,(void*)lllllI,llIIIllll);if(dev){return to_usb_device(dev);}return NULL;}





int lIIlllIl(struct usb_device*llIII){int i;int lIlIlIIII=(0x841+4227-0x18c4);
int IIIIIIII=(0x4b+2108-0x887);int IIIll=-ENODEV;IIlll(
"\x2b\x2b\x20\x25\x73" "\n",llIIIl(&llIII->dev));if(!lIIIllll(llIII)){IIIll=
llIllIIl(llIII);if(IIIll<(0x876+5341-0x1d53)){llIlII(
"\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x61\x74\x74\x61\x63\x68\x20\x75\x73\x62\x20\x64\x65\x76\x69\x63\x65\x20\x25\x73\x2c\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,llIIIl(&llIII->dev),IIIll);IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}}if
(llIII->actconfig){for(i=(0xb3f+1997-0x130c);i<llIII->actconfig->desc.
bNumInterfaces;i++){struct usb_interface*IIIIII=llIII->actconfig->interface[i];
if(IIIIII==NULL){continue;
}IIIll=IIlIlllIl(IIIIII);if(IIIll<(0xa76+1776-0x1166)){IIlll(
"\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73\x20\x6e\x6f\x74\x20\x63\x6c\x61\x69\x6d\x65\x64\x2c\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,llIIIl(&IIIIII->dev),IIIll);break;}lIlIlIIII++;if(IIIll>(0xb05+7150-0x26f3)){
IIlll(
"\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73\x2c\x20\x61\x63\x74\x75\x61\x6c\x6c\x79\x20\x63\x6c\x61\x69\x6d\x65\x64" "\n"
,llIIIl(&IIIIII->dev));IIIIIIII++;}else
{IIlll(
"\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73\x2c\x20\x63\x6c\x61\x69\x6d\x65\x64" "\n"
,llIIIl(&IIIIII->dev));}}if(IIIll>=(0x68b+5087-0x1a6a)&&lIlIlIIII>
(0x169f+245-0x1794)&&IIIIIIII==(0xa38+2438-0x13be)){



struct IlIIl*lIlII=llIlllIl(llIII);if(lIlII){IIlll(
"\x72\x65\x66\x72\x65\x73\x68\x20\x6f\x6e\x6c\x69\x6e\x65" "\n");lIIlIIlIl(lIlII
);lIIlIIIl(lIlII);}else{IIlll(
"\x73\x74\x75\x62\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n");}}}IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}





void lIIllllI(struct usb_device*llIII,int IIIIIlII){int i;IIlll(
"\x2b\x2b\x20\x25\x73" "\n",llIIIl(&llIII->dev));if(llIII->actconfig){for(i=
(0x1c0+6373-0x1aa5);i<llIII->actconfig->desc.bNumInterfaces;i++){struct 
usb_interface*IIIIII=llIII->actconfig->interface[i];if(IIIIII==NULL){continue;
}if(IIIIII->dev.driver==NULL){continue;}if(to_usb_driver(IIIIII->dev.driver)!=&
lIIlllI){continue;}IIlll(
"\x72\x65\x6c\x65\x61\x73\x65\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73" "\n"
,llIIIl(&IIIIII->dev));
usb_driver_release_interface(&lIIlllI,IIIIII);}}if(lIIIllll(llIII)){lIIIllIIl(
llIII);}
#if KERNEL_GT_EQ((0xbbb+1664-0x1239),(0x1674+3538-0x2440),(0x1975+1929-0x20e8))
if(lIIllIll(&llIII->dev)){llllIIII(&llIII->dev,(0x1929+709-0x1bee));IIlll(
"\x73\x65\x6e\x64\x20\x4b\x4f\x42\x4a\x5f\x41\x44\x44\x20\x66\x6f\x72\x20\x64\x65\x76\x69\x63\x65\x20\x25\x73" "\n"
,llIIIl(&llIII->dev));kobject_uevent(&llIII->dev.kobj,KOBJ_ADD);}
#endif
if(llIII->actconfig){for(i=(0x1bf8+2151-0x245f);i<llIII->actconfig->desc.
bNumInterfaces;i++){struct usb_interface*IIIIII=llIII->actconfig->interface[i];
if(IIIIII==NULL){continue;}
#if KERNEL_GT_EQ((0xfad+3078-0x1bb1),(0x2a3+6837-0x1d52),(0x72a+1010-0xb06))
if(lIIllIll(&IIIIII->dev)){llllIIII(&IIIIII->dev,(0x50f+1098-0x959));IIlll(
"\x73\x65\x6e\x64\x20\x4b\x4f\x42\x4a\x5f\x41\x44\x44\x20\x66\x6f\x72\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73" "\n"
,llIIIl(&IIIIII->dev));kobject_uevent(&IIIIII->dev.kobj,KOBJ_ADD);}
#endif
if(IIIIIlII&&IIIIII->dev.driver==NULL){int lllIllIl;IIlll(
"\x6c\x6f\x61\x64\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x64\x72\x69\x76\x65\x72\x20\x66\x6f\x72\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73" "\n"
,llIIIl(&IIIIII->dev));


lllIllIl=device_attach(&IIIIII->dev);}}}IIlll("\x2d\x2d" "\n");}








#if KERNEL_LT_EQ((0x1e59+712-0x211f),(0x669+325-0x7a8),(0xe74+2672-0x18d1))


int llIIIllIl(struct notifier_block*self,unsigned long IIlIIlI,void*dev){struct 
usb_device*llIII=dev;IIlll(
"\x2b\x2b\x20\x61\x63\x74\x69\x6f\x6e\x3d\x25\x73\x28\x25\x6c\x75\x29\x20\x64\x65\x76\x3d\x25\x73" "\n"
,lllllIllI(IIlIIlI),IIlIIlI,llIII?llIIIl(&llIII->dev):"\x6e\x6f\x6e\x65");if(
IIlIIlI==USB_DEVICE_ADD){if(IllllIll(llIII)){
lIIlllIl(llIII);}}if(IIlIIlI==USB_DEVICE_REMOVE){


lIIllllI(llIII,(0x101d+5776-0x26ad));
IIIlIIllI(llIII);}IIlll("\x2d\x2d");return NOTIFY_OK;}struct notifier_block 
IIllllll={.notifier_call=llIIIllIl,.priority=INT_MAX,
};
#else 




int IIllIIIII(struct notifier_block*self,unsigned long IIlIIlI,void*dev){struct 
device*IlIlII=dev;IIlll(
"\x2b\x2b\x20\x61\x63\x74\x69\x6f\x6e\x3d\x25\x73\x28\x25\x6c\x75\x29\x20\x64\x65\x76\x3d\x25\x73" "\n"
,IlIllIII(IIlIIlI),IIlIIlI,IlIlII?llIIIl(IlIlII):"\x6e\x6f\x6e\x65");
#if (0x60f+1524-0xc03)

llIlII("\x25\x73\x20\x64\x65\x76\x3d\x25\x73" "\n",IlIllIII(IIlIIlI),IlIlII?
llIIIl(IlIlII):"\x6e\x6f\x6e\x65");
#endif
if(IIlIIlI==BUS_NOTIFY_ADD_DEVICE){if(IlIllllII(IlIlII)){struct usb_device*llIII
=to_usb_device(IlIlII);



if(IllllIll(llIII)){

if(llIllIIl(llIII)>=(0x1584+3106-0x21a6)){
#if KERNEL_GT_EQ((0x19cb+2290-0x22bb),(0x1284+2297-0x1b77),(0xe2f+4206-0x1e87))







llllIIII(&llIII->dev,(0x633+3734-0x14c8));
#endif
}}}else if(IlIIIlllI(IlIlII)){struct usb_interface*IIIIII=to_usb_interface(dev);
struct usb_device*llIII=interface_to_usbdev(IIIIII);
if(lIIIllll(llIII)){int IIIll;
#if KERNEL_GT_EQ((0xf96+1593-0x15cd),(0x8a4+7493-0x25e3),(0x1524+2627-0x1f4d)) \
&& KERNEL_LT_EQ((0xda4+1242-0x127c),(0x2032+1507-0x260f),(0x3b0+7045-0x1f0e))
int state_in_sysfs;
#endif
#if KERNEL_GT_EQ((0x1e3d+1445-0x23e0),(0x1aec+2127-0x2335),(0x1d54+420-0x1ee2))
llllIIII(&IIIIII->dev,(0xf25+4842-0x220e));
#endif
IIlll(
"\x63\x6c\x61\x69\x6d\x69\x6e\x67\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73" "\n"
,llIIIl(&IIIIII->dev));
#if KERNEL_GT_EQ((0x223+2445-0xbae),(0xa19+4079-0x1a02),(0x1595+3724-0x2407)) &&\
 KERNEL_LT_EQ((0x1297+2832-0x1da5),(0x14a5+2419-0x1e12),(0xa74+1157-0xed2))























state_in_sysfs=IlIlII->kobj.state_in_sysfs;IlIlII->kobj.state_in_sysfs=
(0x13b6+3844-0x22ba);
#endif
IIIll=IIlIlllIl(IIIIII);
#if KERNEL_GT_EQ((0xdc3+715-0x108c),(0x1ac0+75-0x1b05),(0x37d+7754-0x21ad)) && \
KERNEL_LT_EQ((0x142c+16-0x143a),(0xe4d+246-0xf3d),(0x1505+504-0x16d6))

IlIlII->kobj.state_in_sysfs=state_in_sysfs;
#endif
if(IIIll<(0x1ce7+1858-0x2429)){IIlll(
"\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73\x20\x6e\x6f\x74\x20\x63\x6c\x61\x69\x6d\x65\x64\x2c\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,llIIIl(&IIIIII->dev),IIIll);}else if(IIIll>(0x194+1572-0x7b8)){IIlll(
"\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73\x20\x61\x63\x74\x75\x61\x6c\x6c\x79\x20\x63\x6c\x61\x69\x6d\x65\x64" "\n"
,llIIIl(&IIIIII->dev));}else
{IIlll(
"\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73\x20\x63\x6c\x61\x69\x6d\x65\x64" "\n"
,llIIIl(&IIIIII->dev));}}}}else if(IIlIIlI==BUS_NOTIFY_DEL_DEVICE){if(IlIIIlllI(
IlIlII)){struct usb_interface*IIIIII=to_usb_interface(dev);struct usb_device*
llIII=interface_to_usbdev(IIIIII);if(lIIIllll(llIII)){



}}else if(IlIllllII(IlIlII)){struct usb_device*llIII=to_usb_device(IlIlII);if(
lIIIllll(llIII)){


lIIIllIIl(llIII);}
IIIlIIllI(llIII);}}IIlll("\x2d\x2d" "\n");return NOTIFY_OK;}struct 
notifier_block llIIIllI={.notifier_call=IIllIIIII,.priority=INT_MAX,
};
#endif 
#endif 

