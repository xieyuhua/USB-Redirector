/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IlllllIll
#define IlllllIll
#if KERNEL_GT_EQ((0x1e5+7441-0x1ef4),(0xe7d+3916-0x1dc3),(0xad+1200-0x53e))
#include <linux/scatterlist.h>
struct lIllIlll{
#if KERNEL_LT_EQ((0x26c+9076-0x25de),(0x708+1565-0xd1f),(0x1e5+7144-0x1dab)) 
struct usb_sg_request*IlIlIIl;
#else
struct scatterlist*IlIlIIl;
#endif
struct scatterlist*sg;int num_sgs;};int IIlIIllll(struct lIllIlll*sg,size_t 
length,int llllIIlI);void IIIIIIlII(struct lIllIlll*sg);size_t IlIlllIIl(struct 
lIllIlll*sg,const void __user*IIIlI,size_t length);size_t llllIIlII(struct 
lIllIlll*sg,void __user*IIIlI,size_t length);
#endif 
#endif 

