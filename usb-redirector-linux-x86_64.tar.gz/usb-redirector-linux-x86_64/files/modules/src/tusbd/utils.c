/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#include "usbd.h"
#include <linux/highmem.h>
#include <asm/page.h>
int lllIllIlI(const IIlIl IlIlI,size_t*IllllI,size_t*llIlIl,lIllIl*flags,lIllIl*
endpoint){switch(IlIlI->lllII.IIIIIIl){case lllllIIl:*IllllI=sizeof(IlIlI->
IIlllI);*flags=IIIllI;*llIlIl=IlIlI->IIlllI.IIllI;*endpoint=(0x1880+1208-0x1cb8)
;break;case IIlIIIll:*IllllI=sizeof(IlIlI->IIlllI);*flags=(0x17d9+2491-0x2194);*
llIlIl=IlIlI->IIlllI.IIllI;*endpoint=(0x12f2+2486-0x1ca8);break;case IlIIIIII:*
IllllI=sizeof(IlIlI->IIIllll)-sizeof(IlIlI->IIIllll.lIlllll[(0xef5+600-0x114d)])
+IlIlI->IIIllll.IIIllIlI*sizeof(IlIlI->IIIllll.lIlllll[(0x202+1090-0x644)]);*
flags=(0x812+3345-0x1523);*llIlIl=(0x111d+2242-0x19df);*endpoint=
(0x1dc8+1617-0x2419);break;case IIIlIIIl:*IllllI=sizeof(IlIlI->llIlllI);*flags=
(0x173b+3072-0x233b);*llIlIl=(0x14cf+571-0x170a);*endpoint=(0x96a+84-0x9be);
break;case lllllIlI:*IllllI=sizeof(IlIlI->IIllIl);*flags=IlIlI->IIllIl.Flags;*
llIlIl=IlIlI->IIllIl.IIllI;*endpoint=IlIlI->IIllIl.Endpoint|((*flags&IIIllI)?
(0xdd9+1266-0x124b):(0x2bf+2221-0xb6c));break;case IIlIlllI:*IllllI=sizeof(IlIlI
->llIll);*llIlIl=IlIlI->llIll.IIllI;*flags=IlIlI->llIll.Flags;*endpoint=IlIlI->
llIll.Endpoint|((*flags&IIIllI)?(0x67c+3855-0x150b):(0x128f+3602-0x20a1));break;
case IIIlIIII:*IllllI=IIIllllI(IlIlI);*flags=IlIlI->llIIl.Flags;*llIlIl=IlIlI->
llIIl.IIllI;*endpoint=IlIlI->llIIl.Endpoint|((*flags&IIIllI)?(0x4b7+7036-0x1fb3)
:(0xa47+5931-0x2172));break;case llIIlIII:*IllllI=sizeof(IlIlI->llIIlI);*flags=
IlIlI->llIIlI.Flags;*llIlIl=IlIlI->llIIlI.IIllI;*endpoint=IlIlI->llIIlI.Endpoint
|((*flags&IIIllI)?(0x14c1+3763-0x22f4):(0xe17+30-0xe35));break;case IIIIIIll:*
IllllI=sizeof(IlIlI->llIIlII);*flags=IlIlI->llIIlII.Flags;*llIlIl=
(0x6fc+498-0x8ee);*endpoint=IlIlI->llIIlII.Endpoint|((*flags&IIIllI)?
(0x1ec5+445-0x2002):(0x685+751-0x974));break;case lIIlIIll:*IllllI=sizeof(IlIlI
->IllIlIll);*flags=(0xf64+905-0x12ed);*llIlIl=(0x52b+7500-0x2277);*endpoint=
(0x534+360-0x59d);break;case lIIllllII:return-EINVAL;case llIIIlll:*IllllI=
sizeof(IlIlI->IIIlllll);*flags=(0x1024+5685-0x2659);*llIlIl=(0xe04+5421-0x2331);
*endpoint=(0xe4d+3747-0x1bf1);break;case IIIlllII:*IllllI=sizeof(IlIlI->
IllIIIllI);*flags=(0xaea+544-0xd0a);*llIlIl=(0x97c+6470-0x22c2);*endpoint=
(0x5f9+3269-0x11bf);break;case llIIlIIl:*IllllI=sizeof(IlIlI->IIIlllIII);*flags=
(0x507+2004-0xcdb);*llIlIl=(0x4f7+6848-0x1fb7);*endpoint=(0x1a78+1022-0x1d77);
break;case IlllIIlI:*IllllI=sizeof(IlIlI->lIlIllII);*flags=IlIlI->lIlIllII.Flags
;*llIlIl=(0x6d5+4523-0x1880);*endpoint=IlIlI->lIlIllII.Endpoint|((*flags&IIIllI)
?(0x780+3473-0x1491):(0x1e1f+2252-0x26eb));break;default:return-EINVAL;}return
(0x921+7340-0x25cd);}
struct usb_host_config*IIlIIlllI(struct usb_device*llIII){if(llIII->actconfig){
return llIII->actconfig;}if(llIII->descriptor.bNumConfigurations&&llIII->config)
{return&llIII->config[(0xa59+1895-0x11c0)];}return NULL;}
struct usb_host_interface*IlllllIlI(struct usb_host_config*config){if(config->
desc.bNumInterfaces>(0x13ed+2711-0x1e84)){if(config->interface[
(0xd2c+5540-0x22d0)]){if(config->interface[(0xcc6+3109-0x18eb)]->cur_altsetting)
{return config->interface[(0x10b7+4633-0x22d0)]->cur_altsetting;}if(config->
interface[(0x69f+7199-0x22be)]->num_altsetting&&config->interface[
(0x4+6889-0x1aed)]->altsetting){return&config->interface[(0x403+1432-0x99b)]->
altsetting[(0xba4+4039-0x1b6b)];}}if(config->intf_cache[(0x636+1340-0xb72)]&&
config->intf_cache[(0x1774+3985-0x2705)]->num_altsetting){return&config->
intf_cache[(0x1875+3486-0x2613)]->altsetting[(0xfd3+5198-0x2421)];}}return NULL;
}
void lIIlIIIlI(struct usb_device*llIII,u8*IIlllIlI,u8*IlIIIlIl,u8*IIIlIllI){
struct usb_host_config*config;struct usb_host_interface*IIIIII;config=IIlIIlllI(
llIII);if(config==NULL){if(IIlllIlI){*IIlllIlI=(0x11f8+2537-0x1be1);}if(IlIIIlIl
){*IlIIIlIl=(0x394+6820-0x1e38);}if(IIIlIllI){*IIIlIllI=(0x956+437-0xb0b);}
return;}IIIIII=IlllllIlI(config);

















if((config->desc.bNumInterfaces>(0xcf+3892-0x1002))&&((llIII->descriptor.
bDeviceClass==(0x100f+635-0x128a))||
((llIII->descriptor.bDeviceClass==(0xf4a+2049-0x165c))&&
(llIII->descriptor.bDeviceSubClass==(0xfcb+3741-0x1e66))&&(llIII->descriptor.
bDeviceProtocol==(0x15f8+3608-0x240f))))){

if(IIlllIlI){*IIlllIlI=(0x198+2530-0xb7a);}if(IlIIIlIl){*IlIIIlIl=
(0x11f4+3515-0x1faf);}if(IIIlIllI){*IIIlIllI=(0x520+7649-0x2301);}}else if(
config->desc.bNumInterfaces>(0x13a2+288-0x14c2)&&IIIIII){
if(IIlllIlI){*IIlllIlI=IIIIII->desc.bInterfaceClass;}if(IlIIIlIl){*IlIIIlIl=
IIIIII->desc.bInterfaceSubClass;}if(IIIlIllI){*IIIlIllI=IIIIII->desc.
bInterfaceProtocol;}}else
{
if(IIlllIlI){*IIlllIlI=llIII->descriptor.bDeviceClass;}if(IlIIIlIl){*IlIIIlIl=
llIII->descriptor.bDeviceSubClass;}if(IIIlIllI){*IIIlIllI=llIII->descriptor.
bDeviceProtocol;}}}
#ifdef _USBD_ENABLE_STUB_
#ifdef _USBD_DEBUG_MEMORY_
extern atomic_t IlIlIlIl;extern atomic_t IllllIlII;extern atomic_t llIIlIIlI;
#endif 

int IllIlIlIl(struct lIlIl*lIlll,void __user*IIIlI,size_t llIlIIl){int IIIll=
(0xb86+1025-0xf87);Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x65\x78\x74\x72\x61\x63\x74\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x2b\x2b" "\n"
);do{IIlIl IlIlI=(IIlIl)(lIlll+(0x375+4679-0x15bb));lIllIl flags,endpoint;size_t
 lIllIlI,llIlIl,lllIlI;if(lllIllIlI(IlIlI,&lIllIlI,&llIlIl,&flags,&endpoint)<
(0x1407+2603-0x1e32)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x65\x78\x74\x72\x61\x63\x74\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x64\x61\x74\x61" "\n"
);IIIll=-EFAULT;break;}lllIlI=min_t(size_t,IlIlI->lllII.IlIll,llIlIIl);
#if KERNEL_GT_EQ((0x430+120-0x4a3),(0x1185+249-0x127e),(0xa79+2185-0x1302)) || \
RHEL_RELEASE_GT_EQ((0x10f1+4639-0x2308),(0x554+5267-0x19e7))
if(!access_ok(IIIlI,lllIlI))
#else
if(!access_ok(VERIFY_WRITE,IIIlI,lllIlI))
#endif
{Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x65\x78\x74\x72\x61\x63\x74\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x6d\x65\x6d\x6f\x72\x79\x20\x61\x63\x63\x65\x73\x73\x20\x63\x68\x65\x63\x6b\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-EINVAL;break;}lllIlI=min_t(size_t,lIllIlI,llIlIIl);if(__copy_to_user(
IIIlI,IlIlI,lllIlI)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x65\x78\x74\x72\x61\x63\x74\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x74\x6f\x20\x75\x73\x65\x72\x20\x62\x75\x66\x66\x65\x72\x28\x31\x29" "\n"
);IIIll=-EFAULT;break;}if(lllIlI<lIllIlI){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x65\x78\x74\x72\x61\x63\x74\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x6e\x6f\x74\x20\x65\x6e\x6f\x75\x67\x68\x20\x62\x75\x66\x66\x65\x72\x28\x31\x29" "\n"
);IIIll=-EMSGSIZE;break;}llIlIIl-=lllIlI;IIIlI+=lllIlI;if((flags&IIIllI)&&llIlIl
){if(llIlIIl<llIlIl){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x65\x78\x74\x72\x61\x63\x74\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x6e\x6f\x74\x20\x65\x6e\x6f\x75\x67\x68\x20\x62\x75\x66\x66\x65\x72\x28\x32\x29" "\n"
);IIIll=-EMSGSIZE;break;}if(lIlll->lIllll==IIlIlI){


if(__copy_to_user(IIIlI,lIlll->lIIIll.lllll,llIlIl)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x65\x78\x74\x72\x61\x63\x74\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x74\x6f\x20\x75\x73\x65\x72\x20\x62\x75\x66\x66\x65\x72\x28\x32\x29" "\n"
);IIIll=-EFAULT;break;}}else if(lIlll->lIllll==llIIlIl){


if(lIlIlIlII(lIlll->lIllII.llIllI,IIIlI,llIlIl)<llIlIl){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x65\x78\x74\x72\x61\x63\x74\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x74\x6f\x20\x75\x73\x65\x72\x20\x62\x75\x66\x66\x65\x72\x28\x33\x29" "\n"
);IIIll=-EFAULT;break;}}
#if KERNEL_GT_EQ((0x1798+3521-0x2557),(0x17d5+2849-0x22f0),(0x1d0+1948-0x94d))
else if(lIlll->lIllll==lllIIII){


if(llllIIlII(&lIlll->lIIllII.sg,IIIlI,llIlIl)<llIlIl){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x65\x78\x74\x72\x61\x63\x74\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x74\x6f\x20\x75\x73\x65\x72\x20\x62\x75\x66\x66\x65\x72\x28\x34\x29" "\n"
);IIIll=-EFAULT;break;}}
#endif
else{Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x65\x78\x74\x72\x61\x63\x74\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x20\x65\x72\x72\x6f\x72\x21" "\n"
);IIIll=-EFAULT;break;}}}while((0xa45+632-0xcbd));Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x65\x78\x74\x72\x61\x63\x74\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}struct lIlIl*llIlIIlII(struct IlIIl*lIlII,const void 
__user*IIIlI,size_t llIlIIl){IIlIl llllIlIl;llIIllIIlI IIlIlIl;struct lIlIl*
lIlll=NULL;size_t lIllIlI,llIlIl,lllllllI;lIllIl flags,endpoint;int IIIll=-
(0xb60+6645-0x2554);int lIllll;do
{if(copy_from_user(&IIlIlIl,IIIlI,min_t(size_t,sizeof(IIlIlIl),llIlIIl))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x66\x72\x6f\x6d\x20\x75\x73\x65\x72\x20\x62\x75\x66\x66\x65\x72\x20\x28\x32\x29" "\n"
);break;}
#if KERNEL_GT_EQ((0x6b4+6022-0x1e35),(0x8c+1541-0x691),(0x1ead+239-0x1f9c)) || \
RHEL_RELEASE_GT_EQ((0xa72+740-0xd4e),(0x721+5770-0x1dab))
if(!access_ok(IIIlI,IIlIlIl.lllII.IlIll))
#else
if(!access_ok(VERIFY_READ,IIIlI,IIlIlIl.lllII.IlIll))
#endif
{Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x6d\x65\x6d\x6f\x72\x79\x20\x61\x63\x63\x65\x73\x73\x20\x63\x68\x65\x63\x6b\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-EFAULT;break;}if(lllIllIlI(&IIlIlIl,&lIllIlI,&llIlIl,&flags,&endpoint)<
(0xce3+68-0xd27)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x64\x61\x74\x61" "\n"
);IIIll=-EINVAL;break;}


if((llIlIl==(0x9fb+4713-0x1c64))||((sizeof(struct lIlIl)+lIllIlI+llIlIl+
(0x410+3663-0x121f))<=lIIIIll)){
lIllll=IIlIlI;}else if(IIlIlIl.lllII.IIIIIIl==IIlIlllI){
lIllll=lIlII->lIIIlII;}else if(IIlIlIl.lllII.IIIIIIl==llIIlIII){
lIllll=lIlII->lllllIll;}else if(IIlIlIl.lllII.IIIIIIl==IIIlIIII){
lIllll=lIlII->IIlllllI;}else{
lIllll=IIlIlI;}

if(lIllll==IIlIlI){lllllllI=sizeof(struct lIlIl)+lIllIlI+llIlIl+
(0x1b53+3004-0x26cf);}else{lllllllI=sizeof(struct lIlIl)+lIllIlI;}lIlll=IllIIlI(
lllllllI,GFP_KERNEL);if(!lIlll){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x61\x6c\x6c\x6f\x63\x61\x74\x65\x20\x72\x65\x71\x75\x65\x73\x74\x2c\x20\x75\x6e\x72\x62\x73\x69\x7a\x65\x3d\x25\x6c\x75\x20\x2b\x20\x25\x6c\x75" "\n"
,(unsigned long)lIllIlI,(unsigned long)sizeof(struct lIlIl));break;}
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&IlIlIlIl);
#endif


memset(lIlll,(0x112b+1113-0x1584),sizeof(*lIlll));INIT_LIST_HEAD(&lIlll->llllIl)
;lIlll->IllllI=lllllllI;atomic_set(&lIlll->state,lllIIIIl);lIlll->lIlII=IIlllIII
(lIlII);lIlll->lIllll=lIllll;lIlll->IlIIIIl=(0x9cc+5493-0x1f41);lIlll->endpoint=
endpoint;lIlll->lllIl=IIlIlIl.lllII.IIllll;lIlll->IIIIIlI.llIlIIII=IIlIlIl.lllII
.lIIIlll;kref_init(&lIlll->IllIll);llllIlIl=(IIlIl)(lIlll+(0xe94+763-0x118e));


if(__copy_from_user(llllIlIl,IIIlI,lIllIlI)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x66\x72\x6f\x6d\x20\x75\x73\x65\x72\x20\x62\x75\x66\x66\x65\x72\x20\x28\x33\x29" "\n"
);break;}IIIlI+=lIllIlI;llIlIIl-=lIllIlI;

if(lIllll==IIlIlI){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x73\x6f\x6c\x69\x64\x20\x75\x6e\x72\x62" "\n"
);








lIlll->lIIIll.lllll=(void*)(((unsigned long)llllIlIl+lIllIlI+
(0x1964+3319-0x261b))&(~(unsigned long)((0x124c+4552-0x23d4)-(0x8d0+3008-0x148f)
)));
if(llIlIl&&!(flags&IIIllI)){if(llIlIl>llIlIIl){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x73\x69\x7a\x65\x20\x28\x34\x29" "\n"
);IIIll=-(0x62a+5465-0x1b82);break;}if(__copy_from_user(lIlll->lIIIll.lllll,
IIIlI,llIlIl)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x66\x72\x6f\x6d\x20\x75\x73\x65\x72\x20\x62\x75\x66\x66\x65\x72\x20\x28\x34\x29" "\n"
);IIIll=-(0x1971+97-0x19d1);break;}IIIlI+=llIlIl;llIlIIl-=llIlIl;}}else if(
lIllll==llIIlIl){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64" "\n"
);
if(llllIlIl->lllII.IIIIIIl==IIIlIIII){lIlll->lIllII.llIllI=lIIIIlIll(llIlIl,
llllIlIl->llIIl.llIIIlI,llllIlIl->llIIl.llIIIIl);if(!lIlll->lIllII.llIllI){Illll
(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x5f\x66\x6f\x72\x5f\x69\x73\x6f\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-(0x13ba+3189-0x202e);break;}}else{int llIIlllI=IllIIllIl(lIlII->lIIlI,
endpoint);if(llIIlllI<(0xb34+1168-0xfc4)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x6e\x6f\x20\x65\x6e\x64\x70\x6f\x69\x6e\x74" "\n"
);IIIll=llIIlllI;break;}lIlll->lIllII.llIllI=IIIllIlIl(llIlIl,llIIlllI);if(!
lIlll->lIllII.llIllI){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-(0x166d+4151-0x26a3);break;}}
if(llIlIl&&!(flags&IIIllI)){if(llIlIl>llIlIIl){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x73\x69\x7a\x65\x20\x28\x35\x29" "\n"
);IIIll=-(0x5e1+827-0x91b);break;}if(IIIlllIIl(lIlll->lIllII.llIllI,IIIlI,llIlIl
)<llIlIl){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x66\x72\x6f\x6d\x20\x75\x73\x65\x72\x20\x62\x75\x66\x66\x65\x72\x20\x28\x35\x29" "\n"
);IIIll=-(0x10a8+1759-0x1786);break;}IIIlI+=llIlIl;llIlIIl-=llIlIl;}}
#if KERNEL_GT_EQ((0x2b2+3341-0xfbd),(0x412+4470-0x1582),(0x16e8+331-0x1814))
else if(lIllll==lllIIII){


int llIIlllI=IllIIllIl(lIlII->lIIlI,endpoint);Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x73\x67" "\n"
);if(llIIlllI<(0x1796+3639-0x25cd)){IIIll=llIIlllI;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x6e\x6f\x20\x65\x6e\x64\x70\x6f\x69\x6e\x74" "\n"
);break;}IIIll=IIlIIllll(&lIlll->lIIllII.sg,llIlIl,llIIlllI);if(IIIll<
(0x14cb+374-0x1641)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x75\x73\x62\x64\x5f\x73\x67\x5f\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64" "\n"
);break;}if(llIlIl&&(flags&IIIllI)==(0x2ef+5874-0x19e1)){if(llIlIl>llIlIIl){
Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x73\x69\x7a\x65\x20\x28\x36\x29" "\n"
);IIIll=-(0xd87+4156-0x1dc2);break;}if(IlIlllIIl(&lIlll->lIIllII.sg,IIIlI,llIlIl
)<llIlIl){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x66\x72\x6f\x6d\x20\x75\x73\x65\x72\x20\x62\x75\x66\x66\x65\x72\x20\x28\x36\x29" "\n"
);IIIll=-(0x26b+2576-0xc7a);break;}IIIlI+=llIlIl;llIlIIl-=llIlIl;}}
#endif 
else{IIIll=-EINVAL;break;}IIIll=(0x704+7058-0x2296);}while((0xe05+4943-0x2154));
if(IIIll<(0x4a5+8791-0x26fc)){if(lIlll){llIllll(lIlll);lIlll=NULL;}return NULL;}
return lIlll;}


struct lIlIl*IIIIIIlll(struct lIlIl*lIlll,gfp_t lIIIl){struct lIlIl*IIIlIlI;if(
lIlll->lIllll!=IIlIlI)
{return NULL;}IIIlIlI=IllIIlI(lIlll->IllllI,lIIIl);if(IIIlIlI){memset(IIIlIlI,
(0x1027+5019-0x23c2),sizeof(*IIIlIlI));
memcpy(IIIlIlI+(0x10f4+5082-0x24cd),lIlll+(0x92b+2947-0x14ad),lIlll->IllllI-
sizeof(*lIlll));
INIT_LIST_HEAD(&IIIlIlI->llllIl);IIIlIlI->IllllI=lIlll->IllllI;IIIlIlI->lllIl=
lIlll->lllIl;IIIlIlI->IIIIIlI=lIlll->IIIIIlI;atomic_set(&IIIlIlI->state,lllIIIIl
);IIIlIlI->lIlII=IIlllIII(lIlll->lIlII);IIIlIlI->endpoint=lIlll->endpoint;
IIIlIlI->lIIIll.lllll=(void*)IIIlIlI+((unsigned long)lIlll->lIIIll.lllll-(
unsigned long)lIlll);IIIlIlI->lIllll=lIlll->lIllll;kref_init(&IIIlIlI->IllIll);
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&IlIlIlIl);
#endif
}return IIIlIlI;}void IlIlIlll(struct kref*IllIlII){struct lIlIl*lIlll=
container_of(IllIlII,struct lIlIl,IllIll);Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x64\x65\x73\x74\x72\x6f\x79\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x75\x6e\x69\x71\x75\x65\x5f\x69\x64\x3d\x30\x78\x25\x6c\x6c\x78" "\n"
,lIlll->lllIl);
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&llIIlIIlI);
#endif
if(lIlll->lIllll==IIlIlI){if(lIlll->lIIIll.IlllI){if(lIlll->lIIIll.IlllI->
setup_packet){lIlIll(lIlll->lIIIll.IlllI->setup_packet);}lIIIlIIl(lIlll->lIIIll.
IlllI);}


}else if(lIlll->lIllll==llIIlIl){if(lIlll->lIllII.llllIlI){llIllIlll(lIlll->
lIllII.llllIlI);}if(lIlll->lIllII.llIllI){IllIllllI(lIlll->lIllII.llIllI);}}
#if KERNEL_GT_EQ((0x12c8+3639-0x20fd),(0x6d9+2521-0x10ac),(0xf96+5954-0x26b9))
else if(lIlll->lIllll==lllIIII){if(lIlll->lIIllII.IlllI){if(lIlll->lIIllII.IlllI
->setup_packet){lIlIll(lIlll->lIIllII.IlllI->setup_packet);}lIIIlIIl(lIlll->
lIIllII.IlllI);}IIIIIIlII(&lIlll->lIIllII.sg);}
#endif
if(lIlll->lIlII){lIIlIIIl(lIlll->lIlII);}lIlIll(lIlll);}void llIllll(struct 
lIlIl*lIlll){
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&IllllIlII);
#endif
kref_put(&lIlll->IllIll,IlIlIlll);}
#endif 
IlIIlI lllIlIlll(void){static IlIIlI IIllll=(0x1921+3226-0x25bb);return(++IIllll
);}int llllllIIl(void*IlIIIIlIl,struct vm_area_struct*Illllll){int IIIll=
(0x1173+2083-0x1996);unsigned long start=Illllll->vm_start;unsigned long IIlIIl=
Illllll->vm_end-Illllll->vm_start;unsigned long lIIlIlIIl;Illll(
"\x75\x73\x62\x64\x5f\x6d\x61\x70\x5f\x76\x6d\x65\x6d\x3a\x20\x2b\x2b" "\n");
while(IIlIIl>(0x3fb+1141-0x870)){lIIlIlIIl=vmalloc_to_pfn(IlIIIIlIl);IIIll=
remap_pfn_range(Illllll,start,lIIlIlIIl,PAGE_SIZE,PAGE_SHARED);if(IIIll<
(0x12e4+3751-0x218b)){Illll(
"\x75\x73\x62\x64\x5f\x6d\x61\x70\x5f\x76\x6d\x65\x6d\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x6d\x61\x70\x20\x74\x68\x65\x20\x70\x61\x67\x65" "\n"
);break;}start+=PAGE_SIZE;IlIIIIlIl+=PAGE_SIZE;IIlIIl-=PAGE_SIZE;}Illll(
"\x75\x73\x62\x64\x5f\x6d\x61\x70\x5f\x76\x6d\x65\x6d\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}void lIIlIIlII(dma_addr_t IIIlIIl,void*lllIll,unsigned 
long IIlIIl){void*lIIlll;struct page*lIllllll;unsigned long flags;unsigned long 
IIlllII;unsigned long lIllllI,IlIIlIl;local_irq_save(flags);while(IIlIIl){

lIllllI=IIIlIIl&(PAGE_SIZE-(0x1c79+293-0x1d9d));IlIIlIl=PAGE_SIZE-lIllllI;
IIlllII=(IlIIlIl<IIlIIl)?IlIIlIl:IIlIIl;
lIllllll=pfn_to_page(IIIlIIl>>PAGE_SHIFT);
#if KERNEL_GT_EQ((0x313+8590-0x249f),(0x24c+7804-0x20c2),(0x201b+441-0x21af))
lIIlll=kmap_atomic(lIllllll);
#else
lIIlll=kmap_atomic(lIllllll,KM_IRQ0);
#endif
memcpy(lIIlll+lIllllI,lllIll,IIlllII);
#if KERNEL_GT_EQ((0x1a+3953-0xf89),(0x15e2+3972-0x2560),(0xd66+4950-0x2097))
kunmap_atomic(lIIlll);
#else
kunmap_atomic(lIIlll,KM_IRQ0);
#endif

IIIlIIl+=IIlllII;lllIll+=IIlllII;IIlIIl-=IIlllII;}local_irq_restore(flags);}void
 lllIIllIl(void*IIIlIIl,dma_addr_t lllIll,unsigned long IIlIIl){struct page*
lIllllll;unsigned char*lIIlll;unsigned long flags;unsigned long IIlllII;unsigned
 long lIllllI,IlIIlIl;local_irq_save(flags);while(IIlIIl){

lIllllI=lllIll&(PAGE_SIZE-(0x871+6604-0x223c));IlIIlIl=PAGE_SIZE-lIllllI;IIlllII
=(IlIIlIl<IIlIIl)?IlIIlIl:IIlIIl;
lIllllll=pfn_to_page(lllIll>>PAGE_SHIFT);
#if KERNEL_GT_EQ((0x1476+605-0x16d1),(0x292+2309-0xb91),(0x3e8+752-0x6b3))
lIIlll=kmap_atomic(lIllllll);
#else
lIIlll=kmap_atomic(lIllllll,KM_IRQ0);
#endif
memcpy(IIIlIIl,lIIlll+lIllllI,IIlllII);
#if KERNEL_GT_EQ((0x611+136-0x697),(0xff8+5523-0x2585),(0x538+5377-0x1a14))
kunmap_atomic(lIIlll);
#else
kunmap_atomic(lIIlll,KM_IRQ0);
#endif

lllIll+=IIlllII;IIIlIIl+=IIlllII;IIlIIl-=IIlllII;}local_irq_restore(flags);}int 
lIIlIlll(IIIIl status){int IIIll;switch(status){case lIIllllll:IIIll=
(0x1143+3157-0x1d98);break;case lIlIllIllI:IIIll=-EINPROGRESS;break;case 
llIllllll:IIIll=-ECONNRESET;break;case lIIIIIllI:IIIll=-EXDEV;break;case 
IIlIllIII:IIIll=-ETIMEDOUT;break;case IlllIIIlll:IIIll=-EINVAL;break;case 
lIlIIIllll:IIIll=-ENODEV;break;case lIIlllIlI:IIIll=-EREMOTEIO;break;case 
IlIllIlII:IIIll=-EOVERFLOW;break;case IIIlIIllIl:IIIll=-ENOSR;break;case 
lIIllIIIlI:IIIll=-ECOMM;break;case IIlIllIll:IIIll=-EPIPE;break;case lllIllllll:
IIIll=-EILSEQ;break;case lllIllIIII:IIIll=-EPROTO;break;case IlIIIIIll:IIIll=-
ENOMEM;break;case lIlllIIIll:IIIll=-EPROTO;break;case lllIIIIII:default:IIIll=-
EPROTO;break;}return IIIll;}
size_t IIlIIlIl(struct usb_iso_packet_descriptor*lIlIIlIl,int IlIII,void*IIIlIIl
,void*lllIll,int lIIlIIII){lIllIl*IIIIlllI;size_t IIIll;IIIll=
(0x209a+608-0x22fa);IIIIlllI=IIIlIIl;for(;IlIII;IlIII--){lIllIl*IIlIIIIIl=lllIll
+lIlIIlIl->offset;unsigned int length=lIIlIIII?lIlIIlIl->actual_length:lIlIIlIl
->length;if(length&&IIIIlllI!=IIlIIIIIl){
memmove(IIIIlllI,IIlIIIIIl,length);}IIIIlllI+=length;IIIll+=length;lIlIIlIl++;}
Illll(
"\x75\x73\x62\x64\x5f\x70\x61\x63\x6b\x5f\x69\x73\x6f\x5f\x62\x75\x66\x66\x65\x72\x3a\x20\x70\x61\x63\x6b\x65\x64\x3d\x25\x6c\x75" "\n"
,(unsigned long)IIIll);return IIIll;}
size_t IlIllIIll(struct usb_iso_packet_descriptor*lIlIIlIl,int IlIII,int 
lIIlIIII){size_t IIIll;IIIll=(0x665+6048-0x1e05);for(;IlIII>(0x176a+2920-0x22d2)
;IlIII--){IIIll+=lIIlIIII?lIlIIlIl->actual_length:lIlIIlIl->length;lIlIIlIl++;}
Illll(
"\x75\x73\x62\x64\x5f\x63\x6f\x75\x6e\x74\x5f\x69\x73\x6f\x5f\x62\x75\x66\x66\x65\x72\x3a\x20\x70\x61\x63\x6b\x65\x64\x3d\x25\x6c\x75" "\n"
,(unsigned long)IIIll);return IIIll;}char*lIllllIIl(struct kobject*kobj,gfp_t 
llIIIIIll){
#if KERNEL_GT_EQ((0x1008+4372-0x211a),(0x6e0+2315-0xfe5),(0x10f0+4172-0x2129))
return kobject_get_path(kobj,llIIIIIll);
#else
char*llIlIlI;int length;struct kobject*IIllII;
for(IIllII=kobj,length=(0x11c0+2967-0x1d57);IIllII&&kobject_name(IIllII);IIllII=
IIllII->parent){length+=strlen(kobject_name(IIllII));length+=(0xa64+5846-0x2139)
;
}if(IIllII)
{return NULL;}
llIlIlI=IllIIlI(length+(0x779+7379-0x244b),llIIIIIll);if(llIlIlI==NULL){return 
NULL;}*(llIlIlI+length)='\0';
for(IIllII=kobj;IIllII&&length>(0xc77+4837-0x1f5c);IIllII=IIllII->parent){int l=
strlen(kobject_name(IIllII));strncpy(llIlIlI+length-l,kobject_name(IIllII),l);*(
llIlIlI+length-l-(0x167a+831-0x19b8))=((char)(0x1c66+2581-0x264c));length-=l+
(0x10e5+4937-0x242d);}
if(length!=(0x1fa5+110-0x2013)||IIllII){lIlIll(llIlIlI);return NULL;}return 
llIlIlI;
#endif
}void llIIIIIlI(char*llIlIlI){
#if KERNEL_GT_EQ((0xda+5323-0x15a3),(0xa1f+2965-0x15ae),(0xfc+5934-0x1817))
kfree(llIlIlI);
#else
lIlIll(llIlIlI);
#endif
}int IIIllIlll(struct device*dev){



if(dev->bus&&!strcmp(dev->bus->name,"\x75\x73\x62")){return(0x538+1769-0xc20);}
return(0x97a+3831-0x1871);}int IlIIIlllI(struct device*dev){if(IIIllIlll(dev)){
#if KERNEL_LT_EQ((0x1ca9+156-0x1d43),(0x380+7635-0x214d),(0x77a+6879-0x2244))

if(!strchr(llIIIl(dev),((char)(0x61d+6265-0x1e5c)))){return(0x10d3+1593-0x170b);
}
#else




if(dev->type&&!strcmp(dev->type->name,
"\x75\x73\x62\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65")){return
(0x1070+303-0x119e);}
#endif
}return(0xd3+2272-0x9b3);}int IlIllllII(struct device*dev){if(IIIllIlll(dev)){
#if KERNEL_LT_EQ((0x89d+3163-0x14f6),(0x20b3+1100-0x24f9),(0x7b1+5223-0x1c03))


if(strchr(llIIIl(dev),((char)(0x1750+2628-0x215a)))){return(0x968+1528-0xf5f);}
#else




if(dev->type&&!strcmp(dev->type->name,"\x75\x73\x62\x5f\x64\x65\x76\x69\x63\x65"
)){return(0x118a+1822-0x18a7);}
#endif
}return(0x1a66+3193-0x26df);}
#if KERNEL_GT_EQ((0xbb8+6788-0x263a),(0x5af+8274-0x25fb),(0x825+5652-0x1e23))












void llllIIII(struct device*dev,int llIlIlIll){
#if KERNEL_LT_EQ((0x14a2+1131-0x190b),(0xc37+1228-0x10fd),(0x10fa+3075-0x1ce0))
dev->uevent_suppress=llIlIlIll;
#elif KERNEL_GT_EQ((0x5bc+4125-0x15d7),(0x1283+4453-0x23e2),(0xad5+4692-0x1d0b))
dev_set_uevent_suppress(dev,llIlIlIll);
#endif
}int lIIllIll(struct device*dev){
#if KERNEL_LT_EQ((0x1051+1366-0x15a5),(0x68+4506-0x11fc),(0x13d0+568-0x15eb))
return dev->uevent_suppress;
#elif KERNEL_GT_EQ((0x7a5+710-0xa69),(0x4b1+3474-0x123d),(0x78f+2286-0x105f))
return dev_get_uevent_suppress(dev);
#endif
}
#endif 
#ifndef _USBD_DEBUG_
const char*IlIllIII(unsigned long IIlIIlI){return"";}const char*lllllIllI(
unsigned long IIlIIlI){return"";}void IIlIIIIlI(const char*IlIIIIIl,struct urb*
IlllI,IlIIlI lllIl,int lIllIllI){}
#else
const char*IlIllIII(unsigned long IIlIIlI){switch(IIlIIlI){
#if KERNEL_GT_EQ((0x17+349-0x172),(0x553+3844-0x1451),(0x1f9+8446-0x22e3))
case BUS_NOTIFY_ADD_DEVICE:return
"\x42\x55\x53\x5f\x4e\x4f\x54\x49\x46\x59\x5f\x41\x44\x44\x5f\x44\x45\x56\x49\x43\x45"
;case BUS_NOTIFY_DEL_DEVICE:return
"\x42\x55\x53\x5f\x4e\x4f\x54\x49\x46\x59\x5f\x44\x45\x4c\x5f\x44\x45\x56\x49\x43\x45"
;case BUS_NOTIFY_BOUND_DRIVER:return
"\x42\x55\x53\x5f\x4e\x4f\x54\x49\x46\x59\x5f\x42\x4f\x55\x4e\x44\x5f\x44\x52\x49\x56\x45\x52"
;case BUS_NOTIFY_UNBIND_DRIVER:return
"\x42\x55\x53\x5f\x4e\x4f\x54\x49\x46\x59\x5f\x55\x4e\x42\x49\x4e\x44\x5f\x44\x52\x49\x56\x45\x52"
;
#endif
#if KERNEL_GT_EQ((0x2c8+6288-0x1b56),(0x20a2+230-0x2182),(0x8f2+3146-0x151d))
case BUS_NOTIFY_UNBOUND_DRIVER:return
"\x42\x55\x53\x5f\x4e\x4f\x54\x49\x46\x59\x5f\x55\x4e\x42\x4f\x55\x4e\x44\x5f\x44\x52\x49\x56\x45\x52"
;
#endif
#if KERNEL_GT_EQ((0x4e6+8480-0x2604),(0x238+5735-0x1899),(0x1fec+153-0x2061))
case BUS_NOTIFY_BIND_DRIVER:return
"\x42\x55\x53\x5f\x4e\x4f\x54\x49\x46\x59\x5f\x42\x49\x4e\x44\x5f\x44\x52\x49\x56\x45\x52"
;
#endif
#if KERNEL_GT_EQ((0x5d1+4399-0x16fd),(0x2b+964-0x3dd),(0x128a+1112-0x16e2))
case BUS_NOTIFY_REMOVED_DEVICE:return
"\x42\x55\x53\x5f\x4e\x4f\x54\x49\x46\x59\x5f\x52\x45\x4d\x4f\x56\x45\x44\x5f\x44\x45\x56\x49\x43\x45"
;
#endif
default:break;}return"\x75\x6e\x6b\x6e\x6f\x77\x6e";}const char*lllllIllI(
unsigned long IIlIIlI){switch(IIlIIlI){case USB_DEVICE_ADD:return
"\x55\x53\x42\x5f\x44\x45\x56\x49\x43\x45\x5f\x41\x44\x44";case 
USB_DEVICE_REMOVE:return
"\x55\x53\x42\x5f\x44\x45\x56\x49\x43\x45\x5f\x52\x45\x4d\x4f\x56\x45";case 
USB_BUS_ADD:return"\x55\x53\x42\x5f\x42\x55\x53\x5f\x41\x44\x44";case 
USB_BUS_REMOVE:return"\x55\x53\x42\x5f\x42\x55\x53\x5f\x52\x45\x4d\x4f\x56\x45";
default:break;}return"\x75\x6e\x6b\x6e\x6f\x77\x6e";}void IIlIIIIlI(const char*
IlIIIIIl,struct urb*IlllI,IlIIlI lllIl,int lIllIllI){const char*IIllIIlIl[]={
"\x69\x73\x6f","\x69\x6e\x74","\x63\x74\x72\x6c","\x62\x75\x6c\x6b"};if(!IlllI){
return;}Illll(
"\x2b\x2b\x2b\x2b\x20\x55\x52\x42\x20\x53\x54\x41\x52\x54\x20\x25\x73\x20\x2b\x2b\x2b\x2b" "\n"
,IlIIIIIl);Illll("\x20\x20\x55\x52\x42\x3d\x30\x78\x25\x70" "\n",IlllI);Illll(
"\x20\x20\x50\x69\x70\x65\x3d\x30\x78\x25\x30\x38\x58\x20\x28\x64\x65\x76\x3a\x20\x25\x64\x20\x65\x6e\x64\x70\x3a\x20\x25\x64\x20\x64\x69\x72\x3a\x20\x25\x73\x20\x74\x79\x70\x65\x3a\x20\x25\x73\x29" "\n"
,IlllI->pipe,usb_pipedevice(IlllI->pipe),usb_pipeendpoint(IlllI->pipe),
usb_pipein(IlllI->pipe)?"\x69\x6e":"\x6f\x75\x74",IIllIIlIl[usb_pipetype(IlllI->
pipe)]);Illll("\x20\x20\x53\x74\x61\x74\x75\x73\x3d\x25\x64" "\n",IlllI->status)
;Illll(
"\x20\x20\x54\x72\x61\x6e\x73\x66\x65\x72\x46\x6c\x61\x67\x73\x3d\x30\x78\x25\x30\x38\x58" "\n"
,IlllI->transfer_flags);Illll(
"\x20\x20\x42\x75\x66\x66\x65\x72\x3d\x30\x78\x25\x70" "\n",IlllI->
transfer_buffer);Illll(
"\x20\x20\x42\x75\x66\x66\x65\x72\x4c\x65\x6e\x67\x74\x68\x3d\x25\x64" "\n",
IlllI->transfer_buffer_length);Illll(
"\x20\x20\x41\x63\x74\x75\x61\x6c\x4c\x65\x6e\x67\x74\x68\x3d\x25\x64" "\n",
IlllI->actual_length);Illll(
"\x20\x20\x54\x72\x61\x6e\x73\x66\x65\x72\x44\x6d\x61\x3d\x30\x78\x25\x30\x38\x58" "\n"
,(u32)IlllI->transfer_dma);Illll(
"\x20\x20\x53\x65\x74\x75\x70\x44\x6d\x61\x3d\x30\x78\x25\x30\x38\x58" "\n",(u32
)IlllI->setup_dma);if(usb_pipebulk(IlllI->pipe)&&usb_pipeout(IlllI->pipe)&&IlllI
->transfer_buffer&&lIllIllI){IIlIlIlll(
"\x20\x20\x42\x75\x66\x66\x65\x72\x44\x75\x6d\x70\x3d",(unsigned char*)IlllI->
transfer_buffer,min((size_t)(0x3cf+2040-0xbb7),(size_t)(IlllI->
transfer_buffer_length)));}if(usb_pipebulk(IlllI->pipe)&&usb_pipein(IlllI->pipe)
&&IlllI->transfer_buffer&&!lIllIllI){IIlIlIlll(
"\x20\x20\x42\x75\x66\x66\x65\x72\x44\x75\x6d\x70\x3d",(unsigned char*)IlllI->
transfer_buffer,min((size_t)(0x781+2010-0xf4b),(size_t)(IlllI->actual_length)));
}if(usb_pipecontrol(IlllI->pipe)){Illll(
"\x20\x20\x53\x65\x74\x75\x70\x50\x61\x63\x6b\x65\x74\x3d\x25\x30\x32\x58\x20\x25\x30\x32\x58\x20\x25\x30\x32\x58\x20\x25\x30\x32\x58\x20\x25\x30\x32\x58\x20\x25\x30\x32\x58\x20\x25\x30\x32\x58\x20\x25\x30\x32\x58" "\n"
,IlllI->setup_packet[(0x16c6+1250-0x1ba8)],IlllI->setup_packet[
(0xa47+3671-0x189d)],IlllI->setup_packet[(0x145c+2742-0x1f10)],IlllI->
setup_packet[(0x144+9337-0x25ba)],IlllI->setup_packet[(0x1a02+1930-0x2188)],
IlllI->setup_packet[(0x283+3555-0x1061)],IlllI->setup_packet[(0x78a+3141-0x13c9)
],IlllI->setup_packet[(0x680+2661-0x10de)]);}else if(usb_pipeisoc(IlllI->pipe)){
int i;Illll("\x20\x20\x53\x74\x61\x72\x74\x46\x72\x61\x6d\x65\x3d\x25\x64" "\n",
IlllI->start_frame);Illll(
"\x20\x20\x4e\x75\x6d\x62\x65\x72\x4f\x66\x50\x61\x63\x6b\x65\x74\x73\x3d\x25\x64" "\n"
,IlllI->number_of_packets);Illll(
"\x20\x20\x49\x6e\x74\x65\x72\x76\x61\x6c\x3d\x25\x64" "\n",IlllI->interval);
Illll("\x20\x20\x45\x72\x72\x6f\x72\x43\x6f\x75\x6e\x74\x3d\x25\x64" "\n",IlllI
->error_count);Illll("\x20\x20\x49\x73\x6f\x46\x72\x61\x6d\x65\x73\x3d" "\n");
for(i=(0x65+7289-0x1cde);i<IlllI->number_of_packets;i++){Illll(
"\x20\x20\x20\x20\x5b\x25\x64\x5d\x20\x4f\x66\x66\x73\x65\x74\x3d\x25\x64\x20\x4c\x65\x6e\x67\x74\x68\x3d\x25\x64\x20\x41\x63\x74\x75\x61\x6c\x4c\x65\x6e\x67\x74\x68\x3d\x25\x64\x20\x53\x74\x61\x74\x75\x73\x3d\x25\x64" "\n"
,i,IlllI->iso_frame_desc[i].offset,IlllI->iso_frame_desc[i].length,IlllI->
iso_frame_desc[i].actual_length,IlllI->iso_frame_desc[i].status);}}else if(
usb_pipeint(IlllI->pipe)){Illll(
"\x20\x20\x49\x6e\x74\x65\x72\x76\x61\x6c\x3d\x25\x64" "\n",IlllI->interval);}
Illll(
"\x2d\x2d\x2d\x2d\x20\x55\x52\x42\x20\x45\x4e\x44\x20\x25\x73\x20\x2d\x2d\x2d\x2d" "\n"
,IlIIIIIl);}
#endif 
#ifndef _USBD_DEBUG_
void llllIII(const char*IlIIIIIl,IIlIl IlIlI){}
#else
static void IllllII(IIlIl IlIlI);void llllIII(const char*IlIIIIIl,IIlIl IlIlI){
int i;
if(!IlIlI){return;}Illll(
"\x2d\x2d\x2d\x2d\x20\x55\x4e\x52\x42\x20\x53\x54\x41\x52\x54\x20\x25\x73" "\n",
IlIIIIIl);switch(IlIlI->lllII.IIIIIIl){case lllllIIl:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x47\x45\x54\x5f\x44\x45\x53\x43\x52\x49\x50\x54\x4f\x52" "\n"
);IllllII(IlIlI);Illll(
"\x20\x20\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x52\x65\x71\x75\x65\x73\x74" "\n"
);Illll(
"\x20\x20\x20\x20\x52\x65\x71\x75\x65\x73\x74\x54\x79\x70\x65\x3d\x25\x64" "\n",
IlIlI->IIlllI.llIIIII);Illll(
"\x20\x20\x20\x20\x52\x65\x71\x75\x65\x73\x74\x52\x65\x63\x69\x70\x69\x65\x6e\x74\x3d\x25\x64" "\n"
,IlIlI->IIlllI.IIIIIllI);Illll(
"\x20\x20\x20\x20\x44\x65\x73\x63\x54\x79\x70\x65\x3d\x25\x64" "\n",IlIlI->
IIlllI.lIIlllll);Illll(
"\x20\x20\x20\x20\x44\x65\x73\x63\x49\x6e\x64\x65\x78\x3d\x25\x64" "\n",IlIlI->
IIlllI.IllIIlll);Illll(
"\x20\x20\x20\x20\x4c\x61\x6e\x67\x49\x64\x3d\x25\x64" "\n",IlIlI->IIlllI.
IIllIlIl);Illll(
"\x20\x20\x20\x20\x42\x75\x66\x66\x65\x72\x53\x69\x7a\x65\x3d\x25\x64" "\n",
IlIlI->IIlllI.IIllI);break;case IIlIIIll:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x53\x45\x54\x5f\x44\x45\x53\x43\x52\x49\x50\x54\x4f\x52" "\n"
);IllllII(IlIlI);Illll(
"\x20\x20\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x52\x65\x71\x75\x65\x73\x74" "\n"
);Illll("\x20\x20\x20\x20\x44\x65\x73\x63\x54\x79\x70\x65\x3d\x25\x64" "\n",
IlIlI->IIlllI.lIIlllll);Illll(
"\x20\x20\x20\x20\x44\x65\x73\x63\x49\x6e\x64\x65\x78\x3d\x25\x64" "\n\n",IlIlI
->IIlllI.IllIIlll);Illll(
"\x20\x20\x20\x20\x4c\x61\x6e\x67\x49\x64\x3d\x25\x64" "\n",IlIlI->IIlllI.
IIllIlIl);Illll(
"\x20\x20\x20\x20\x42\x75\x66\x66\x65\x72\x53\x69\x7a\x65\x3d\x25\x64" "\n",
IlIlI->IIlllI.IIllI);break;case IlIIIIII:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x53\x45\x4c\x45\x43\x54\x5f\x43\x4f\x4e\x46\x49\x47\x55\x52\x41\x54\x49\x4f\x4e" "\n"
);IllllII(IlIlI);Illll(
"\x20\x20\x53\x65\x6c\x65\x63\x74\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e" "\n"
);Illll(
"\x20\x20\x20\x20\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3d\x25\x64" "\n"
,IlIlI->IIIllll.lllIlIll);Illll(
"\x20\x20\x20\x20\x4e\x75\x6d\x41\x6c\x74\x65\x72\x6e\x61\x74\x65\x73\x3d\x25\x64" "\n"
,IlIlI->IIIllll.IIIllIlI);for(i=(0x9ec+3362-0x170e);i<IlIlI->IIIllll.IIIllIlI;i
++){Illll(
"\x20\x20\x20\x20\x20\x20\x25\x2e\x33\x64\x3a\x20\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x4e\x75\x6d\x3d\x25\x64" "\n"
,i,IlIlI->IIIllll.lIlllll[i].IlllIlI);Illll(
"\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x41\x6c\x74\x65\x72\x6e\x61\x74\x65\x4e\x75\x6d\x3d\x25\x64" "\n"
,IlIlI->IIIllll.lIlllll[i].IllIIII);}break;case IIIlIIIl:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x53\x45\x4c\x45\x43\x54\x5f\x49\x4e\x54\x45\x52\x46\x41\x43\x45" "\n"
);IllllII(IlIlI);Illll(
"\x20\x20\x53\x65\x6c\x65\x63\x74\x49\x6e\x74\x65\x72\x66\x61\x63\x65" "\n");
Illll("\x20\x20\x20\x20\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x3d\x25\x64" "\n",
IlIlI->llIlllI.IlllIlI);Illll(
"\x20\x20\x20\x20\x41\x6c\x74\x65\x72\x6e\x61\x74\x65\x3d\x25\x64" "\n",IlIlI->
llIlllI.IllIIII);break;case lllllIlI:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x43\x4f\x4e\x54\x52\x4f\x4c\x5f\x54\x52\x41\x4e\x53\x46\x45\x52" "\n"
);IllllII(IlIlI);Illll(
"\x20\x20\x43\x6f\x6e\x74\x72\x6f\x6c\x54\x72\x61\x6e\x73\x66\x65\x72" "\n");
Illll("\x20\x20\x20\x20\x45\x6e\x64\x70\x6f\x69\x6e\x74\x3d\x25\x64" "\n",IlIlI
->IIllIl.Endpoint);Illll(
"\x20\x20\x20\x20\x46\x6c\x61\x67\x73\x3d\x30\x78\x25\x2e\x32\x58" "\n",IlIlI->
IIllIl.Flags);Illll(
"\x20\x20\x20\x20\x52\x65\x71\x75\x65\x73\x74\x54\x79\x70\x65\x3d\x30\x78\x25\x2e\x32\x58" "\n"
,IlIlI->IIllIl.llIIIII);Illll(
"\x20\x20\x20\x20\x52\x65\x71\x75\x65\x73\x74\x3d\x30\x78\x25\x2e\x32\x58" "\n",
IlIlI->IIllIl.lIlllIIIl);Illll(
"\x20\x20\x20\x20\x56\x61\x6c\x75\x65\x3d\x30\x78\x25\x2e\x34\x58" "\n",IlIlI->
IIllIl.llIlIIII);Illll(
"\x20\x20\x20\x20\x49\x6e\x64\x65\x78\x3d\x30\x78\x25\x2e\x34\x58" "\n",IlIlI->
IIllIl.IlllIllIl);Illll(
"\x20\x20\x20\x20\x42\x75\x66\x65\x72\x53\x69\x7a\x65\x3d\x25\x64" "\n",IlIlI->
IIllIl.IIllI);break;case IIlIlllI:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x42\x55\x4c\x4b\x5f\x54\x52\x41\x4e\x53\x46\x45\x52" "\n"
);IllllII(IlIlI);Illll(
"\x20\x20\x42\x75\x6c\x6b\x54\x72\x61\x6e\x73\x66\x65\x72" "\n");Illll(
"\x20\x20\x20\x20\x45\x6e\x64\x70\x6f\x69\x6e\x74\x3d\x25\x64" "\n",IlIlI->llIll
.Endpoint);Illll(
"\x20\x20\x20\x20\x46\x6c\x61\x67\x73\x3d\x30\x78\x25\x2e\x32\x58" "\n",IlIlI->
llIll.Flags);Illll(
"\x20\x20\x20\x20\x42\x75\x66\x65\x72\x53\x69\x7a\x65\x3d\x25\x64" "\n",IlIlI->
llIll.IIllI);break;case llIIlIII:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x49\x4e\x54\x45\x52\x52\x55\x50\x54\x5f\x54\x52\x41\x4e\x53\x46\x45\x52" "\n"
);IllllII(IlIlI);Illll(
"\x20\x20\x49\x6e\x74\x65\x72\x72\x75\x70\x74\x54\x72\x61\x6e\x73\x66\x65\x72" "\n"
);Illll("\x20\x20\x20\x20\x45\x6e\x64\x70\x6f\x69\x6e\x74\x3d\x25\x64" "\n",
IlIlI->llIIlI.Endpoint);Illll(
"\x20\x20\x20\x20\x46\x6c\x61\x67\x73\x3d\x30\x78\x25\x2e\x32\x58" "\n",IlIlI->
llIIlI.Flags);Illll(
"\x20\x20\x20\x20\x49\x6e\x74\x65\x72\x76\x61\x6c\x3d\x25\x64" "\n",IlIlI->
llIIlI.Interval);Illll(
"\x20\x20\x20\x20\x42\x75\x66\x65\x72\x53\x69\x7a\x65\x3d\x25\x64" "\n",IlIlI->
llIIlI.IIllI);break;case IIIlIIII:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x49\x53\x4f\x43\x48\x5f\x54\x52\x41\x4e\x53\x46\x45\x52" "\n"
);IllllII(IlIlI);Illll(
"\x20\x20\x49\x73\x6f\x63\x68\x54\x72\x61\x6e\x73\x66\x65\x72" "\n");Illll(
"\x20\x20\x20\x20\x45\x6e\x64\x70\x6f\x69\x6e\x74\x3d\x25\x64" "\n",IlIlI->llIIl
.Endpoint);Illll(
"\x20\x20\x20\x20\x46\x6c\x61\x67\x73\x3d\x30\x78\x25\x2e\x32\x58" "\n",IlIlI->
llIIl.Flags);Illll(
"\x20\x20\x20\x20\x42\x75\x66\x65\x72\x53\x69\x7a\x65\x3d\x25\x64" "\n",IlIlI->
llIIl.IIllI);Illll(
"\x20\x20\x20\x20\x49\x6e\x74\x65\x72\x76\x61\x6c\x3d\x25\x64" "\n",IlIlI->llIIl
.Interval);Illll(
"\x20\x20\x20\x20\x53\x74\x61\x72\x74\x46\x72\x61\x6d\x65\x3d\x25\x64" "\n",
IlIlI->llIIl.llIIIIIl);Illll(
"\x20\x20\x20\x20\x4e\x75\x6d\x62\x65\x72\x4f\x66\x50\x61\x63\x6b\x65\x74\x73\x3d\x25\x64" "\n"
,IlIlI->llIIl.llIIIIl);Illll(
"\x20\x20\x20\x20\x45\x72\x72\x6f\x72\x43\x6f\x75\x6e\x74\x3d\x25\x64" "\n",
IlIlI->llIIl.IIllllIl);Illll(
"\x20\x20\x20\x20\x49\x73\x6f\x63\x68\x50\x61\x63\x6b\x65\x74\x73\x3a" "\n");for
(i=(0x1f41+6-0x1f47);i<IlIlI->llIIl.llIIIIl;i++){Illll(
"\x20\x20\x20\x20\x20\x20\x25\x2e\x33\x64\x3a\x20\x4f\x66\x66\x73\x65\x74\x3d\x25\x64" "\n"
,i,IlIlI->llIIl.llIIIlI[i].Offset);Illll(
"\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x4c\x65\x6e\x67\x74\x68\x3d\x25\x64" "\n"
,IlIlI->llIIl.llIIIlI[i].Length);Illll(
"\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x53\x74\x61\x74\x75\x73\x3d\x25\x64" "\n"
,IlIlI->llIIl.llIIIlI[i].Status);}break;case IIIIIIll:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x43\x4c\x45\x41\x52\x5f\x53\x54\x41\x4c\x4c" "\n"
);IllllII(IlIlI);Illll("\x20\x20\x43\x6c\x65\x61\x72\x53\x74\x61\x6c\x6c" "\n");
Illll("\x20\x20\x20\x20\x45\x6e\x64\x70\x6f\x69\x6e\x74\x3d\x25\x64" "\n",IlIlI
->llIIlII.Endpoint);Illll(
"\x20\x20\x20\x20\x46\x6c\x61\x67\x73\x3d\x30\x78\x25\x2e\x32\x58" "\n",IlIlI->
llIIlII.Flags);break;case lIIlIIll:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x47\x45\x54\x5f\x43\x55\x52\x52\x45\x4e\x54\x5f\x46\x52\x41\x4d\x45\x5f\x4e\x55\x4d\x42\x45\x52" "\n"
);IllllII(IlIlI);Illll(
"\x20\x20\x47\x65\x74\x43\x75\x72\x72\x65\x6e\x74\x46\x72\x61\x6d\x65\x4e\x75\x6d\x62\x65\x72" "\n"
);Illll(
"\x20\x20\x20\x20\x46\x72\x61\x6d\x65\x4e\x75\x6d\x62\x65\x72\x3d\x25\x64" "\n",
IlIlI->IllIlIll.llIIllIll);break;case llIIIlll:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x47\x45\x54\x5f\x50\x4f\x52\x54\x5f\x53\x54\x41\x54\x55\x53" "\n"
);IllllII(IlIlI);Illll(
"\x20\x20\x47\x65\x74\x50\x6f\x72\x74\x53\x74\x61\x74\x75\x73" "\n");switch(
IlIlI->IIIlllll.IIllIIlI){case IlIIlIIll:Illll(
"\x20\x20\x20\x20\x50\x6f\x72\x74\x53\x74\x61\x74\x75\x73\x3d\x45\x4e\x41\x42\x4c\x45\x44" "\n"
);break;case lIlIIllIl:Illll(
"\x20\x20\x20\x20\x50\x6f\x72\x74\x53\x74\x61\x74\x75\x73\x3d\x43\x4f\x4e\x4e\x45\x43\x54\x45\x44" "\n"
);break;default:Illll(
"\x20\x20\x20\x20\x50\x6f\x72\x74\x53\x74\x61\x74\x75\x73\x3d\x75\x6e\x6b\x6e\x6f\x77\x6e" "\n"
);break;}break;case IIIlllII:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x52\x45\x53\x45\x54\x5f\x50\x4f\x52\x54" "\n"
);IllllII(IlIlI);break;case llIIlIIl:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x43\x41\x4e\x43\x45\x4c" "\n"
);IllllII(IlIlI);break;case IlllIIlI:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x41\x42\x4f\x52\x54\x5f\x45\x4e\x44\x50\x4f\x49\x4e\x54" "\n"
);IllllII(IlIlI);Illll(
"\x20\x20\x41\x62\x6f\x72\x74\x45\x6e\x64\x70\x6f\x69\x6e\x74" "\n");Illll(
"\x20\x20\x20\x20\x45\x6e\x64\x70\x6f\x69\x6e\x74\x3d\x25\x64" "\n",IlIlI->
lIlIllII.Endpoint);Illll(
"\x20\x20\x20\x20\x46\x6c\x61\x67\x73\x3d\x30\x78\x25\x2e\x32\x58" "\n",IlIlI->
lIlIllII.Flags);break;default:Illll(
"\x55\x4e\x52\x42\x5f\x46\x55\x4e\x43\x54\x49\x4f\x4e\x5f\x75\x6e\x6b\x6e\x6f\x77\x6e" "\n"
);IllllII(IlIlI);break;}Illll(
"\x2d\x2d\x2d\x2d\x20\x55\x4e\x52\x42\x20\x45\x4e\x44\x20\x25\x73" "\n",IlIIIIIl
);}static void IllllII(IIlIl IlIlI){Illll(
"\x20\x20\x48\x65\x61\x64\x65\x72" "\n");Illll(
"\x20\x20\x20\x20\x55\x6e\x69\x71\x75\x65\x49\x64\x3d\x30\x78\x25\x2e\x38\x58\x25\x2e\x38\x58" "\n"
,(IIIIl)(IlIlI->lllII.IIllll>>(0x189f+2997-0x2434)),(IIIIl)(IlIlI->lllII.IIllll)
);Illll(
"\x20\x20\x20\x20\x53\x63\x72\x69\x70\x74\x3d\x30\x78\x25\x2e\x34\x58" "\n",(
IlllIl)IlIlI->lllII.lIIIlll);Illll(
"\x20\x20\x20\x20\x53\x69\x7a\x65\x3d\x25\x64" "\n",IlIlI->lllII.IlIll);Illll(
"\x20\x20\x20\x20\x46\x75\x6e\x63\x74\x69\x6f\x6e\x3d\x25\x64" "\n",IlIlI->lllII
.IIIIIIl);Illll("\x20\x20\x20\x20\x53\x74\x61\x74\x75\x73\x3d\x25\x64" "\n",
IlIlI->lllII.Status);Illll(
"\x20\x20\x20\x20\x43\x6f\x6e\x74\x65\x78\x74\x3d\x30\x78\x25\x2e\x38\x58" "\n",
IlIlI->lllII.Context);}
#endif 

