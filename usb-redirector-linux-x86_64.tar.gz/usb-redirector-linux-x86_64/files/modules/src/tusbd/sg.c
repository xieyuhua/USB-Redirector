/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#include "usbd.h"
#if KERNEL_GT_EQ((0x147+2590-0xb63),(0x116+7527-0x1e77),(0x4d0+8010-0x23fb))
int IIlIIllll(struct lIllIlll*IIIIll,size_t length,int llllIIlI){int i;size_t 
lIlIllIII=lIIIIll-(lIIIIll%llllIIlI);int num_sgs=(length+lIlIllIII-
(0x119+4008-0x10c0))/lIlIllIII;struct scatterlist*sg;
#if KERNEL_LT_EQ((0x755+6206-0x1f91),(0x19d+1671-0x81e),(0xa14+5385-0x1efb)) 

int IllllIIlI=((PAGE_SIZE-sizeof(*IIIIll->IlIlIIl))&~((0x72a+6774-0x2198)-
(0x822+5620-0x1e15)))/sizeof(*IIIIll->sg);
#else

int IllllIIlI=PAGE_SIZE/sizeof(*IIIIll->sg);
#endif
if(num_sgs>IllllIIlI){Illll(
"\x75\x73\x62\x64\x5f\x73\x67\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x74\x6f\x6f\x20\x6c\x61\x72\x67\x65" "\n"
);return-EOVERFLOW;}IIIIll->num_sgs=num_sgs;
#if KERNEL_LT_EQ((0x1470+1520-0x1a5e),(0xbdc+4163-0x1c19),(0x1046+599-0x127b)) 

IIIIll->sg=lllIlII(ALIGN(num_sgs*sizeof(*IIIIll->sg),sizeof(void*))+sizeof(*
IIIIll->IlIlIIl),GFP_KERNEL);IIIIll->IlIlIIl=(struct usb_sg_request*)((char*)
IIIIll->sg+ALIGN(num_sgs*sizeof(*IIIIll->sg),(0x22f+4322-0x1309)));IIIIll->
IlIlIIl->sg=IIIIll->sg;
#else

IIIIll->sg=lllIlII(num_sgs*sizeof(*IIIIll->IlIlIIl),GFP_KERNEL);IIIIll->IlIlIIl=
IIIIll->sg;
#endif
if(IIIIll->sg==NULL){Illll(
"\x75\x73\x62\x64\x5f\x73\x67\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x73\x67\x20\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64\x28\x31\x29" "\n"
);return-ENOMEM;}sg_init_table(IIIIll->sg,IIIIll->num_sgs);for_each_sg(IIIIll->
sg,sg,IIIIll->num_sgs,i){size_t lIllIII=min_t(size_t,length,lIlIllIII);void*
IIIIllIll=IllIIlI(lIllIII,GFP_KERNEL);if(IIIIllIll==NULL){break;}sg_set_buf(sg,
IIIIllIll,lIllIII);length-=lIllIII;}if(i<IIIIll->num_sgs){Illll(
"\x75\x73\x62\x64\x5f\x61\x6c\x6c\x6f\x63\x5f\x6e\x5f\x63\x6f\x70\x79\x5f\x70\x61\x72\x74\x69\x6f\x74\x69\x6f\x6e\x65\x64\x5f\x75\x6e\x72\x62\x3a\x20\x73\x67\x20\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64\x28\x32\x29" "\n"
);IIIIll->num_sgs=i;IIIIIIlII(IIIIll);return-ENOMEM;}return(0x801+4556-0x19cd);}
void IIIIIIlII(struct lIllIlll*IIIIll){if(IIIIll->sg){int i;struct scatterlist*
sg;for_each_sg(IIIIll->sg,sg,IIIIll->num_sgs,i){lIlIll(sg_virt(sg));}lIlIll(
IIIIll->sg);}IIIIll->sg=NULL;IIIIll->IlIlIIl=NULL;IIIIll->num_sgs=
(0x513+1305-0xa2c);}size_t IlIlllIIl(struct lIllIlll*IIIIll,const void __user*
IIIlI,size_t length){int i;size_t IIIll=(0x171+8765-0x23ae);struct scatterlist*
sg;for_each_sg(IIIIll->sg,sg,IIIIll->num_sgs,i){size_t IIlllll;if(length==
(0xa87+4402-0x1bb9)){break;}IIlllll=min_t(size_t,sg->length,length);if(
__copy_from_user(sg_virt(sg),IIIlI,IIlllll)){break;}length-=IIlllll;IIIlI+=
IIlllll;IIIll+=IIlllll;}return IIIll;}size_t llllIIlII(struct lIllIlll*IIIIll,
void __user*IIIlI,size_t length){int i;size_t IIIll=(0x18c7+104-0x192f);struct 
scatterlist*sg;for_each_sg(IIIIll->sg,sg,IIIIll->num_sgs,i){size_t IIlllll;if(
length==(0x7c0+2738-0x1272)){break;}IIlllll=min_t(size_t,sg->length,length);if(
__copy_to_user(IIIlI,sg_virt(sg),IIlllll)){break;}length-=IIlllll;IIIlI+=IIlllll
;IIIll+=IIlllll;}return IIIll;}
#endif 

