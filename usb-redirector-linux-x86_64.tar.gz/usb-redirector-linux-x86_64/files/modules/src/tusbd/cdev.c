/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#include "usbd.h"
#include <linux/ctype.h> 
#define llIlIlll (0xd35+1626-0x128f)
static struct cdev*IlIIlll=NULL;static dev_t IlIIIII=MKDEV((0x812+4620-0x1a1e),
(0xcb3+5456-0x2203));static void*lIlIIlII[llIlIlll]={(0xad7+5255-0x1f5e)};static
 struct mutex IllIlll;static struct class*IIIIIll=NULL;ssize_t lllIllllI(struct 
file*,char __user*,size_t,loff_t*);ssize_t llIllIllI(struct file*,const char 
__user*,size_t,loff_t*);long lllllllII(struct file*,unsigned int,unsigned long);
#ifdef CONFIG_COMPAT
long IllIIIlII(struct file*,unsigned int,unsigned long);
#endif
int IllIIllII(struct inode*,struct file*);int IllIllIll(struct inode*,struct 
file*);unsigned int IlIlIlIIl(struct file*lIlllI,poll_table*IIIIlI);int 
lIlIllllI(struct file*lIlllI,struct vm_area_struct*Illllll);
#if (RHEL_RELEASE_GT_EQ((0xd24+2614-0x1752),(0xce0+361-0xe40)) && \
RHEL_RELEASE_LT((0xe4c+4170-0x1e8d),(0x15+4416-0x1155))) || RHEL_RELEASE_GT_EQ(\
(0x66+6651-0x1a58),(0xee1+6141-0x26db))
static int IlIllIlI(const struct device*dev,struct kobj_uevent_env*IIlIIIl);
#elif KERNEL_LT_EQ((0x122f+3339-0x1f38),(0x9dc+1351-0xf1d),(0x11a9+488-0x137a)) 
static int IlIllIlI(struct class_device*dev,char**envp,int lIlIlllIl,char*lllll,
int llllIlIIl);static void IllllIIl(struct class_device*device);
#elif KERNEL_LT_EQ((0x85a+495-0xa47),(0x1a12+283-0x1b27),(0x94c+1852-0x106f)) 
static int IlIllIlI(struct class_device*dev,struct kobj_uevent_env*IIlIIIl);
static void IllllIIl(struct class_device*device);
#elif KERNEL_LT((0x1e41+376-0x1fb3),(0x263+3795-0x1134),(0x58b+6488-0x1ee3)) 
static int IlIllIlI(struct device*dev,struct kobj_uevent_env*IIlIIIl);
#else 
static int IlIllIlI(const struct device*dev,struct kobj_uevent_env*IIlIIIl);
#endif
static struct file_operations IlIlIllIl={.owner=THIS_MODULE,.read=lllIllllI,.
write=llIllIllI,.poll=IlIlIlIIl,.unlocked_ioctl=lllllllII,
#ifdef CONFIG_COMPAT
.compat_ioctl=IllIIIlII,
#endif
.mmap=lIlIllllI,.open=IllIIllII,.release=IllIllIll,};int llIlIIIlI(void){int 
IIIll=(0x1891+1470-0x1e4f);Illll(
"\x69\x6e\x69\x74\x5f\x63\x64\x65\x76\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x2b\x2b" "\n"
);do{mutex_init(&IllIlll);
#if KERNEL_GT_EQ((0x7f7+6475-0x213c),(0x13e9+2393-0x1d3e),(0xc58+6698-0x2682)) \
|| RHEL_RELEASE_GT_EQ((0x15d4+1183-0x1a6a),(0xf88+4991-0x2303)) 
IIIIIll=class_create(IIllIll);
#else 
IIIIIll=class_create(THIS_MODULE,IIllIll);
#endif
if(IIIIIll==NULL){Illll(
"\x69\x6e\x69\x74\x5f\x63\x64\x65\x76\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x63\x6c\x61\x73\x73\x5f\x63\x72\x65\x61\x74\x65\x20\x66\x61\x69\x6c\x65\x64\x2e" "\n"
);IIIll=-ENOMEM;break;}
#if KERNEL_LT_EQ((0x1117+4938-0x245f),(0x1bc1+1940-0x234f),(0x60+3487-0xdf0)) 
IIIIIll->hotplug=IlIllIlI,IIIIIll->release=IllllIIl,
#elif KERNEL_LT_EQ((0x6a5+2494-0x1061),(0x8e3+6190-0x210b),(0x436+8638-0x25db)) 
IIIIIll->uevent=IlIllIlI,IIIIIll->release=IllllIIl,
#else 
IIIIIll->dev_uevent=IlIllIlI,
#endif
IIIll=alloc_chrdev_region(&IlIIIII,(0xd43+3903-0x1c82),llIlIlll,IIllIll);if(
IIIll!=(0x127c+2432-0x1bfc)){Illll(
"\x69\x6e\x69\x74\x5f\x63\x64\x65\x76\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x61\x6c\x6c\x6f\x63\x5f\x63\x68\x72\x64\x65\x76\x5f\x72\x65\x67\x69\x6f\x6e\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x6e\x75\x6d\x62\x65\x72\x20\x25\x64" "\n"
,IIIll);break;}Illll(
"\x69\x6e\x69\x74\x5f\x63\x64\x65\x76\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x61\x6c\x6c\x6f\x63\x61\x74\x65\x64\x20\x64\x65\x76\x6e\x75\x6d\x20\x72\x65\x67\x69\x6f\x6e\x3a\x20\x4d\x61\x6a\x6f\x72\x20\x25\x64\x20\x4d\x69\x6e\x6f\x72\x20\x25\x64" "\n"
,MAJOR(IlIIIII),MINOR(IlIIIII));memset(lIlIIlII,(0x1f23+1891-0x2686),sizeof(
lIlIIlII));IlIIlll=cdev_alloc();if(IlIIlll==NULL){Illll(
"\x69\x6e\x69\x74\x5f\x63\x64\x65\x76\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x63\x64\x65\x76\x5f\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64\x2e" "\n"
);IIIll=-ENOMEM;break;}IlIIlll->owner=THIS_MODULE;IlIIlll->ops=&IlIlIllIl;IIIll=
cdev_add(IlIIlll,IlIIIII,llIlIlll);if(IIIll!=(0x533+3353-0x124c)){Illll(
"\x69\x6e\x69\x74\x5f\x63\x64\x65\x76\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x63\x64\x65\x76\x5f\x61\x64\x64\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x6e\x75\x6d\x62\x65\x72\x20\x25\x64" "\n"
,IIIll);break;}}while((0xf88+5949-0x26c5));if(IIIll!=(0x147b+2241-0x1d3c)){if(
IlIIlll){cdev_del(IlIIlll);}if(IlIIIII!=MKDEV((0xbf6+2631-0x163d),
(0x65+526-0x273))){unregister_chrdev_region(IlIIIII,(0x5e3+642-0x766));}if(
IIIIIll){class_destroy(IIIIIll);}IlIIlll=NULL;IlIIIII=MKDEV((0x1d0+3151-0xe1f),
(0x64f+5739-0x1cba));IIIIIll=NULL;}Illll(
"\x69\x6e\x69\x74\x5f\x63\x64\x65\x76\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}int IIIIllIII(void){Illll(
"\x64\x65\x73\x74\x72\x6f\x79\x5f\x63\x64\x65\x76" "\n");if(IlIIlll){cdev_del(
IlIIlll);}if(IlIIIII!=MKDEV((0x1c92+2631-0x26d9),(0x328+1536-0x928))){
unregister_chrdev_region(IlIIIII,llIlIlll);}if(IIIIIll){class_destroy(IIIIIll);}
IlIIlll=NULL;IlIIIII=MKDEV((0xef4+4550-0x20ba),(0x945+4662-0x1b7b));IIIIIll=NULL
;return(0x2488+397-0x2615);}
#if KERNEL_LT_EQ((0xaa4+4974-0x1e10),(0x1011+2841-0x1b24),(0x25b+3670-0x1098)) 
static void IllllIIl(struct class_device*device){kfree(device);}
#endif
#if KERNEL_LT_EQ((0xed6+4408-0x200c),(0x348+1735-0xa09),(0xe2d+8-0xe1e)) 
static int IlIllIlI(struct class_device*device,char**envp,int lIlIlllIl,char*
lllll,int llllIlIIl){struct IIIlll*IllII=device->class_data;if(IllII&&IllII->
IlIlllII){int i;int length;struct IllIlllI*IIllIII;for(IIllIII=IllII->IlIlllII,i
=(0x210+7717-0x2035),length=(0x1af3+2072-0x230b);IIllIII->name&&(IIllIII->
IIlIllII||IIllIII->IIllllII);IIllIII++){const char*IIlIllII=IIllIII->IIllllII?
IIllIII->IIllllII(IllII->context):IIllIII->IIlIllII;
#if KERNEL_LT_EQ((0xce1+6480-0x262f),(0x443+2689-0xebe),(0x225+6823-0x1cbd)) 
if(add_hotplug_env_var(
#else 
if(add_uevent_var(
#endif
envp,lIlIlllIl,&i,lllll,llllIlIIl,&length,"\x25\x73\x5f\x25\x73\x3d\x25\x73",
IIllIll,IIllIII->name,IIlIllII)==(0x1041+2618-0x1a7b)){int IIIIIl;for(IIIIIl=
(0x22a+7009-0x1d8b);envp[i-(0x1ab1+51-0x1ae3)][IIIIIl]!='\0'&&envp[i-
(0x567+3802-0x1440)][IIIIIl]!=((char)(0xc3+4367-0x1195));IIIIIl++)envp[i-
(0xdb+615-0x341)][IIIIIl]=toupper(envp[i-(0x1740+62-0x177d)][IIIIIl]);}}}return
(0xf6a+1716-0x161e);}
#else 
static int IlIllIlI(
#if (RHEL_RELEASE_GT_EQ((0x8a1+6520-0x2211),(0x199b+1954-0x2134)) && \
RHEL_RELEASE_LT((0x135+8741-0x2351),(0x1ea3+578-0x20e5))) || RHEL_RELEASE_GT_EQ(\
(0x272+2513-0xc3a),(0x463+5594-0x1a3a))
const struct device*device,
#elif KERNEL_LT_EQ((0x1600+14-0x160c),(0x1895+2294-0x2185),(0xa5a+215-0xb18)) 
struct class_device*device,
#elif KERNEL_LT((0x1a55+3031-0x2626),(0xea4+2770-0x1974),(0x122b+4926-0x2569)) 
struct device*device,
#else 
const struct device*device,
#endif
struct kobj_uevent_env*IIlIIIl){
#if KERNEL_LT_EQ((0x534+456-0x6fa),(0x1507+29-0x151e),(0x389+8004-0x22b4)) 
struct IIIlll*IllII=device->class_data;
#else 
struct IIIlll*IllII=dev_get_drvdata(device);
#endif
if(IllII&&IllII->IlIlllII){struct IllIlllI*IIllIII;for(IIllIII=IllII->IlIlllII;
IIllIII->name&&(IIllIII->IIlIllII||IIllIII->IIllllII);IIllIII++){const char*
IIlIllII=IIllIII->IIllllII?IIllIII->IIllllII(IllII->context):IIllIII->IIlIllII;
if(add_uevent_var(IIlIIIl,"\x25\x73\x5f\x25\x73\x3d\x25\x73",IIllIll,IIllIII->
name,IIlIllII)==(0xcc2+1641-0x132b)){int IIIIIl;for(IIIIIl=(0x2c1+223-0x3a0);
IIlIIIl->envp[IIlIIIl->envp_idx-(0xc02+3139-0x1844)][IIIIIl]!='\0'&&IIlIIIl->
envp[IIlIIIl->envp_idx-(0x1851+2775-0x2327)][IIIIIl]!=
((char)(0x50b+4953-0x1827));IIIIIl++)IIlIIIl->envp[IIlIIIl->envp_idx-
(0x1788+839-0x1ace)][IIIIIl]=toupper(IIlIIIl->envp[IIlIIIl->envp_idx-
(0xf4+7600-0x1ea3)][IIIIIl]);}}}return(0x472+2024-0xc5a);}
#endif 
int IlIIIIIIII(struct IIIlll*IllII,int IIlIII){















#if KERNEL_GT_EQ((0xea9+611-0x110a),(0x16aa+934-0x1a4a),(0x1201+3871-0x2105)) 
struct device*dev=NULL;dev=device_create(IIIIIll,NULL,MKDEV(MAJOR(IlIIIII),MINOR
(IlIIIII)+IIlIII),IllII,IIllIll"\x5f\x25\x64",IIlIII);
#elif KERNEL_EQ((0x572+2036-0xd64),(0x63d+4652-0x1863),(0x1d5c+1531-0x233d)) 
struct device*dev=NULL;dev=device_create_drvdata(IIIIIll,NULL,MKDEV(MAJOR(
IlIIIII),MINOR(IlIIIII)+IIlIII),IllII,IIllIll"\x5f\x25\x64",IIlIII);
#else 
struct class_device*dev=NULL;int IlllIIlll;dev=kzalloc(sizeof(*dev),GFP_KERNEL);
if(dev){dev->devt=MKDEV(MAJOR(IlIIIII),MINOR(IlIIIII)+IIlIII);dev->dev=NULL;dev
->class=IIIIIll;dev->parent=NULL;dev->release=NULL;
dev->class_data=IllII;
#if KERNEL_LT_EQ((0xb94+3611-0x19ad),(0xdcc+1693-0x1463),(0x31a+7744-0x214b)) 
dev->hotplug=NULL;
#else 
dev->uevent=NULL;
#endif
snprintf(dev->class_id,BUS_ID_SIZE,IIllIll"\x5f\x25\x64",IIlIII);IlllIIlll=
class_device_register(dev);if(IlllIIlll){kfree(dev);dev=ERR_PTR(IlllIIlll);}}
else{dev=ERR_PTR(-ENOMEM);}
#endif
if(IS_ERR(dev)){return PTR_ERR(dev);}IllII->dev=dev;return(0x495+2782-0xf73);}
void lIIIlIIII(struct IIIlll*IllII,int IIlIII){if(IllII->dev){
#if KERNEL_GT_EQ((0x11c9+3970-0x2149),(0x6b6+7871-0x256f),(0x1a5+9027-0x24ce)) 
device_destroy(IIIIIll,MKDEV(MAJOR(IlIIIII),MINOR(IlIIIII)+IIlIII));
#else 
class_device_destroy(IIIIIll,MKDEV(MAJOR(IlIIIII),MINOR(IlIIIII)+IIlIII));
#endif
IllII->dev=NULL;}}int llIIIlIl(struct IIIlll*IllII,int llllIIll,int lIllIIIl){
int i;if(lIllIIIl==-(0x10e5+4402-0x2216)){lIllIIIl=llIlIlll-(0xf9a+5642-0x25a3);
}if(llllIIll<(0x66d+3507-0x1420)||llllIIll>=llIlIlll){return-EINVAL;}if(lIllIIIl
<(0x7d1+4426-0x191b)||lIllIIIl>=llIlIlll){return-EINVAL;}if(llllIIll>lIllIIIl){
return-EINVAL;}mutex_lock(&IllIlll);for(i=llllIIll;i<=lIllIIIl;i++){if(lIlIIlII[
i]==NULL){if(IlIIIIIIII(IllII,i)==(0x7b2+670-0xa50)){IllII->IIlIII=i;lIlIIlII[i]
=IllII;if(IllII->ops.IIlIIIII){IllII->ops.IIlIIIII(IllII->context);}break;}}}
mutex_unlock(&IllIlll);if(i>lIllIIIl){return-EOVERFLOW;}return(0x5b3+987-0x98e);
}dev_t lIIlIIIlll(struct IIIlll*IllII){dev_t IIIll=MKDEV((0xb3+2301-0x9b0),
(0x4f4+3720-0x137c));mutex_lock(&IllIlll);if(IllII->IIlIII>=(0x345+1186-0x7e7)&&
IllII->IIlIII<llIlIlll){IIIll=MKDEV(MAJOR(IlIIIII),MINOR(IlIIIII)+IllII->IIlIII)
;}mutex_unlock(&IllIlll);return IIIll;}int lIIlIllI(struct IIIlll*IllII){int 
IIlIII;mutex_lock(&IllIlll);IIlIII=IllII->IIlIII;mutex_unlock(&IllIlll);return 
IIlIII;}void lIIlIIlI(struct IIIlll*IllII){int IIIIIlllI=(0x5f2+5057-0x19b3);
mutex_lock(&IllIlll);if(IllII->IIlIII>=(0x1fd2+860-0x232e)&&IllII->IIlIII<
llIlIlll&&lIlIIlII[IllII->IIlIII]==IllII){lIlIIlII[IllII->IIlIII]=NULL;lIIIlIIII
(IllII,IllII->IIlIII);IIIIIlllI=(0x14ec+1255-0x19d2);}IllII->IIlIII=-
(0x1314+4004-0x22b7);mutex_unlock(&IllIlll);if(IIIIIlllI){if(IllII->ops.IllIIllI
){IllII->ops.IllIIllI(IllII->context);}}}void llIlIIIIl(struct IIIlll*IllII){
#if KERNEL_LT_EQ((0x230+559-0x45d),(0x1763+2905-0x22b6),(0x528+3459-0x129c))
kobject_hotplug(&IllII->dev->kobj,KOBJ_ONLINE);
#else
kobject_uevent(&IllII->dev->kobj,KOBJ_ONLINE);
#endif
}void lllllIIII(struct IIIlll*IllII){
#if KERNEL_LT_EQ((0x9+4890-0x1321),(0x7ea+5347-0x1cc7),(0x78d+5293-0x1c2b))
kobject_hotplug(&IllII->dev->kobj,KOBJ_OFFLINE);
#else
kobject_uevent(&IllII->dev->kobj,KOBJ_OFFLINE);
#endif
}
ssize_t lllIllllI(struct file*lIlllI,char __user*llIIIIIII,size_t IlIII,loff_t*
lIllllIllI){struct IIIlll*IllII=lIlllI->private_data;if(IllII){if(IllII->ops.
read){return IllII->ops.read(IllII->context,llIIIIIII,IlIII);}else{return
(0x14fd+1969-0x1cae);}}return-ENODEV;}ssize_t llIllIllI(struct file*lIlllI,const
 char __user*llIIIIIII,size_t IlIII,loff_t*lIllllIllI){struct IIIlll*IllII=
lIlllI->private_data;if(IllII){if(IllII->ops.write){return IllII->ops.write(
IllII->context,llIIIIIII,IlIII);}else{return(0x10d1+2242-0x1993);}}return-ENODEV
;}unsigned int IlIlIlIIl(struct file*lIlllI,poll_table*IIIIlI){struct IIIlll*
IllII=lIlllI->private_data;if(IllII){if(IllII->ops.poll){return IllII->ops.poll(
IllII->context,lIlllI,IIIIlI);}else{return(0x1109+271-0x1218);}}return-ENODEV;}
long lllllllII(struct file*lIlllI,unsigned int lIIIIl,unsigned long IlIIII){
struct IIIlll*IllII=lIlllI->private_data;if(IllII){if(IllII->ops.unlocked_ioctl)
{return IllII->ops.unlocked_ioctl(IllII->context,lIIIIl,IlIIII);}else{return
(0x52a+8669-0x2707);}}return-ENODEV;}
#ifdef CONFIG_COMPAT
long IllIIIlII(struct file*lIlllI,unsigned int lIIIIl,unsigned long IlIIII){
struct IIIlll*IllII=lIlllI->private_data;if(IllII){if(IllII->ops.compat_ioctl){
return IllII->ops.compat_ioctl(IllII->context,lIIIIl,IlIIII);}else{return
(0x1020+3467-0x1dab);}}return-ENODEV;}
#endif
int lIlIllllI(struct file*lIlllI,struct vm_area_struct*Illllll){struct IIIlll*
IllII=lIlllI->private_data;if(IllII){if(IllII->ops.mmap){return IllII->ops.mmap(
IllII->context,Illllll);}else{return-EINVAL;}}return-ENODEV;}int IllIIllII(
struct inode*inode,struct file*lIlllI){int IIIll=-ENODEV;u32 m=iminor(inode);
struct IIIlll*IllII;mutex_lock(&IllIlll);IllII=lIlIIlII[m];if(IllII&&IllII->ops.
IIlIIIII){IllII->ops.IIlIIIII(IllII->context);}mutex_unlock(&IllIlll);if(IllII){
lIlllI->private_data=IllII;





mutex_lock(&IllII->mutex);if(IllII->ops.open){IIIll=IllII->ops.open(IllII->
context,++IllII->lllIllI);}else{IIIll=(0x13a4+1129-0x180d);}mutex_unlock(&IllII
->mutex);if(IIIll){if(IllII->ops.IllIIllI){IllII->ops.IllIIllI(IllII->context);}
}}return IIIll;}int IllIllIll(struct inode*inode,struct file*lIlllI){int IIIll=-
ENODEV;struct IIIlll*IllII=lIlllI->private_data;if(IllII){





mutex_lock(&IllII->mutex);if(IllII->ops.release){IIIll=IllII->ops.release(IllII
->context,--IllII->lllIllI);}else{IIIll=(0x12d+2927-0xc9c);}mutex_unlock(&IllII
->mutex);if(IllII->ops.IllIIllI){IllII->ops.IllIIllI(IllII->context);}}return 
IIIll;}
