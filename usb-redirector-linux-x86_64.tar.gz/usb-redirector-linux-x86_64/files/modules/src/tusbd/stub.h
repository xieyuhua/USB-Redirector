/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef llIIlIlll
#define llIIlIlll
#ifdef _USBD_ENABLE_STUB_
struct IlIIl{struct list_head llIIII;struct IIIlll*IllII;struct kref IllIll;u16 
vid;u16 lIllIIl;u16 lIIlIIl;char bus_id[BUS_ID_SIZE];struct usb_device*lIIlI;
char*IllIllII;int IlIllll;int lIlllIIl;int IlIIllll;int IlIlIII;int IlIllIl;int 
IlIIIlll;int lIlIIIll;
int llIlIIlI[(0x1533+3431-0x228a)];int lIIIlIII[(0x1853+974-0x1c11)];int 
IIIIlIIlI[(0x1172+1726-0x1820)];int IlIlllIII[(0x8a7+1005-0xc84)];
wait_queue_head_t IIIIlI;spinlock_t IlIlll;struct list_head llllIll;spinlock_t 
lllllll;struct list_head llIlIlIl;struct list_head lllIIlll;
int lIIIlII;int lllllIll;int IIlllllI;
int llIllII;int IlIlIIll;int IIIIIlll;int IllIlIII;int IIIlIl;
spinlock_t lIIIlI;struct lIlIII*IIIllII;};int IIlIlIlIl(void);void lIlIlIlll(
void);struct IlIIl*llIlIlllI(struct usb_device*llIII);void llllllIl(struct IlIIl
*lIlII);const char*lllIIllll(void*context);const char*IIllllIll(void*context);
int llIllIIl(struct usb_device*llIII);int lIIIllIIl(struct usb_device*llIII);int
 lIIIllll(struct usb_device*llIII);int lIIIIlllI(struct usb_interface*IIIIII,int
 IIIllIllll);void IlllIIIII(struct usb_interface*IIIIII);struct IlIIl*llIlllIl(
struct usb_device*llIII);void lIIllIllI(struct IlIIl*lIlII);void lIIIllIlI(
struct IlIIl*lIlII);int lIlllIlll(struct IlIIl*lIlII);void lIIlIIlIl(struct 
IlIIl*lIlII);void IlIlIllII(struct IlIIl*lIlII,int lllIlIl);void lIIIIIlII(
struct IlIIl*lIlII,int lllIlIl);int IIIllllII(struct IlIIl*lIlII,int pipe);int 
IlIIIIlI(struct IlIIl*lIlII,int pipe);void IlIllllllI(struct IlIIl*lIlII,int 
pipe);int IlllIlII(struct IlIIl*lIlII,int pipe);void IlIlllll(struct IlIIl*lIlII
,int pipe,int IlIIIlI);int IllIIllIl(struct usb_device*lIIlI,lIllIl endpoint);
void lIlIIlIIl(struct IlIIl*lIlII,struct usb_interface*lllIII,struct lIlIl*
IlIlIlI,int IllIlIl);void lIllIIlll(struct IlIIl*lIlII,int endpoint,struct lIlIl
*IlIlIlI);void IIIlIlII(struct IlIIl*lIlII,struct lIlIl*IlIlIlI,int lIlllIlII,
int IllIlIl);void lIIIlIlIl(struct IlIIl*lIlII,IlIIlI lllIl,struct lIlIl*IlIlIlI
);void llIIIllII(struct kref*IllIlII);static inline struct IlIIl*IIlllIII(struct
 IlIIl*lIlII){kref_get(&lIlII->IllIll);return lIlII;}static inline void lIIlIIIl
(struct IlIIl*lIlII){kref_put(&lIlII->IllIll,llIIIllII);}


#pragma pack(push,1)


struct llllIIIl{__le32 IllIlIIll;__u32 lIlllllllI;__le32 IllllIIIlI;__u8 
llIIIlIll;__u8 IlIIIlllII;__u8 llIlIIllIl;__u8 llIllIIlII[(0xbd6+6880-0x26a6)];}
__attribute__((packed));

struct IIIlIIIIl{__le32 IIlIIIIIll;__u32 IIIllIlIll;__le32 llIlIlIIIl;__u8 
llIIIlIIIl;}__attribute__((packed));
#pragma pack(pop)
#define lIlIIIlII (0x18d7+3434-0x2441)
struct lIlIII{struct IlIIl*lIlII;int ep_in;int ep_out;IlIIlI IlllIIIll;IlIIlI 
IlIlIIIlI;IlIIlI IIIIlIlII;struct lIlIl*lIIlIl;struct lIlIl*IllllIl;IIIIl 
IIlIlIll;int lIIllIlI;int status;struct kref IllIll;struct urb*IlllI;void*lllll;
int lllIlIlI;
int IlIIIIl;int IllIlIl;};enum lIIIIlIIlI{llllllll=(0x11b4+3793-0x2085),
IIIlIlIII,lllIIlIl,IIlIIIlIl,lllIIIII,lllllII};int IlIIIIll(struct IlIIl*lIlII);
int IlllIIlIl(struct lIlIl*lIlll,gfp_t lIIIl);
#endif 
#endif 

