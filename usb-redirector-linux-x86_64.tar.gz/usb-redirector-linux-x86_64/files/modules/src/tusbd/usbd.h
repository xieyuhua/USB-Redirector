/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/ioctl.h>
#include <linux/usb.h>
#include <linux/types.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/poll.h>
#include <linux/spinlock.h>
#include <linux/list.h>
#include <linux/version.h>
#include <linux/kref.h>
#include <linux/device.h>
#include <linux/compat.h>
#include <linux/mm.h>
#include <linux/vmalloc.h>
#include <linux/module.h>
#include <asm/uaccess.h>
#define KERNEL_GT(IlIlIll,lIlIIlI,IlIIlIIl)			(LINUX_VERSION_CODE > \
KERNEL_VERSION((IlIlIll),(lIlIIlI),(IlIIlIIl)))
#define KERNEL_LT(IlIlIll,lIlIIlI,IlIIlIIl)			(LINUX_VERSION_CODE < \
KERNEL_VERSION((IlIlIll),(lIlIIlI),(IlIIlIIl)))
#define KERNEL_EQ(IlIlIll,lIlIIlI,IlIIlIIl)			(LINUX_VERSION_CODE == \
KERNEL_VERSION((IlIlIll),(lIlIIlI),(IlIIlIIl)))
#define KERNEL_GT_EQ(IlIlIll,lIlIIlI,IlIIlIIl)			(LINUX_VERSION_CODE >= \
KERNEL_VERSION((IlIlIll),(lIlIIlI),(IlIIlIIl)))
#define KERNEL_LT_EQ(IlIlIll,lIlIIlI,IlIIlIIl)			(LINUX_VERSION_CODE <= \
KERNEL_VERSION((IlIlIll),(lIlIIlI),(IlIIlIIl)))
#if defined(RHEL_RELEASE_CODE) 
#define RHEL_RELEASE_GT(IlIlIll,lIlIIlI) 		(RHEL_RELEASE_CODE > \
RHEL_RELEASE_VERSION((IlIlIll),(lIlIIlI)))
#define RHEL_RELEASE_LT(IlIlIll,lIlIIlI)		(RHEL_RELEASE_CODE < \
RHEL_RELEASE_VERSION((IlIlIll),(lIlIIlI)))
#define RHEL_RELEASE_EQ(IlIlIll,lIlIIlI)		(RHEL_RELEASE_CODE == \
RHEL_RELEASE_VERSION((IlIlIll),(lIlIIlI)))
#define RHEL_RELEASE_GT_EQ(IlIlIll,lIlIIlI)		(RHEL_RELEASE_CODE >= \
RHEL_RELEASE_VERSION((IlIlIll),(lIlIIlI)))
#define RHEL_RELEASE_LT_EQ(IlIlIll,lIlIIlI)		(RHEL_RELEASE_CODE <= \
RHEL_RELEASE_VERSION((IlIlIll),(lIlIIlI)))
#else
#define RHEL_RELEASE_GT(IlIlIll,lIlIIlI) 		(0xfcf+5935-0x26fe)
#define RHEL_RELEASE_LT(IlIlIll,lIlIIlI)		(0x16d3+693-0x1988)
#define RHEL_RELEASE_EQ(IlIlIll,lIlIIlI)		(0x53b+7407-0x222a)
#define RHEL_RELEASE_GT_EQ(IlIlIll,lIlIIlI)		(0xb3+4872-0x13bb)
#define RHEL_RELEASE_LT_EQ(IlIlIll,lIlIIlI)		(0x1d91+1225-0x225a)
#endif

#ifndef BUS_ID_SIZE
#define BUS_ID_SIZE (0x9f6+804-0xd06)
#endif
#include "../public/pubstt2.h"
#include "../public/apitypes.h"
#include "../public/pubuniprotocol.h"
#include "../public/interface.h"
#include "../public/public_devices.h"
#include "utils.h"
#include "driver.h"
#include "cdev.h"
#include "stub.h"
#include "vhci.h"
#include "minor_loader.h"
#include "minor_stub.h"
#include "minor_vbus.h"
#include "minor_vstub.h"
#include "urb_chain.h"
#include "sg.h"

#if KERNEL_LT_EQ((0xe8+7306-0x1d70),(0x200c+697-0x22bf),(0x1584+1463-0x1b2c))
#define llIlllIII __stringify(KBUILD_MODNAME)
#else
#define llIlllIII KBUILD_MODNAME
#endif

#ifndef CONFIG_PRINTK_TIME
#define IIIlIlll(lIIllll, IIIIlIl...) printk(KERN_DEBUG \
"\x5b\x25\x30\x39\x75\x5d\x20\x25\x73\x3a\x20" lIIllll, jiffies_to_msecs(jiffies\
), llIlllIII, ## IIIIlIl)
#else
#define IIIlIlll(lIIllll, IIIIlIl...) printk(KERN_DEBUG "\x25\x73\x3a\x20" \
lIIllll, llIlllIII, ## IIIIlIl)
#endif

#define llIIlIIII(IIlIllIl,IIllllIII,IIlIIlII) do { \
	char IlllIlIl[(0x2ea+5339-0x1761)]; \
	char *lIIllIIl; \
	size_t i; \
	for(i=(0xef2+654-0x1180),lIIllIIl=IlllIlIl;i<(IIlIIlII);i++) \
	{ \
		if((i%(0x14fd+157-0x1592)) == (0x391+4857-0x168a) && i > (0x5db+2510-0xfa9)) \
		{ \
			Illll(IIlIllIl "\x25\x73" "\n", IlllIlIl); \
			lIIllIIl=IlllIlIl; \
		} \
		sprintf(lIIllIIl,"\x25\x30\x32\x58\x20", (IIllllIII)[i]); \
		lIIllIIl+=(0x254+3306-0xf3b); \
	} \
	if(lIIllIIl!=IlllIlIl) IIIlIlll(IIlIllIl "\x25\x73" "\n", IlllIlIl); \
} while ((0xe0a+724-0x10de))

#define IlIIIlIII(IIlIllIl,IIllllIII,IIlIIlII) do { \
	char IlllIlIl[(0x755+6555-0x208c)]; \
	char *lIIllIIl; \
	size_t i; \
	for(i=(0xd41+1077-0x1176),lIIllIIl=IlllIlIl;(i<(IIlIIlII))&&(i<\
(0x209+5638-0x17ef));i++,lIIllIIl+=(0x96b+5223-0x1dcf)) \
	{ \
		sprintf(lIIllIIl,"\x25\x30\x32\x58\x20", ((unsigned char*)(IIllllIII))[i]); \
	} \
	if(i>(0x9ac+3568-0x179c)) {IIIlIlll(IIlIllIl "\x20\x25\x73\x25\x73" "\n", \
IlllIlIl, (i<(IIlIIlII)) ? "\x2e\x2e\x2e" : "");} \
} while ((0x584+3786-0x144e))

#ifdef _USBD_DEBUG_
#define Illll(lIIllll, IIIIlIl...) IIIlIlll(lIIllll, ##IIIIlIl)
#define IIlll(lIIllll, IIIIlIl...) IIIlIlll("\x25\x73\x3a\x20" lIIllll, __func__\
, ##IIIIlIl)
#define lllIIllII(IllIIlIl,lIllllII,IIlIllll) llIIlIIII(IllIIlIl,lIllllII,\
IIlIllll)
#define IIlIlIlll(IllIIlIl,lIllllII,IIlIllll) IlIIIlIII(IllIIlIl,lIllllII,\
IIlIllll)
#else
#define Illll(lIIllll, IIIIlIl...) do {} while((0x4a9+7543-0x2220))
#define IIlll(lIIllll, IIIIlIl...) do {} while((0x6d6+2364-0x1012))
#define lllIIllII(IllIIlIl,lIllllII,IIlIllll) do {} while((0x12e5+1598-0x1923))
#define IIlIlIlll(IllIIlIl,lIllllII,IIlIllll) do {} while((0x1769+3637-0x259e))
#endif

#define llIlII(lIIllll, IIIIlIl...) IIIlIlll(lIIllll, ##IIIIlIl)
#define IIllIIlIlI(IllIIlIl,lIllllII,IIlIllll) llIIlIIII(IllIIlIl,lIllllII,\
IIlIllll)
#define lllIlIlIl(IllIIlIl,lIllllII,IIlIllll) IlIIIlIII(IllIIlIl,lIllllII,\
IIlIllll)
extern size_t lIIIIll;
#if KERNEL_LT_EQ((0x5e9+2331-0xf02),(0xd25+2200-0x15b7),(0x3a3+897-0x70d))
typedef unsigned long uintptr_t;
#endif
#if KERNEL_LT_EQ((0x14e5+1221-0x19a8),(0x6aa+3247-0x1353),(0x1a40+1402-0x1fab))
#define atomic_xchg(lIIlllIIIl, new) (xchg(&((lIIlllIIIl)->counter), new))
#endif
#if KERNEL_LT((0x279+2413-0xbe3),(0xabb+3499-0x1854),(0xc93+3916-0x1bdf))




#undef strncasecmp
#define strncasecmp strnicmp
#endif

