/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IIIIlIIll
#define IIIIlIIll
#ifdef _USBD_ENABLE_STUB_
#include "cdev.h"
int IllIlIIII(struct IlIIl*lIlII);void IIlllIIIl(struct IlIIl*lIlII);int 
IIllllIIl(struct IlIIl*lIlII);void lllIlIIII(struct IlIIl*lIlII);
#endif 
#endif 

