/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef lIIlIllII
#define lIIlIllII
#include "urb_chain.h"
#include "sg.h"

#define lllIIIIl		(0x8ed+1723-0xfa8)
#define llIlIll		(0xb07+1092-0xf4a)
#define IllIIll		(0x5ea+6420-0x1efc)
#define lllIlllII	(0x8f4+6671-0x2300)
#define IIIIlII		(0x185a+1918-0x1fd4)

#define IIlIlI		(0xd14+6247-0x257b) 
#define llIIlIl	(0xe78+1424-0x1407) 
#if KERNEL_GT_EQ((0x68b+4757-0x191e),(0x16f1+516-0x18ef),(0x7b1+7819-0x261d))
#define lllIIII			(0x1c8+7607-0x1f7d) 
#endif
struct lIlIl{size_t IllllI;struct kref IllIll;atomic_t state;IlIIlI lllIl;int 
lIllll;
IlIllIlIl IIIIIlI;lIllIl endpoint;
struct list_head llllIl;struct IlIIl*lIlII;union{struct{struct urb*IlllI;
void*lllll;
}lIIIll;struct{struct llllll*llllIlI;
struct IIlIIll*llIllI;
}lIllII;
#if KERNEL_GT_EQ((0x123b+1375-0x1798),(0x10c6+669-0x135d),(0x635+5859-0x1cf9))
struct{struct urb*IlllI;
struct lIllIlll sg;}lIIllII;
#endif
};char IlIIIIl:(0xb46+6778-0x25bf);
char IllIlIl:(0x133b+1101-0x1787);



};struct IllllIII{struct list_head llIIII;
IlIIlI lllIl;int lllIlllIl;int IlllllllI;};
#ifdef _USBD_DEBUG_MEMORY_
extern atomic_t llIIlIllI;extern atomic_t lllllIlIl;extern atomic_t IlIIllII;
extern atomic_t IIIIIllII;
#ifdef ATOMIC64_INIT
extern atomic64_t lIIIIlll;
#endif
static inline struct urb*IIIlllIl(int lIIllIlIl,gfp_t lIIIl){atomic_inc(&
llIIlIllI);return usb_alloc_urb(lIIllIlIl,lIIIl);}static inline void lIIIlIIl(
struct urb*urb){atomic_inc(&lllllIlIl);usb_free_urb(urb);}static inline void*
IllIIlI(size_t IllllI,int flags){atomic_inc(&IlIIllII);
#ifdef ATOMIC64_INIT
atomic64_add(IllllI,&lIIIIlll);
#endif
return kmalloc(IllllI,flags);}static inline void*lllIlII(size_t IllllI,int flags
){atomic_inc(&IlIIllII);
#ifdef ATOMIC64_INIT
atomic64_add(IllllI,&lIIIIlll);
#endif
return kzalloc(IllllI,flags);}static inline void lIlIll(const void*lIllIlIII){
atomic_inc(&IIIIIllII);return kfree(lIllIlIII);}
#else 
#define	IIIlllIl	usb_alloc_urb
#define	lIIIlIIl	usb_free_urb
#define	IllIIlI		kmalloc
#define	lllIlII		kzalloc
#define	lIlIll			kfree
#endif 
#ifdef _USBD_ENABLE_STUB_
struct lIlIl*llIlIIlII(struct IlIIl*lIlII,const void __user*IIIlI,size_t llIlIIl
);int IllIlIlIl(struct lIlIl*lIlll,void __user*IIIlI,size_t llIlIIl);struct 
lIlIl*IIIIIIlll(struct lIlIl*lIlll,gfp_t lIIIl);void llIllll(struct lIlIl*lIlll)
;void IlIlIlll(struct kref*IllIlII);
#endif
void lIIlIIIlI(struct usb_device*llIII,u8*IIlllIlI,u8*IlIIIlIl,u8*IIIlIllI);
const char*IlIllIII(unsigned long IIlIIlI);const char*lllllIllI(unsigned long 
IIlIIlI);void IIlIIIIlI(const char*IlIIIIIl,struct urb*IlllI,IlIIlI lllIl,int 
lIllIllI);void llllIII(const char*IlIIIIIl,IIlIl IlIlI);
#ifdef _USBD_ENABLE_VHCI_
int IllIIlIll(struct list_head*IIlIllI,IlIIlI lllIl,void*lllll,size_t IlIIIl);
int IIIlIIIlI(IIlIl IlIlI,struct list_head*IIlIllI,int*status);
#endif
int lIIlIlll(IIIIl status);int llllllIIl(void*IlIIIIlIl,struct vm_area_struct*
Illllll);IlIIlI lllIlIlll(void);size_t IIlIIlIl(struct usb_iso_packet_descriptor
*lIlIIlIl,int IlIII,void*IIIlIIl,void*lllIll,int lIIlIIII);size_t IlIllIIll(
struct usb_iso_packet_descriptor*lIlIIlIl,int IlIII,int lIIlIIII);void lIIlIIlII
(dma_addr_t IIIlIIl,void*lllIll,unsigned long IIlIIl);void lllIIllIl(void*
IIIlIIl,dma_addr_t lllIll,unsigned long IIlIIl);char*lIllllIIl(struct kobject*
kobj,gfp_t llIIIIIll);void llIIIIIlI(char*llIlIlI);int IIIllIlll(struct device*
dev);int IlIllllII(struct device*dev);int IlIIIlllI(struct device*dev);
#if KERNEL_GT_EQ((0x13f3+1364-0x1945),(0xf8d+5673-0x25b0),(0xc5b+966-0x100b))
void llllIIII(struct device*dev,int llIlIlIll);int lIIllIll(struct device*dev);
#endif
#if KERNEL_GT_EQ((0xb60+348-0xcba),(0xf95+1588-0x15c3),(0x1a3d+3093-0x2634))
#define llIIIl(IlIlIllll) dev_name((IlIlIllll))
#else
#define llIIIl(IlIlIllll) (IlIlIllll)->bus_id
#endif
#if KERNEL_GT_EQ((0xf6d+3864-0x1e81),(0x7ff+23-0x80a),(0xe89+4466-0x1ffb))
#define lIllIIll(IIIIllII) ((IIIIllII)->bus->controller->driver ? \
			(IIIIllII)->bus->controller->driver->name : (IIIIllII)->bus->sysdev->driver->\
name)
#else
#define lIllIIll(IIIIllII) ((IIIIllII)->bus->controller->driver->name)
#endif
#if KERNEL_LT_EQ((0xd67+2125-0x15b2),(0x1814+3756-0x26ba),(0x152f+4430-0x266e))
#include <asm/semaphore.h>
struct mutex{struct semaphore lIlIIIIlI;};static inline void mutex_init(struct 
mutex*mutex){sema_init(&mutex->lIlIIIIlI,(0x922+2888-0x1469));}static inline 
void mutex_lock(struct mutex*mutex){down(&mutex->lIlIIIIlI);}static inline void 
mutex_unlock(struct mutex*mutex){up(&mutex->lIlIIIIlI);}
#endif
#endif 

