/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifdef _USBD_ENABLE_STUB_
#include "usbd.h"
#include "loader.h"
#if KERNEL_LT_EQ((0x144a+3483-0x21e3),(0x170d+506-0x1901),(0x33c+2002-0xae8))
#include <linux/smp_lock.h>
#endif
#if KERNEL_GT_EQ((0x1663+3640-0x2499),(0x1367+665-0x15fa),(0xe6f+5451-0x239b))
#if KERNEL_LT_EQ((0x50+2135-0x8a4),(0x9fd+2287-0x12ea),(0xb56+6578-0x2508))



#include "vhci_hcd.h"
#endif
#endif
static struct list_head IlllIll;static spinlock_t lllIIl;extern struct IIIlll*
llIIIlII;extern struct list_head IlIllIll;extern struct mutex IllllllI;extern 
struct list_head IlllIIll;extern struct mutex IIlllIll;extern struct list_head 
lIIIIIIl;extern struct mutex IlllllIl;
#if KERNEL_LT_EQ((0x752+4893-0x1a6d),(0xc58+3194-0x18cc),(0x1f51+1403-0x24b9))
extern struct notifier_block IIllllll;
#else 
extern struct notifier_block llIIIllI;
#endif
#ifdef _USBD_DEBUG_MEMORY_
extern atomic_t IIIIlllII;extern atomic_t lIIIIIII;extern atomic_t IlIIlIlll;
#endif 


static struct usb_device_id IIlIllllI[]={{.driver_info=(0x3c9+8458-0x24d2)},{}};
MODULE_DEVICE_TABLE(usb,IIlIllllI);static int IlIIIIlII(struct usb_interface*
IIIIII,const struct usb_device_id*id);static void IIIllllll(struct usb_interface
*IIIIII);
#if KERNEL_GT_EQ((0x103d+3970-0x1fbd),(0x659+20-0x667),(0x799+762-0xa7c))
static int lllIIIll(struct usb_interface*lllIII);static int lIlIIIII(struct 
usb_interface*lllIII);
#elif KERNEL_GT_EQ((0xc78+1685-0x130b),(0x1dc+5462-0x172c),(0x147c+2819-0x1f6d))
static void lllIIIll(struct usb_interface*lllIII);static void lIlIIIII(struct 
usb_interface*lllIII);
#endif
void lIlllllI(struct IlIIl*lIlII,int IlIIIIl,int IlllllII);void IIlllIIl(struct 
IlIIl*lIlII);int lIIlIlIlI(struct IlIIl*lIlII,IlIIlI lllIl);void llIIIIII(struct
 IlIIl*lIlII,IlIIlI lllIl);struct lIlIl*Illlllll(struct IlIIl*lIlII,IlIIlI lllIl
);struct usb_driver lIIlllI={.name=IlIllIIl,.id_table=IIlIllllI,.probe=IlIIIIlII
,.disconnect=IIIllllll,
#if KERNEL_GT_EQ((0x1918+2821-0x241b),(0x2099+1560-0x26ab),(0x14a8+2773-0x1f6b))
.pre_reset=lllIIIll,.post_reset=lIlIIIII,
#endif
};


static int IlIIIIlII(struct usb_interface*IIIIII,const struct usb_device_id*id){
int IIIll=-ENODEV;int IlIIllIIl=(0x4db+3701-0x1350);struct usb_device*llIII=
interface_to_usbdev(IIIIII);const char*llIlIlI=lIllllIIl(&llIII->dev.kobj,
GFP_KERNEL);IIlll(
"\x76\x69\x64\x3d\x30\x78\x25\x30\x34\x58\x20\x70\x69\x64\x3d\x30\x78\x25\x30\x34\x58\x20\x72\x65\x76\x3d\x30\x78\x25\x30\x34\x58\x20\x62\x75\x73\x5f\x69\x64\x3d" "\"" "\x25\x73" "\"" "\x20\x68\x75\x62\x3d" "\"" "\x25\x73" "\"" "\x20\x70\x61\x74\x68\x3d" "\"" "\x25\x73" "\"" "\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3d\x25\x75\x20\x74\x6f\x74\x61\x6c\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x3d\x25\x75" "\n"
,le16_to_cpu(llIII->descriptor.idVendor),le16_to_cpu(llIII->descriptor.idProduct
),le16_to_cpu(llIII->descriptor.bcdDevice),llIIIl(&llIII->dev),lIllIIll(llIII),
llIlIlI,IIIIII->cur_altsetting->desc.bInterfaceNumber,llIII->actconfig->desc.
bNumInterfaces);if(llIlIlI){kfree(llIlIlI);}if(lIIIllll(llIII)){IlIIllIIl=
(0x185+8556-0x22f0);}else if(IllllIll(llIII)){IIIll=llIllIIl(llIII);if(IIIll<
(0x1151+1622-0x17a7)){llIlII(
"\x63\x61\x6e\x20\x6e\x6f\x74\x20\x61\x74\x74\x61\x63\x68\x20\x75\x73\x62\x20\x64\x65\x76\x69\x63\x65\x20\x25\x73\x2c\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,llIIIl(&llIII->dev),IIIll);}else{IlIIllIIl=(0x154+7927-0x204a);}}if(IlIIllIIl){
IIIll=lIIIIlllI(IIIIII,(0xb9a+3068-0x1796));if(IIIll<(0x1275+4162-0x22b7)){
llIlII(
"\x63\x61\x6e\x20\x6e\x6f\x74\x20\x61\x74\x74\x61\x63\x68\x20\x75\x73\x62\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x73\x2c\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,llIIIl(&IIIIII->dev),IIIll);}}return IIIll;}
static void IIIllllll(struct usb_interface*IIIIII){IIlll("\x2b\x2b" "\n");if(
usb_get_intfdata(IIIIII)!=(void*)-(0x108+7768-0x1f5f)){IlllIIIII(IIIIII);}IIlll(
"\x2d\x2d" "\n");}
#if KERNEL_GT_EQ((0x57+5906-0x1767),(0x6f8+1790-0xdf0),(0x2088+516-0x2275))
static int lllIIIll(struct usb_interface*lllIII){return(0x4f9+2776-0xfd1);}
static int lIlIIIII(struct usb_interface*lllIII){return(0xf76+4673-0x21b7);}
#elif KERNEL_GT_EQ((0x1939+2608-0x2367),(0x1450+1890-0x1bac),(0x288+114-0x2e8))
static void lllIIIll(struct usb_interface*lllIII){return;}static void lIlIIIII(
struct usb_interface*lllIII){return;}
#endif


int lIIIllll(struct usb_device*llIII){int IIlllIlll=(0x231a+976-0x26ea);struct 
IlIIl*lIlII;spin_lock(&lllIIl);list_for_each_entry(lIlII,&IlllIll,llIIII){if(
lIlII->lIIlI==llIII){IIlllIlll=(0x222+863-0x580);break;}}spin_unlock(&lllIIl);
return IIlllIlll;}
int llIllIIl(struct usb_device*llIII){IIlll("\x2b\x2b\x20\x25\x73" "\n",llIIIl(&
llIII->dev));if(llIlIlllI(llIII)==NULL){IIlll(
"\x63\x61\x6e\x20\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x73\x74\x75\x62" "\n"
);return-ENOMEM;}IIlll("\x2d\x2d" "\n");return(0x17cf+474-0x19a9);}
int lIIIllIIl(struct usb_device*llIII){struct IlIIl*lIlII;IIlll(
"\x2b\x2b\x20\x25\x73" "\n",llIIIl(&llIII->dev));lIlII=llIlllIl(llIII);if(lIlII)
{IIIlIlII(lIlII,NULL,(0x36b+3227-0x1006),(0x18b0+3376-0x25df));llllllIl(lIlII);
lIIlIIIl(lIlII);}else{IIlll(
"\x64\x65\x76\x69\x63\x65\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n");}IIlll(
"\x2d\x2d" "\n");return(0xdcc+216-0xea4);}int lIIIIlllI(struct usb_interface*
IIIIII,int IIIlIlIlll){int IIIll=-ENODEV;struct usb_device*llIII=
interface_to_usbdev(IIIIII);struct IlIIl*lIlII;IIlll("\x2b\x2b" "\n");lIlII=
llIlllIl(llIII);if(lIlII){


lIlII->lIlllIIl+=IIIlIlIlll;lIlII->IlIIIlll=llIII->actconfig?llIII->actconfig->
desc.bNumInterfaces:(0x8e5+958-0xca3);if(++lIlII->lIlIIIll==lIlII->IlIIIlll){
lIIllIllI(lIlII);}IIlll(
"\x69\x6e\x69\x74\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x3d\x25\x64\x20\x74\x6f\x74\x61\x6c\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x3d\x25\x64" "\n"
,lIlII->lIlIIIll,lIlII->IlIIIlll);usb_set_intfdata(IIIIII,lIlII);
IIIll=(0xed9+124-0xf55);}IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}
void IlllIIIII(struct usb_interface*IIIIII){struct IlIIl*lIlII;IIlll(
"\x2b\x2b" "\n");
lIlII=usb_get_intfdata(IIIIII);usb_set_intfdata(IIIIII,NULL);lIlII->lIlIIIll--;
lIIIllIlI(lIlII);
lIlIIlIIl(lIlII,IIIIII,NULL,(0x4f7+6634-0x1ee0));IIlll(
"\x69\x6e\x69\x74\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x3d\x25\x64\x20\x74\x6f\x74\x61\x6c\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x3d\x25\x64" "\n"
,lIlII->lIlIIIll,lIlII->IlIIIlll);lIIlIIIl(lIlII);
IIlll("\x2d\x2d" "\n");}

int IIlIlIlIl(void){int lIIIlIllI=(0x1321+1270-0x1817);int IIIIIIlIl=
(0x6f5+1392-0xc65);int IIIll=(0x175f+3819-0x264a);do{INIT_LIST_HEAD(&IlllIll);
spin_lock_init(&lllIIl);INIT_LIST_HEAD(&IlIllIll);mutex_init(&IllllllI);
INIT_LIST_HEAD(&IlllIIll);mutex_init(&IIlllIll);INIT_LIST_HEAD(&lIIIIIIl);
mutex_init(&IlllllIl);llIIIlII=lIlIllIIl();if(llIIIlII==NULL){IIIll=-ENOMEM;
Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x75\x73\x62\x64\x5f\x6c\x6f\x61\x64\x65\x72\x5f\x61\x6c\x6c\x6f\x63\x5f\x6d\x69\x6e\x6f\x72\x2e\x20\x45\x72\x72\x6f\x72\x20\x6e\x75\x6d\x62\x65\x72\x20\x25\x64" "\n"
,IIIll);break;}


IIIll=usb_register(&lIIlllI);if(IIIll!=(0xb68+5835-0x2233)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x75\x73\x62\x5f\x72\x65\x67\x69\x73\x74\x65\x72\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x6e\x75\x6d\x62\x65\x72\x20\x25\x64" "\n"
,IIIll);break;}lIIIlIllI=(0x1089+4487-0x220f);
#if KERNEL_LT_EQ((0x259+2276-0xb3b),(0x115b+2195-0x19e8),(0x986+3876-0x1897))
usb_register_notify(&IIllllll);
#else 
IIIll=bus_register_notifier(lIIlllI.drvwrap.driver.bus,&llIIIllI);if(IIIll!=
(0x3+1404-0x57f)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x3a\x20\x62\x75\x73\x5f\x72\x65\x67\x69\x73\x74\x65\x72\x5f\x6e\x6f\x74\x69\x66\x69\x65\x72\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x6e\x75\x6d\x62\x65\x72\x20\x25\x64" "\n"
,IIIll);break;}
#endif
IIIIIIlIl=(0xc44+6500-0x25a7);}while((0xeb2+589-0x10ff));if(IIIll!=
(0x1abd+415-0x1c5c)){if(IIIIIIlIl){
#if KERNEL_LT_EQ((0x4b3+5093-0x1896),(0x1387+2849-0x1ea2),(0x11eb+1744-0x18a8))
usb_unregister_notify(&IIllllll);
#else 
bus_unregister_notifier(lIIlllI.drvwrap.driver.bus,&llIIIllI);
#endif
}if(lIIIlIllI){usb_deregister(&lIIlllI);}if(llIIIlII){lIIIIIIlI(llIIIlII);
llIIIlII=NULL;}}return IIIll;}void lIlIlIlll(void){struct list_head Illlll;
llIllIlI();IlIlIIllI();
#if KERNEL_LT_EQ((0x1306+1720-0x19bc),(0x1d4b+409-0x1ede),(0x2b9+5452-0x17f2))
usb_unregister_notify(&IIllllll);
#else 
bus_unregister_notifier(lIIlllI.drvwrap.driver.bus,&llIIIllI);
#endif
usb_deregister(&lIIlllI);if(llIIIlII){lIIIIIIlI(llIIIlII);llIIIlII=NULL;}
INIT_LIST_HEAD(&Illlll);spin_lock(&lllIIl);list_splice_init(&IlllIll,&Illlll);
spin_unlock(&lllIIl);while(!list_empty(&Illlll)){struct IlIIl*lIlII=list_entry(
Illlll.next,struct IlIIl,llIIII);llllllIl(lIlII);}IIlIIIllI();}struct IlIIl*
llIlIlllI(struct usb_device*llIII){char*llIlIlI;struct IlIIl*lIlII;llIlIlI=
lIllllIIl(&llIII->dev.kobj,GFP_KERNEL);if(llIlIlI==NULL){return NULL;}lIlII=
lllIlII(sizeof(*lIlII),GFP_KERNEL);if(lIlII){INIT_LIST_HEAD(&lIlII->llIIII);
init_waitqueue_head(&lIlII->IIIIlI);INIT_LIST_HEAD(&lIlII->llIlIlIl);
spin_lock_init(&lIlII->lllllll);INIT_LIST_HEAD(&lIlII->llllIll);spin_lock_init(&
lIlII->IlIlll);INIT_LIST_HEAD(&lIlII->lllIIlll);kref_init(&lIlII->IllIll);lIlII
->vid=le16_to_cpu(llIII->descriptor.idVendor);lIlII->lIllIIl=le16_to_cpu(llIII->
descriptor.idProduct);lIlII->lIIlIIl=le16_to_cpu(llIII->descriptor.bcdDevice);
strncpy(lIlII->bus_id,llIIIl(&llIII->dev),BUS_ID_SIZE-(0x15e3+1635-0x1c45));
lIlII->IlIlIII=(0x661+7215-0x2290);lIlII->lIlllIIl=(0xbc1+3789-0x1a8e);lIlII->
IlIIllll=IIlIIlIlI;lIlII->lIIlI=usb_get_dev(llIII);lIlII->IlIIIlll=
(0xbf+4581-0x12a4);lIlII->lIlIIIll=(0x470+2571-0xe7b);lIlII->IlIllll=
(0xd33+377-0xeac);lIlII->IllIllII=llIlIlI;lIlII->llIllII=(0x3f6+5138-0x1808);
lIlII->IlIlIIll=-(0xf35+5060-0x22f8);lIlII->IIIIIlll=-(0x66+146-0xf7);lIlII->
IllIlIII=-(0x851+810-0xb7a);lIlII->IIIlIl=lllIIIII;lIlII->IIIllII=NULL;
spin_lock_init(&lIlII->lIIIlI);lIlII->IlIllIl=(strcmp(lIllIIll(llIII),
"\x65\x68\x63\x69\x5f\x68\x63\x64")==(0x3a6+6869-0x1e7b));







if(strcmp(lIllIIll(llIII),"\x64\x77\x63\x5f\x6f\x74\x67")==(0x11f3+1788-0x18ef))
{


lIlII->lIIIlII=IIlIlI;lIlII->lllllIll=IIlIlI;lIlII->IIlllllI=IIlIlI;}else{
#if KERNEL_LT_EQ((0xd82+5493-0x22f5),(0x173+9310-0x25cb),(0x111f+3307-0x1dec))


lIlII->lIIIlII=llIIlIl;lIlII->lllllIll=IIlIlI;lIlII->IIlllllI=llIIlIl;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x62\x75\x66\x66\x65\x72\x20\x74\x79\x70\x65\x73\x20\x62\x75\x6c\x6b\x3d\x70\x74\x20\x69\x6e\x74\x3d\x73\x6c\x20\x69\x73\x6f\x3d\x70\x74" "\n"
);
#elif KERNEL_EQ((0x145c+1476-0x1a1e),(0x1498+4070-0x2478),(0x1837+1963-0x1fc3))



if((bus_to_hcd(llIII->bus)->driver->flags&HCD_MASK)>=HCD_USB3){lIlII->lIIIlII=
lllIIII;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x62\x75\x66\x66\x65\x72\x20\x74\x79\x70\x65\x73\x20\x62\x75\x6c\x6b\x3d\x73\x67\x20\x69\x6e\x74\x3d\x73\x6c\x20\x69\x73\x6f\x3d\x70\x74" "\n"
);}else{lIlII->lIIIlII=llIIlIl;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x62\x75\x66\x66\x65\x72\x20\x74\x79\x70\x65\x73\x20\x62\x75\x6c\x6b\x3d\x70\x74\x20\x69\x6e\x74\x3d\x73\x6c\x20\x69\x73\x6f\x3d\x70\x74" "\n"
);}lIlII->lllllIll=IIlIlI;lIlII->IIlllllI=llIIlIl;
#elif KERNEL_EQ((0x45d+692-0x70f),(0x1745+1058-0x1b61),(0x557+4653-0x1764))



if((bus_to_hcd(llIII->bus)->driver->flags&HCD_MASK)>=HCD_USB3){lIlII->lIIIlII=
lllIIII;lIlII->lllllIll=lllIIII;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x62\x75\x66\x66\x65\x72\x20\x74\x79\x70\x65\x73\x20\x62\x75\x6c\x6b\x3d\x73\x67\x20\x69\x6e\x74\x3d\x73\x67\x20\x69\x73\x6f\x3d\x70\x74" "\n"
);}else{lIlII->lIIIlII=llIIlIl;lIlII->lllllIll=IIlIlI;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x62\x75\x66\x66\x65\x72\x20\x74\x79\x70\x65\x73\x20\x62\x75\x6c\x6b\x3d\x70\x74\x20\x69\x6e\x74\x3d\x73\x6c\x20\x69\x73\x6f\x3d\x70\x74" "\n"
);}lIlII->IIlllllI=llIIlIl;
#elif (KERNEL_GT_EQ((0x908+7116-0x24d2),(0xfd6+576-0x1210),(0x18c1+1195-0x1d49))\
 && KERNEL_LT_EQ((0x1353+3986-0x22e3),(0xff0+5250-0x246c),(0xbc4+4195-0x1c00))) \
|| (KERNEL_GT_EQ((0xac8+3561-0x18ae),(0x5d8+3105-0x11f9),(0x316+5401-0x182f)) &&\
 KERNEL_LT_EQ((0x4b+5413-0x156d),(0x1236+2363-0x1b71),(0x2073+1050-0x247d))) || \
(KERNEL_GT_EQ((0xd5+9752-0x26ea),(0xea6+5806-0x2553),(0x1a45+1455-0x1ff4)) && \
KERNEL_LT_EQ((0x1f24+1755-0x25fc),(0x15+7779-0x1e77),(0xe85+3305-0x1b66))) || \
KERNEL_EQ((0x64a+8037-0x25ac),(0xae2+5144-0x1ef8),(0x1af+4419-0x12f2))










llIlII(
"\x42\x75\x67\x67\x79\x20\x6b\x65\x72\x6e\x65\x6c\x20\x76\x65\x72\x73\x69\x6f\x6e\x2c\x20\x55\x53\x42\x20\x72\x65\x64\x69\x72\x65\x63\x74\x69\x6f\x6e\x20\x6d\x61\x79\x20\x62\x65\x20\x6c\x69\x6d\x69\x74\x65\x64\x2e" "\n"
);if((bus_to_hcd(llIII->bus)->driver->flags&HCD_MASK)>=HCD_USB3){lIlII->lIIIlII=
IIlIlI;lIlII->lllllIll=IIlIlI;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x62\x75\x66\x66\x65\x72\x20\x74\x79\x70\x65\x73\x20\x62\x75\x6c\x6b\x3d\x73\x6c\x20\x69\x6e\x74\x3d\x73\x6c\x20\x69\x73\x6f\x3d\x70\x74" "\n"
);}else{lIlII->lIIIlII=llIIlIl;lIlII->lllllIll=IIlIlI;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x62\x75\x66\x66\x65\x72\x20\x74\x79\x70\x65\x73\x20\x62\x75\x6c\x6b\x3d\x70\x74\x20\x69\x6e\x74\x3d\x73\x6c\x20\x69\x73\x6f\x3d\x70\x74" "\n"
);}lIlII->IIlllllI=llIIlIl;
#elif KERNEL_GT_EQ((0x9d2+243-0xac3),(0x585+7963-0x249a),(0x3f1+1910-0xb46))





if(llIII->bus->sg_tablesize>(0x2045+1070-0x2473)){lIlII->lIIIlII=lllIIII;lIlII->
lllllIll=lllIIII;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x62\x75\x66\x66\x65\x72\x20\x74\x79\x70\x65\x73\x20\x62\x75\x6c\x6b\x3d\x73\x67\x20\x69\x6e\x74\x3d\x73\x67\x20\x69\x73\x6f\x3d\x70\x74" "\n"
);}else{
#if KERNEL_GT_EQ((0x1aff+2648-0x2554),(0x306+5696-0x1940),(0x13e6+2416-0x1d56)) \
|| RHEL_RELEASE_GT_EQ((0x2591+167-0x2631),(0x141+4583-0x1328))



if(llIII->bus->no_stop_on_short){lIlII->lIIIlII=IIlIlI;}else{lIlII->lIIIlII=
llIIlIl;}
#else
lIlII->lIIIlII=llIIlIl;
#endif
lIlII->lllllIll=IIlIlI;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x62\x75\x66\x66\x65\x72\x20\x74\x79\x70\x65\x73\x20\x62\x75\x6c\x6b\x3d\x70\x74\x20\x69\x6e\x74\x3d\x73\x6c\x20\x69\x73\x6f\x3d\x70\x74" "\n"
);}lIlII->IIlllllI=llIIlIl;
#endif
}
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&IIIIlllII);
#endif
if(IllIlIIII(lIlII)<(0xe0c+4542-0x1fca)){
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&lIIIIIII);
#endif
Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x61\x6c\x6c\x6f\x63\x20\x6d\x69\x6e\x6f\x72\x20\x66\x61\x69\x6c\x65\x64" "\n"
);lIIlIIIl(lIlII);return NULL;}spin_lock(&lllIIl);list_add(&lIlII->llIIII,&
IlllIll);spin_unlock(&lllIIl);if(IIllllIIl(lIlII)<(0x620+605-0x87d)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x63\x72\x65\x61\x74\x65\x3a\x20\x72\x65\x67\x69\x73\x74\x65\x72\x20\x6d\x69\x6e\x6f\x72\x20\x66\x61\x69\x6c\x65\x64" "\n"
);llllllIl(lIlII);return NULL;}return lIlII;}llIIIIIlI(llIlIlI);return NULL;}
void llllllIl(struct IlIIl*lIlII){
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&lIIIIIII);
#endif
spin_lock(&lllIIl);list_del_init(&lIlII->llIIII);spin_unlock(&lllIIl);lllIlIIII(
lIlII);lIIlIIIl(lIlII);}
void llIIIllII(struct kref*IllIlII){struct IlIIl*lIlII=container_of(IllIlII,
struct IlIIl,IllIll);Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x64\x65\x73\x74\x72\x6f\x79\x2b\x2b" "\n"
);
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&IlIIlIlll);
#endif
spin_lock(&lllIIl);list_del_init(&lIlII->llIIII);spin_unlock(&lllIIl);IIlllIIIl(
lIlII);while(!list_empty(&lIlII->llIlIlIl)){struct lIlIl*lIlll=list_entry(lIlII
->llIlIlIl.next,struct lIlIl,llllIl);list_del(&lIlll->llllIl);llIllll(lIlll);}
while(!list_empty(&lIlII->llllIll)){struct lIlIl*lIlll=list_entry(lIlII->llllIll
.next,struct lIlIl,llllIl);list_del(&lIlll->llllIl);llIllll(lIlll);}if(lIlII->
lIIlI){usb_put_dev(lIlII->lIIlI);lIlII->lIIlI=NULL;}if(lIlII->IllIllII){
llIIIIIlI(lIlII->IllIllII);lIlII->IllIllII=NULL;}lIlIll(lIlII);Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x64\x65\x73\x74\x72\x6f\x79\x2d\x2d" "\n"
);}struct IlIIl*llIlllIl(struct usb_device*llIII){struct IlIIl*lIlII;spin_lock(&
lllIIl);list_for_each_entry(lIlII,&IlllIll,llIIII){if(lIlII->lIIlI==llIII){
IIlllIII(lIlII);spin_unlock(&lllIIl);return lIlII;}}spin_unlock(&lllIIl);return 
NULL;}void lIIllIllI(struct IlIIl*lIlII){if(!lIlII->IlIllll){lIlII->IlIllll=
(0xc08+6158-0x2415);IlIIIIll(lIlII);llIlIIIIl(lIlII->IllII);IIlll(
"\x69\x6e\x69\x74\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x3d\x25\x64\x20\x74\x6f\x74\x61\x6c\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x3d\x25\x64\x20\x6f\x6e\x6c\x69\x6e\x65\x3d\x25\x64" "\n"
,lIlII->lIlIIIll,lIlII->IlIIIlll,lIlII->IlIllll);}}void lIIIllIlI(struct IlIIl*
lIlII){if(lIlII->IlIllll){lIlII->IlIllll=(0x10fc+1928-0x1884);lllllIIII(lIlII->
IllII);IIlll(
"\x69\x6e\x69\x74\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x3d\x25\x64\x20\x74\x6f\x74\x61\x6c\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x3d\x25\x64\x20\x6f\x6e\x6c\x69\x6e\x65\x3d\x25\x64" "\n"
,lIlII->lIlIIIll,lIlII->IlIIIlll,lIlII->IlIllll);}}void lIIlIIlIl(struct IlIIl*
lIlII){if(lIlII->IlIllll){llIlIIIIl(lIlII->IllII);}else{lllllIIII(lIlII->IllII);
}}int lIlllIlll(struct IlIIl*lIlII){IIlll(
"\x69\x6e\x69\x74\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x3d\x25\x64\x20\x74\x6f\x74\x61\x6c\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x3d\x25\x64\x20\x6f\x6e\x6c\x69\x6e\x65\x3d\x25\x64" "\n"
,lIlII->lIlIIIll,lIlII->IlIIIlll,lIlII->IlIllll);return(lIlII->IlIllll==
(0x10d4+5331-0x25a7));}const char*lllIIllll(void*context){struct IlIIl*lIlII=
context;return lIlII->IllIllII;}const char*IIllllIll(void*context){
#if KERNEL_GT_EQ((0x5f4+2905-0x114b),(0xd62+3129-0x1995),(0x252+3064-0xe34))
struct IlIIl*lIlII=context;return lIIllIll(&lIlII->lIIlI->dev)?
"\x74\x72\x75\x65":"\x66\x61\x6c\x73\x65";
#else
return"\x66\x61\x6c\x73\x65";
#endif
}


void lIIIIIlII(struct IlIIl*lIlII,int lllIlIl){int i,lllIllIl;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x72\x65\x73\x65\x74\x2b\x2b" "\n");
lIlII->lIlllIIl=(0xaf1+5146-0x1f0b);if(lIlII->lIIlI->actconfig){



for(i=(0xb23+2136-0x137b);i<lIlII->lIIlI->actconfig->desc.bNumInterfaces;i++){
struct usb_interface*IIIIII=lIlII->lIIlI->actconfig->interface[i];if(IIIIII&&
IIIIII->num_altsetting>(0xce7+3697-0x1b57)){struct usb_host_interface*IIllIIl=
usb_altnum_to_altsetting(IIIIII,(0x11b4+2720-0x1c54));if(IIllIIl){lllIllIl=
usb_set_interface(lIlII->lIIlI,IIllIIl->desc.bInterfaceNumber,IIllIIl->desc.
bAlternateSetting);}}}}if(lllIlIl==lIIlIIlll||lllIlIl==llIlllIIl){llIlII(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x72\x65\x73\x65\x74\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x73\x65\x74\x20\x64\x65\x76\x69\x63\x65\x20\x76\x69\x64\x20\x25\x30\x34\x78\x20\x70\x69\x64\x20\x25\x30\x34\x78" "\n"
,lIlII->vid,lIlII->lIllIIl);lllIllIl=usb_reset_device(lIlII->lIIlI);llIlII(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x72\x65\x73\x65\x74\x3a\x20\x75\x73\x62\x5f\x72\x65\x73\x65\x74\x5f\x64\x65\x76\x69\x63\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x25\x64" "\n"
,lllIllIl);}memset(lIlII->llIlIIlI,(0x1470+1935-0x1bff),sizeof(lIlII->llIlIIlI))
;memset(lIlII->lIIIlIII,(0xdd4+6415-0x26e3),sizeof(lIlII->lIIIlIII));Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x72\x65\x73\x65\x74\x2d\x2d" "\n");}
void IlIlIllII(struct IlIIl*lIlII,int lllIlIl){if(lllIlIl!=IIlIIlIlI&&
usb_lock_device_for_reset(lIlII->lIIlI,NULL)>=(0x3e7+3555-0x11ca)){lIIIIIlII(
lIlII,lllIlIl);usb_unlock_device(lIlII->lIIlI);}else{memset(lIlII->llIlIIlI,
(0xcf5+6094-0x24c3),sizeof(lIlII->llIlIIlI));memset(lIlII->lIIIlIII,
(0xdc+5783-0x1773),sizeof(lIlII->lIIIlIII));}}int IIIllllII(struct IlIIl*lIlII,
int pipe){if(!usb_pipeisoc(pipe)){return(0x1857+3067-0x2452);}if(usb_pipein(pipe
)){return(++lIlII->IIIIlIIlI[usb_pipeendpoint(pipe)]);}else{return(++lIlII->
IlIlllIII[usb_pipeendpoint(pipe)]);}}int IlIIIIlI(struct IlIIl*lIlII,int pipe){
if(!usb_pipeisoc(pipe)){return(0x2646+71-0x268d);}if(usb_pipein(pipe)){return(--
lIlII->IIIIlIIlI[usb_pipeendpoint(pipe)]);}else{return(--lIlII->IlIlllIII[
usb_pipeendpoint(pipe)]);}}void IlIllllllI(struct IlIIl*lIlII,int pipe){if(!
usb_pipeisoc(pipe)){return;}if(usb_pipein(pipe)){lIlII->IIIIlIIlI[
usb_pipeendpoint(pipe)]=(0xf+6741-0x1a64);}else{lIlII->IlIlllIII[
usb_pipeendpoint(pipe)]=(0x25a+6565-0x1bff);}}int IlllIlII(struct IlIIl*lIlII,
int pipe){if(!usb_pipeisoc(pipe)){return(0x622+2478-0xfd0);}if(usb_pipein(pipe))
{return lIlII->llIlIIlI[usb_pipeendpoint(pipe)];}else{return lIlII->lIIIlIII[
usb_pipeendpoint(pipe)];}}void IlIlllll(struct IlIIl*lIlII,int pipe,int IlIIIlI)
{if(!usb_pipeisoc(pipe)){return;}if(usb_pipein(pipe)){lIlII->llIlIIlI[
usb_pipeendpoint(pipe)]=IlIIIlI;}else{lIlII->lIIIlIII[usb_pipeendpoint(pipe)]=
IlIIIlI;}}static void IlllIlllI(struct lIlIl*lIlll){if(lIlll->lIllll==IIlIlI){if
(lIlll->lIIIll.IlllI){IIlll(
"\x3a\x20\x75\x6e\x6c\x69\x6e\x6b\x69\x6e\x67\x20\x75\x72\x62\x20\x30\x78\x25\x70\x20\x75\x6e\x69\x71\x75\x65\x5f\x69\x64\x3d\x30\x78\x25\x6c\x6c\x78" "\n"
,lIlll->lIIIll.IlllI,lIlll->lllIl);


usb_unlink_urb(lIlll->lIIIll.IlllI);}}else if(lIlll->lIllll==llIIlIl){IIlll(
"\x3a\x20\x75\x6e\x6c\x69\x6e\x6b\x69\x6e\x67\x20\x75\x63\x20\x75\x6e\x69\x71\x75\x65\x5f\x69\x64\x3d\x30\x78\x25\x6c\x6c\x78" "\n"
,lIlll->lllIl);lIlIllIll(lIlll->lIllII.llllIlI);}
#if KERNEL_GT_EQ((0x14e4+2531-0x1ec5),(0xb0f+2649-0x1562),(0xc06+3397-0x192c))
else if(lIlll->lIllll==lllIIII){if(lIlll->lIIllII.IlllI){IIlll(
"\x3a\x20\x75\x6e\x6c\x69\x6e\x6b\x69\x6e\x67\x20\x73\x67\x20\x30\x78\x25\x70\x20\x75\x6e\x69\x71\x75\x65\x5f\x69\x64\x3d\x30\x78\x25\x6c\x6c\x78" "\n"
,lIlll->lIIllII.IlllI,lIlll->lllIl);


usb_unlink_urb(lIlll->lIIllII.IlllI);}}
#endif
else{
llIlII(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x6e\x6c\x69\x6e\x6b\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x20\x65\x72\x72\x6f\x72\x21" "\n"
);}}static void llIlIIIII(struct lIlIl*lIlll){if(lIlll->lIllll==IIlIlI){if(lIlll
->lIIIll.IlllI){IIlll(
"\x3a\x20\x6b\x69\x6c\x69\x6e\x67\x20\x75\x72\x62\x20\x30\x78\x25\x70\x20\x75\x6e\x69\x71\x75\x65\x5f\x69\x64\x3d\x30\x78\x25\x6c\x6c\x78" "\n"
,lIlll->lIIIll.IlllI,lIlll->lllIl);
#if KERNEL_GT_EQ((0x5e4+5140-0x19f6),(0x1dc5+1683-0x2452),(0xe42+559-0x1055))


usb_poison_urb(lIlll->lIIIll.IlllI);
#else
usb_kill_urb(lIlll->lIIIll.IlllI);
#endif
}}else if(lIlll->lIllll==llIIlIl){IIlll(
"\x3a\x20\x6b\x69\x6c\x6c\x69\x6e\x67\x20\x75\x63\x20\x75\x6e\x69\x71\x75\x65\x5f\x69\x64\x3d\x30\x78\x25\x6c\x6c\x78" "\n"
,lIlll->lllIl);lllIlIIIl(lIlll->lIllII.llllIlI);}
#if KERNEL_GT_EQ((0x18fc+3333-0x25ff),(0x11ff+3110-0x1e1f),(0xf61+714-0x120c))
else if(lIlll->lIllll==lllIIII){if(lIlll->lIIllII.IlllI){IIlll(
"\x3a\x20\x6b\x69\x6c\x6c\x69\x6e\x67\x20\x73\x67\x20\x30\x78\x25\x70\x20\x75\x6e\x69\x71\x75\x65\x5f\x69\x64\x3d\x30\x78\x25\x6c\x6c\x78" "\n"
,lIlll->lIIllII.IlllI,lIlll->lllIl);
#if KERNEL_GT_EQ((0x107a+619-0x12e3),(0xacd+6218-0x2311),(0x786+2080-0xf8a))


usb_poison_urb(lIlll->lIIllII.IlllI);
#else
usb_kill_urb(lIlll->lIIllII.IlllI);
#endif
}}
#endif
else{
llIlII(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6b\x69\x6c\x6c\x5f\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x20\x65\x72\x72\x6f\x72\x21" "\n"
);}}
void lIlIIlIIl(struct IlIIl*lIlII,struct usb_interface*lllIII,struct lIlIl*
IlIlIlI,int IllIlIl){int i;unsigned long flags;struct lIlIl*IllIII,*IIllIlI;
IIlll("\x2b\x2b" "\n");
if(lIlII->llIllII&&lIlII->IlIlIIll==lllIII->cur_altsetting->desc.
bInterfaceNumber)
{lIlllllI(lIlII,(0x570+5369-0x1a69),IllIlIl);}for(i=(0xef8+3275-0x1bc3);i<lllIII
->cur_altsetting->desc.bNumEndpoints;i++){do{IIllIlI=NULL;spin_lock_irqsave(&
lIlII->IlIlll,flags);list_for_each_entry(IllIII,&lIlII->llllIll,llllIl){int 
llIIIll;
if(IllIII==IlIlIlI){continue;}
if(IllIII->endpoint!=lllIII->cur_altsetting->endpoint[i].desc.bEndpointAddress){
continue;}llIIIll=atomic_xchg(&IllIII->state,IIIIlII);
if(llIIIll==IIIIlII||llIIIll==lllIlllII){continue;}IllIII->IllIlIl=IllIlIl;
if(IllIII->IIIIIlI.IlIlIIlI){


IllIII=Illlllll(lIlII,IllIII->lllIl);}if(llIIIll==IllIIll){



kref_get(&IllIII->IllIll);

IIllIlI=IllIII;break;}}spin_unlock_irqrestore(&lIlII->IlIlll,flags);if(IIllIlI){
llIlIIIII(IIllIlI);kref_put(&IIllIlI->IllIll,IlIlIlll);}}while(IIllIlI);}IIlll(
"\x2d\x2d" "\n");}void lIllIIlll(struct IlIIl*lIlII,int endpoint,struct lIlIl*
IlIlIlI){unsigned long flags;struct lIlIl*IllIII,*lllIIll;IIlll("\x2b\x2b" "\n")
;if(lIlII->llIllII)
{if(endpoint==lIlII->IIIIIlll||endpoint==lIlII->IllIlIII){IIlllIIl(lIlII);}}




do{lllIIll=NULL;spin_lock_irqsave(&lIlII->IlIlll,flags);list_for_each_entry(
IllIII,&lIlII->llllIll,llllIl){int llIIIll;
if(IllIII==IlIlIlI){continue;}
if(IllIII->endpoint!=endpoint){continue;}llIIIll=atomic_xchg(&IllIII->state,
IIIIlII);
if(llIIIll==IIIIlII||llIIIll==lllIlllII){continue;}
if(IllIII->IIIIIlI.IlIlIIlI){


IllIII=Illlllll(lIlII,IllIII->lllIl);}if(llIIIll==IllIIll){



kref_get(&IllIII->IllIll);

lllIIll=IllIII;break;}}spin_unlock_irqrestore(&lIlII->IlIlll,flags);if(lllIIll){
IlllIlllI(lllIIll);kref_put(&lllIIll->IllIll,IlIlIlll);}}while(lllIIll);IIlll(
"\x2d\x2d" "\n");}void lIIIlIlIl(struct IlIIl*lIlII,IlIIlI lllIl,struct lIlIl*
IlIlIlI){int IIllIIII;unsigned long flags;struct lIlIl*IllIII,*lllIIll;IIlll(
"\x2b\x2b" "\n");if(lIlII->llIllII){if(lIIlIlIlI(lIlII,lllIl))return;}
spin_lock_irqsave(&lIlII->IlIlll,flags);



IIllIIII=(0xfa0+2582-0x19b6);lllIIll=NULL;list_for_each_entry(IllIII,&lIlII->
llllIll,llllIl){
if(IllIII==IlIlIlI){continue;}if(IllIII->lllIl==lllIl){if(atomic_xchg(&IllIII->
state,IIIIlII)==IllIIll){



kref_get(&IllIII->IllIll);

lllIIll=IllIII;}IIllIIII=(0x86a+76-0x8b5);break;}}if(!IIllIIII){llIIIIII(lIlII,
lllIl);}spin_unlock_irqrestore(&lIlII->IlIlll,flags);if(lllIIll){IlllIlllI(
lllIIll);kref_put(&lllIIll->IllIll,IlIlIlll);}else{IIlll(
"\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n");}IIlll("\x2d\x2d" "\n");}void 
IIIlIlII(struct IlIIl*lIlII,struct lIlIl*IlIlIlI,int lIlllIlII,int IlllllII){
struct lIlIl*IIllIlI,*IllIII;unsigned long flags;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6b\x69\x6c\x6c\x5f\x61\x6c\x6c\x5f\x72\x65\x71\x75\x65\x73\x74\x73\x3a\x20\x2b\x2b" "\n"
);

lIlllllI(lIlII,lIlllIlII,IlllllII);

spin_lock_irqsave(&lIlII->IlIlll,flags);while(!list_empty(&lIlII->lllIIlll)){
struct IllllIII*IIIIIII=list_entry(lIlII->lllIIlll.next,struct IllllIII,llIIII);
list_del(&IIIIIII->llIIII);lIlIll(IIIIIII);}

do{


IIllIlI=NULL;list_for_each_entry(IllIII,&lIlII->llllIll,llllIl){if(lIlllIlII){
IllIII->IlIIIIl=(0x1613+3114-0x223c);}if(IlllllII){
IllIII->IllIlIl=(0xd23+5105-0x2113);}
if(IllIII!=IlIlIlI&&atomic_xchg(&IllIII->state,IIIIlII)==IllIIll){



kref_get(&IllIII->IllIll);

IIllIlI=IllIII;break;}}spin_unlock_irqrestore(&lIlII->IlIlll,flags);if(IIllIlI){
llIlIIIII(IIllIlI);kref_put(&IIllIlI->IllIll,IlIlIlll);}spin_lock_irqsave(&lIlII
->IlIlll,flags);}while(IIllIlI);spin_unlock_irqrestore(&lIlII->IlIlll,flags);
Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6b\x69\x6c\x6c\x5f\x61\x6c\x6c\x5f\x72\x65\x71\x75\x65\x73\x74\x73\x3a\x20\x2d\x2d" "\n"
);}
int IllIIllIl(struct usb_device*lIIlI,lIllIl endpoint){int IIIllIl;struct 
usb_host_endpoint*ep;ep=(endpoint&(0x131f+4542-0x245d))?lIIlI->ep_in[endpoint&
(0x1a6c+1395-0x1fd0)]:lIIlI->ep_out[endpoint&(0x40+5328-0x1501)];if(!ep){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x67\x65\x74\x5f\x65\x6e\x64\x70\x6f\x69\x6e\x74\x5f\x6d\x61\x78\x70\x61\x63\x6b\x65\x74\x3a\x20\x65\x6e\x64\x70\x6f\x69\x6e\x74\x20\x69\x73\x20\x4e\x55\x4c\x4c" "\n"
);return-ENODEV;}IIIllIl=le16_to_cpu(ep->desc.wMaxPacketSize);if((ep->desc.
bmAttributes&USB_ENDPOINT_XFERTYPE_MASK)!=USB_ENDPOINT_XFER_ISOC){IIIllIl=
IIIllIl&(0xda0+1893-0xd06);}else if(lIIlI->speed==USB_SPEED_FULL)
{IIIllIl=IIIllIl&(0x1aa6+1270-0x179d);}else if(lIIlI->speed==USB_SPEED_HIGH)
{IIIllIl=(IIIllIl&(0xacd+8631-0x2485))*((0x13b+5886-0x1838)+((IIIllIl>>
(0x111+9443-0x25e9))&(0x44+8172-0x202d)));}
#if KERNEL_GT_EQ((0x137f+3883-0x22a8),(0x175c+3935-0x26b5),(0xb67+199-0xc0f)) &&\
 KERNEL_LT_EQ((0x3c+9560-0x2592),(0x915+7054-0x249d),(0x14e2+2125-0x1d0d))
else if(lIIlI->speed==USB_SPEED_SUPER)
{IIIllIl=(IIIllIl&(0xeb8+6502-0x201f))*(ep->ss_ep_comp?(((0x201f+800-0x233e)+ep
->ss_ep_comp->desc.bMaxBurst)*((0xaa7+563-0xcd9)+(ep->ss_ep_comp->desc.
bmAttributes&(0x1b98+548-0x1db9)))):(0xf58+1578-0x1581));}
#endif 
#if KERNEL_GT_EQ((0x87+9101-0x2412),(0x4d3+2524-0xea9),(0x363+6124-0x1b2c))
else if(lIIlI->speed==USB_SPEED_SUPER)
{IIIllIl=(IIIllIl&(0x1165+113-0x9d7))*((0x38c+5887-0x1a8a)+ep->ss_ep_comp.
bMaxBurst)*((0x928+6581-0x22dc)+(ep->ss_ep_comp.bmAttributes&(0x25a+5302-0x170d)
));}
#endif 
#if KERNEL_GT_EQ((0x1c47+68-0x1c87),(0x10c3+1394-0x162f),(0xf15+295-0x103c))
else if(lIIlI->speed==USB_SPEED_SUPER_PLUS)
{
IIIllIl=(IIIllIl&(0xd19+4267-0x15c5))*((0x16a4+2695-0x212a)+ep->ss_ep_comp.
bMaxBurst)*((0x1616+633-0x188e)+(ep->ss_ep_comp.bmAttributes&(0xb75+2918-0x16d8)
));}
#endif 
else{return-EPROTO;}Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x67\x65\x74\x5f\x65\x6e\x64\x70\x6f\x69\x6e\x74\x5f\x6d\x61\x78\x70\x61\x63\x6b\x65\x74\x3a\x20\x65\x6e\x64\x70\x6f\x69\x6e\x74\x3d\x30\x78\x25\x30\x32\x78\x20\x6d\x61\x78\x70\x61\x63\x6b\x65\x74\x3d\x25\x64" "\n"
,endpoint,IIIllIl);return IIIllIl;}
#endif 

