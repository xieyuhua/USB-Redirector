/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifdef _USBD_ENABLE_STUB_
#include "usbd.h"
#include "loader.h"
static ssize_t IlIIlIllI(void*,const char __user*,size_t);static ssize_t 
llllIlIII(void*,char __user*,size_t);static long llIlllIll(void*,unsigned int,
unsigned long);
#ifdef CONFIG_COMPAT
static long IllIlllll(void*,unsigned int,unsigned long);
#endif
static int IlIlIIlll(void*,int);static int IIIllIIlI(void*,int);static unsigned 
int IIIlIIIII(void*,struct file*,poll_table*IIIIlI);static int IIlllllIl(struct 
IIIlll*IllII,const char __user*IIIlI);static int lIlIlllII(struct IIIlll*IllII,
const struct IIIIIIIIl __user*ioctl);static int IIIlIlllI(struct IIIlll*IllII,
struct IlIIIlIll __user*ioctl);static int IIlllIllI(struct IIIlll*IllII,const 
struct IIIIlIllI __user*ioctl);static int lllIIIlII(struct IIIlll*IllII,const 
struct lIIlIllIl __user*ioctl);static int IIlIIllIl(struct IIIlll*IllII,const 
struct lIlllllIl __user*ioctl);static int llIIlIIll(struct IIIlll*IllII,const 
struct IllIIIlll __user*ioctl);static int llIIIIllI(struct IIIlll*IllII,const 
char __user*IIIlI);static int lIlIlIIlI(struct IIIlll*IllII,const struct 
IlllIIlII __user*ioctl);struct IllIlllI lIllllllI[]={{"\x74\x79\x70\x65",
"\x6c\x6f\x61\x64\x65\x72",NULL},{NULL,NULL,NULL}};struct IIIlll*lIlIllIIl(void)
{struct IIIlll*IllII;IllII=lllIlII(sizeof(*IllII),GFP_KERNEL);if(IllII){
mutex_init(&IllII->mutex);IllII->context=IllII;IllII->IIlIII=-
(0xa1f+5402-0x1f38);IllII->ops.open=IlIlIIlll;IllII->ops.release=IIIllIIlI;IllII
->ops.unlocked_ioctl=llIlllIll;
#ifdef CONFIG_COMPAT
IllII->ops.compat_ioctl=IllIlllll;
#endif
IllII->ops.read=llllIlIII;IllII->ops.write=IlIIlIllI;IllII->ops.poll=IIIlIIIII;
IllII->IlIlllII=lIllllllI;if(llIIIlIl(IllII,(0x6d6+7190-0x22ec),
(0x2493+630-0x2709))<(0x380+704-0x640)){lIlIll(IllII);IllII=NULL;}}return IllII;
}void lIIIIIIlI(struct IIIlll*IllII){if(IllII){lIIlIIlI(IllII);lIlIll(IllII);}}
static ssize_t llllIlIII(void*context,char __user*IIIlI,size_t IlIII){
ssize_t IIIll=(0x7e8+5752-0x1e60);Illll(
"\x75\x73\x62\x64\x5f\x6c\x6f\x61\x64\x65\x72\x5f\x72\x65\x61\x64\x3a\x20\x62\x75\x66\x20\x69\x73\x20\x30\x78\x25\x70\x2c\x20\x72\x65\x71\x75\x65\x73\x74\x65\x64\x20\x25\x6c\x75\x20\x62\x79\x74\x65\x73" "\n"
,IIIlI,(unsigned long)IlIII);return IIIll;}static ssize_t IlIIlIllI(void*context
,const char __user*IIIlI,size_t IlIII){
ssize_t IIIll=IlIII;Illll(
"\x75\x73\x62\x64\x5f\x6c\x6f\x61\x64\x65\x72\x5f\x77\x72\x69\x74\x65\x3a\x20\x62\x75\x66\x20\x69\x73\x20\x30\x78\x25\x70\x2c\x20\x72\x65\x71\x75\x65\x73\x74\x65\x64\x20\x25\x6c\x75\x20\x62\x79\x74\x65\x73" "\n"
,IIIlI,(unsigned long)IlIII);return IIIll;}static long lIIllIlII(void*context,
unsigned int lIIIIl,void __user*IlIIII){struct IIIlll*IllII=context;ssize_t 
IIIll=(0xee9+1688-0x1581);Illll(
"\x75\x73\x62\x64\x5f\x6c\x6f\x61\x64\x65\x72\x5f\x64\x6f\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x2b\x2b\x20\x63\x6d\x64\x3d\x25\x64\x20\x61\x72\x67\x3d\x30\x78\x25\x70" "\n"
,lIIIIl,IlIIII);switch(lIIIIl){case lllIIllIll:IIIll=IIlllllIl(IllII,IlIIII);
break;case lIlllIllI:IIIll=lIlIlllII(IllII,IlIIII);break;case lIllIIIIl:IIIll=
IIIlIlllI(IllII,IlIIII);break;case IIlIllIIl:IIIll=IIlllIllI(IllII,IlIIII);break
;case lllIIlIIl:IIIll=lllIIIlII(IllII,IlIIII);break;case lIlIIlllI:IIIll=
IIlIIllIl(IllII,IlIIII);break;case IlIIlIlIl:IIIll=llIIlIIll(IllII,IlIIII);break
;
#if (0x2+6220-0x184e)
case llIlIIIlIl:IIIll=IIllIlIlI(IllII,IlIIII);break;
#endif
case IIIllIIIl:IIIll=llIIIIllI(IllII,IlIIII);break;case lIlIlIllI:IIIll=
lIlIlIIlI(IllII,IlIIII);break;default:Illll(
"\x75\x73\x62\x64\x5f\x6c\x6f\x61\x64\x65\x72\x5f\x64\x6f\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x69\x6f\x63\x74\x6c" "\n"
);IIIll=-EINVAL;break;}Illll(
"\x75\x73\x62\x64\x5f\x6c\x6f\x61\x64\x65\x72\x5f\x64\x6f\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x6c\x75" "\n"
,(unsigned long)IIIll);return IIIll;}static long llIlllIll(void*context,unsigned
 int lIIIIl,unsigned long IlIIII){Illll(
"\x75\x73\x62\x64\x5f\x6c\x6f\x61\x64\x65\x72\x5f\x69\x6f\x63\x74\x6c" "\n");
return lIIllIlII(context,lIIIIl,(void __user*)IlIIII);}
#ifdef CONFIG_COMPAT
static long IllIlllll(void*context,unsigned int lIIIIl,unsigned long IlIIII){
Illll(
"\x75\x73\x62\x64\x5f\x6c\x6f\x61\x64\x65\x72\x5f\x63\x6f\x6d\x70\x61\x74\x5f\x69\x6f\x63\x74\x6c" "\n"
);return lIIllIlII(context,lIIIIl,compat_ptr(IlIIII));}
#endif


static int IlIlIIlll(void*context,int lllIllI){
Illll(
"\x75\x73\x62\x64\x5f\x6c\x6f\x61\x64\x65\x72\x5f\x6f\x70\x65\x6e\x20\x25\x64" "\n"
,lllIllI);
return(0xeec+1687-0x1583);}

static int IIIllIIlI(void*context,int lllIllI){
Illll(
"\x75\x73\x62\x64\x5f\x6c\x6f\x61\x64\x65\x72\x5f\x72\x65\x6c\x65\x61\x73\x65\x20\x25\x64" "\n"
,lllIllI);if(lllIllI==(0x8bd+3742-0x175b)){
llIllIlI();}return(0x19+5856-0x16f9);}static unsigned int IIIlIIIII(void*context
,struct file*lIlllI,poll_table*IIIIlI){
return(POLLOUT|POLLWRNORM);}static int IIlllllIl(struct IIIlll*IllII,const char 
__user*IIIlI){int IIIll=(0x1c31+702-0x1eef);const char __user*llllIlll;struct 
list_head lIlllIII;struct IIIIllllI IlIIIll;IIIIl lllIlI;IIlll("\x2b\x2b" "\n");
INIT_LIST_HEAD(&lIlllIII);if(copy_from_user(&IlIIIll,IIIlI,sizeof(IlIIIll))){
return-EFAULT;}llllIlll=IIIlI+IlIIIll.lIIlII.lIIIllI;if(IIIlI+sizeof(IlIIIll)>
llllIlll){return-EINVAL;}IIIlI+=sizeof(IlIIIll);IIlll(
"\x63\x6f\x75\x6e\x74\x3d\x25\x64" "\n",IlIIIll.IlllIllI);for(lllIlI=
(0x324+4579-0x1507);lllIlI<IlIIIll.IlllIllI;lllIlI++){size_t IlIIIlII;size_t 
IIIlIlIl;struct IllIllll lIIll;struct lIIIIIlI*IlIlIl;if(IIIlI+sizeof(lIIll)>
llllIlll){IIIll=-EINVAL;break;}if(copy_from_user(&lIIll,IIIlI,sizeof(lIIll))){
IIIll=-EFAULT;break;}if((lIIll.lIlIllI&lIlIIlIll)&&(lIIll.lIlIllI&IllllllII)){
IIIll=-EINVAL;break;}if((lIIll.lIlIllI&llIllllII)&&lIIll.IlllIIl<=
(0xbd8+6582-0x258e)){
IIIll=-EINVAL;break;}if((lIIll.lIlIllI&IlIIIIlll)&&lIIll.llIIlIll<=
(0xc3f+2791-0x1726)){
IIIll=-EINVAL;break;}if((lIIll.lIlIllI&lIIIIlIlI)&&lIIll.lIIIlIlI<=
(0xb26+4747-0x1db1)){
IIIll=-EINVAL;break;}IIIlIlIl=sizeof(struct IllIllll)+lIIll.IlllIIl+lIIll.
llIIlIll+lIIll.lIIIlIlI;IlIIIlII=sizeof(struct lIIIIIlI)-sizeof(struct IllIllll)
+IIIlIlIl;if(IIIlI+IIIlIlIl>llllIlll){IIIll=-EINVAL;break;}IlIlIl=IllIIlI(
IlIIIlII,GFP_KERNEL);if(IlIlIl==NULL){IIIll=-ENOMEM;break;}if(copy_from_user(&
IlIlIl->lIIll,IIIlI,IIIlIlIl)){lIlIll(IlIlIl);IIIll=-EFAULT;break;}if((lIIll.
lIlIllI&llIllllII)&&*((char*)(&IlIlIl->lIIll+(0x133+2509-0xaff))+lIIll.IlllIIl-
(0xc63+5777-0x22f3))!='\0'){
lIlIll(IlIlIl);IIIll=-EINVAL;break;}if((lIIll.lIlIllI&IlIIIIlll)&&*((char*)(&
IlIlIl->lIIll+(0x11e8+4936-0x252f))+lIIll.IlllIIl+lIIll.llIIlIll-
(0x16fa+2038-0x1eef))!='\0'){
lIlIll(IlIlIl);IIIll=-EINVAL;break;}if((lIIll.lIlIllI&lIIIIlIlI)&&*((char*)(&
IlIlIl->lIIll+(0xb8f+6194-0x23c0))+lIIll.IlllIIl+lIIll.llIIlIll+lIIll.lIIIlIlI-
(0x196+6905-0x1c8e))!='\0'){
lIlIll(IlIlIl);IIIll=-EINVAL;break;}IIlll(
"\x56\x3d\x25\x30\x34\x58\x20\x50\x3d\x25\x30\x34\x58\x20\x52\x3d\x25\x30\x34\x58\x20\x43\x3d\x25\x30\x32\x58\x20\x53\x3d\x25\x30\x32\x58\x20\x50\x3d\x25\x30\x32\x58\x20\x50\x3d\x25\x73\x20\x53\x4e\x3d\x25\x73\x20\x49\x4e\x3d\x25\x73\x20\x46\x3d\x25\x30\x38\x58" "\n"
,IlIlIl->lIIll.IIIIIlIl,IlIlIl->lIIll.lIIIllIl,IlIlIl->lIIll.lIlIlIII,IlIlIl->
lIIll.llIIIIlI,IlIlIl->lIIll.llIlllll,IlIlIl->lIIll.lllIlllI,IlIlIl->lIIll.
IlllIIl?(char*)(&IlIlIl->lIIll+(0x9a1+3888-0x18d0)):"\x6e\x6f\x6e\x65",IlIlIl->
lIIll.llIIlIll?(char*)(&IlIlIl->lIIll+(0x750+1184-0xbef))+IlIlIl->lIIll.IlllIIl:
"\x6e\x6f\x6e\x65",IlIlIl->lIIll.lIIIlIlI?(char*)(&IlIlIl->lIIll+
(0x20d0+961-0x2490))+IlIlIl->lIIll.IlllIIl+IlIlIl->lIIll.llIIlIll:
"\x6e\x6f\x6e\x65",IlIlIl->lIIll.lIlIllI);list_add_tail(&IlIlIl->entry,&lIlllIII
);IIIlI+=IIIlIlIl;}
if(lllIlI!=IlIIIll.IlllIllI){IIIll=-EINVAL;}
if(IIIll>=(0xdca+5902-0x24d8)){IIlll("\x75\x70\x64\x61\x74\x65" "\n");IllIIIIIl(
&lIlllIII);}
if(IIIll<(0xeaf+358-0x1015)){while(!list_empty(&lIlllIII)){struct lIIIIIlI*
IIIlIII;IIIlIII=list_entry(lIlllIII.next,struct lIIIIIlI,entry);list_del(&
IIIlIII->entry);lIlIll(IIIlIII);}}IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}
static int lIlIlllII(struct IIIlll*IllII,const struct IIIIIIIIl __user*ioctl){
int IIIll;IIIIl IllllI;IIlll("\x2b\x2b" "\n");do
{if(get_user(IllllI,&ioctl->lIIlII.lIIIllI)<(0xdd2+5544-0x237a)){IIIll=-EFAULT;
break;}if(IllllI!=sizeof(*ioctl)){IIIll=-EINVAL;break;}llIllIlI();IIIll=
(0x1253+266-0x135d);}while((0x874+3977-0x17fd));IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}
static int IIIlIlllI(struct IIIlll*IllII,struct IlIIIlIll __user*ioctl){int 
IIIll=-ENODEV;IIIIl IllllI;IIlll("\x2b\x2b" "\n");do
{lIllIl IlIIIlIIl;char lllllI[sizeof(ioctl->lllllI)+(0xee1+5632-0x24e0)];struct 
usb_device*llIII;if(get_user(IllllI,&ioctl->lIIlII.lIIIllI)<(0x1a53+2831-0x2562)
){IIIll=-EFAULT;break;}if(IllllI!=sizeof(*ioctl)){IIIll=-EINVAL;break;}if(
get_user(IlIIIlIIl,&ioctl->IlIIIlIIl)<(0x1fa9+1836-0x26d5)){IIIll=-EFAULT;break;
}lllllI[sizeof(lllllI)-(0x8c9+908-0xc54)]='\0';if(copy_from_user(lllllI,&ioctl->
lllllI,sizeof(ioctl->lllllI))){IIIll=-EFAULT;break;}IIIll=-ENODEV;llIII=lllllIII
(lllllI);if(llIII){usb_lock_device(llIII);
#if KERNEL_LT_EQ((0x107d+4427-0x21c6),(0x1dda+1070-0x2202),(0x2416+502-0x25f7))
down_write(&llIII->dev.bus->subsys.rwsem);
#endif
if(IllllIll(llIII)){IIIll=lIIlllIl(llIII);}else{IIlll(
"\x64\x65\x76\x69\x63\x65\x20\x25\x73\x20\x6e\x6f\x74\x20\x73\x68\x61\x72\x65\x64" "\n"
,lllllI);}
#if KERNEL_LT_EQ((0x9b2+1835-0x10db),(0x23+8241-0x204e),(0xb46+5221-0x1f96))
up_write(&llIII->dev.bus->subsys.rwsem);
#endif
usb_unlock_device(llIII);usb_put_dev(llIII);}else{IIlll(
"\x64\x65\x76\x69\x63\x65\x20\x25\x73\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,lllllI);}}while((0x127d+1447-0x1824));IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}
static int IIlllIllI(struct IIIlll*IllII,const struct IIIIlIllI __user*ioctl){
int IIIll=-ENODEV;IIIIl IllllI;IIlll("\x2b\x2b" "\n");do
{char lllllI[sizeof(ioctl->lllllI)+(0xb76+2662-0x15db)];lIllIl IIIIIlII;struct 
usb_device*llIII;if(get_user(IllllI,&ioctl->lIIlII.lIIIllI)<(0x86+8481-0x21a7)){
IIIll=-EFAULT;break;}if(IllllI!=sizeof(*ioctl)){IIIll=-EINVAL;break;}if(get_user
(IIIIIlII,&ioctl->IIIIIlII)<(0x99c+7455-0x26bb)){IIIll=-EFAULT;break;}lllllI[
sizeof(lllllI)-(0x21a0+859-0x24fa)]='\0';if(copy_from_user(lllllI,&ioctl->lllllI
,sizeof(ioctl->lllllI))){IIIll=-EFAULT;break;}IIIll=-ENODEV;llIII=lllllIII(
lllllI);if(llIII){usb_lock_device(llIII);
#if KERNEL_LT_EQ((0xd8d+5267-0x221e),(0xe65+4634-0x2079),(0x20b0+1188-0x253f))
down_write(&llIII->dev.bus->subsys.rwsem);
#endif
lIIllllI(llIII,IIIIIlII);IIIll=(0x40f+4709-0x1674);
#if KERNEL_LT_EQ((0x12ef+2915-0x1e50),(0x1203+1521-0x17ee),(0x563+4666-0x1788))
up_write(&llIII->dev.bus->subsys.rwsem);
#endif
usb_unlock_device(llIII);usb_put_dev(llIII);}else{IIlll(
"\x64\x65\x76\x69\x63\x65\x20\x25\x73\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,lllllI);}}while((0x1a73+900-0x1df7));IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}
static int lllIIIlII(struct IIIlll*IllII,const struct lIIlIllIl __user*ioctl){
int IIIll=-ENODEV;IIIIl IllllI;IIlll("\x2b\x2b" "\n");do
{char lllllI[sizeof(ioctl->lllllI)+(0x1136+3935-0x2094)];struct usb_device*llIII
;if(get_user(IllllI,&ioctl->lIIlII.lIIIllI)<(0x713+5684-0x1d47)){IIIll=-EFAULT;
break;}if(IllllI!=sizeof(*ioctl)){IIIll=-EINVAL;break;}lllllI[sizeof(lllllI)-
(0x55d+2944-0x10dc)]='\0';if(copy_from_user(lllllI,&ioctl->lllllI,sizeof(ioctl->
lllllI))){IIIll=-EFAULT;break;}IIIll=-ENODEV;llIII=lllllIII(lllllI);if(llIII){
usb_lock_device(llIII);
#if KERNEL_LT_EQ((0x88b+2503-0x1250),(0xb8+599-0x309),(0x1513+3448-0x2276))
down_write(&llIII->dev.bus->subsys.rwsem);
#endif
if(IllllIll(llIII)){IIIll=lIIlllIl(llIII);}else{lIIllllI(llIII,
(0x529+1425-0xab9));IIIll=(0x360+6617-0x1d39);}
#if KERNEL_LT_EQ((0x40a+8032-0x2368),(0x143a+400-0x15c4),(0x1442+2911-0x1f8c))
up_write(&llIII->dev.bus->subsys.rwsem);
#endif
usb_unlock_device(llIII);usb_put_dev(llIII);}else{IIlll(
"\x64\x65\x76\x69\x63\x65\x20\x25\x73\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,lllllI);}}while((0x665+7117-0x2232));IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}
static int IIlIIllIl(struct IIIlll*IllII,const struct lIlllllIl __user*ioctl){
int IIIll=-ENODEV;IIIIl IllllI;IIlll("\x2b\x2b" "\n");do
{char lllllI[sizeof(ioctl->lllllI)+(0x954+3513-0x170c)];struct usb_device*llIII;
if(get_user(IllllI,&ioctl->lIIlII.lIIIllI)<(0x4a3+2300-0xd9f)){IIIll=-EFAULT;
break;}if(IllllI<sizeof(*ioctl)){IIIll=-EINVAL;break;}lllllI[sizeof(lllllI)-
(0x27+151-0xbd)]='\0';if(copy_from_user(lllllI,&ioctl->lllllI,sizeof(ioctl->
lllllI))){IIIll=-EFAULT;break;}IIIll=-ENODEV;llIII=lllllIII(lllllI);if(llIII){
usb_lock_device(llIII);
#if KERNEL_LT_EQ((0x657+1734-0xd1b),(0xb7f+3803-0x1a54),(0x314+8981-0x2614))
down_write(&llIII->dev.bus->subsys.rwsem);
#endif
IIIll=-ENOENT;if(llIII->actconfig){int i;for(i=(0x1447+2110-0x1c85);i<llIII->
descriptor.bNumConfigurations;i++){struct usb_config_descriptor*config=(struct 
usb_config_descriptor*)llIII->rawdescriptors[i];if(config->bConfigurationValue==
llIII->actconfig->desc.bConfigurationValue){
if(copy_to_user((void*)(ioctl+(0xf0d+2110-0x174a)),(void*)config,min_t(size_t,
IllllI-sizeof(*ioctl),le16_to_cpu(config->wTotalLength)))){IIIll=-EFAULT;}else{
IIIll=(0x1fbf+1668-0x2643);}break;}}}
#if KERNEL_LT_EQ((0x1108+435-0x12b9),(0x813+5584-0x1ddd),(0x2187+253-0x226f))
up_write(&llIII->dev.bus->subsys.rwsem);
#endif
usb_unlock_device(llIII);usb_put_dev(llIII);}else{IIlll(
"\x64\x65\x76\x69\x63\x65\x20\x25\x73\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,lllllI);}}while((0x1a82+891-0x1dfd));IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}
static int llIIlIIll(struct IIIlll*IllII,const struct IllIIIlll __user*ioctl){
int IIIll=-ENODEV;IIIIl IllllI;IIlll("\x2b\x2b" "\n");do
{char lllllI[sizeof(ioctl->lllllI)+(0xa3c+1252-0xf1f)];struct usb_device*llIII;
if(get_user(IllllI,&ioctl->lIIlII.lIIIllI)<(0x74+1543-0x67b)){IIIll=-EFAULT;
break;}if(IllllI<sizeof(*ioctl)){IIIll=-EINVAL;break;}lllllI[sizeof(lllllI)-
(0x154+6629-0x1b38)]='\0';if(copy_from_user(lllllI,&ioctl->lllllI,sizeof(ioctl->
lllllI))){IIIll=-EFAULT;break;}IIIll=-ENODEV;llIII=lllllIII(lllllI);if(llIII){
const char*lIIlIIIIl,*IIlIIIIl,*IIlIIIlI;size_t IIlIIl;usb_lock_device(llIII);
#if KERNEL_LT_EQ((0xfb7+2270-0x1893),(0x394+7822-0x221c),(0x1a5+3597-0xf9d))
down_write(&llIII->dev.bus->subsys.rwsem);
#endif
do
{IIIll=IIllIIll(llIII,&lIIlIIIIl,&IIlIIIIl,&IIlIIIlI);if(IIIll<
(0x64c+3122-0x127e)){
break;}IIlIIl=strlen(IIlIIIlI)+(0x1939+2448-0x22c8);if(IIlIIl>(IllllI-sizeof(*
ioctl))){
IIIll=-EMSGSIZE;break;}if(copy_to_user((void*)(ioctl+(0x1388+2104-0x1bbf)),(void
*)IIlIIIlI,IIlIIl)){IIIll=-EFAULT;break;}}while((0x4d+5599-0x162c));
#if KERNEL_LT_EQ((0x1c0b+816-0x1f39),(0x8b8+2893-0x13ff),(0x22a8+1105-0x26e4))
up_write(&llIII->dev.bus->subsys.rwsem);
#endif
usb_unlock_device(llIII);usb_put_dev(llIII);}else{IIlll(
"\x64\x65\x76\x69\x63\x65\x20\x25\x73\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,lllllI);}}while((0x7cd+2237-0x108a));IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}
#if (0x70b+1667-0xd8e)
static int IIllIlIlI(struct IIIlll*IllII,const struct lIllIlIIl __user*ioctl){
int IIIll=-ENODEV;IIIIl IllllI;IIlll("\x2b\x2b" "\n");do
{char lllllI[sizeof(ioctl->lllllI)+(0xdd4+5575-0x239a)];struct usb_device*llIII;
lIllIl speed;if(get_user(IllllI,&ioctl->lIIlII.lIIIllI)<(0x51a+3247-0x11c9)){
IIIll=-EFAULT;break;}if(IllllI<sizeof(*ioctl)){IIIll=-EINVAL;break;}lllllI[
sizeof(lllllI)-(0x49b+7987-0x23cd)]='\0';if(copy_from_user(lllllI,&ioctl->lllllI
,sizeof(ioctl->lllllI))){IIIll=-EFAULT;break;}IIIll=-ENODEV;llIII=lllllIII(
lllllI);if(llIII){const char*lIIlIIIIl,*IIlIIIIl,*IIlIIIlI;usb_lock_device(llIII
);
#if KERNEL_LT_EQ((0x1654+1531-0x1c4d),(0x1039+1839-0x1762),(0x20ac+884-0x240b))
down_write(&llIII->dev.bus->subsys.rwsem);
#endif
do
{IIIll=IIllIIll(llIII,&lIIlIIIIl,&IIlIIIIl,&IIlIIIlI);if(IIIll<
(0xa4a+7169-0x264b)){
break;}if(put_user(le16_to_cpu(llIII->descriptor.idVendor),&ioctl->IIIIIlIl)<
(0x864+2292-0x1158)){IIIll=-EFAULT;break;}if(put_user(le16_to_cpu(llIII->
descriptor.idProduct),&ioctl->lIIIllIl)<(0x42a+2159-0xc99)){IIIll=-EFAULT;break;
}if(put_user(le16_to_cpu(llIII->descriptor.bcdDevice),&ioctl->lIlIlIII)<
(0xb04+431-0xcb3)){IIIll=-EFAULT;break;}if(put_user(le16_to_cpu(llIII->
descriptor.llIIllll),&ioctl->llIIllll)<(0xa92+6964-0x25c6)){IIIll=-EFAULT;break;
}if(put_user(llIII->descriptor.bDeviceClass,&ioctl->llIIIIlI)<
(0xd16+3364-0x1a3a)){IIIll=-EFAULT;break;}if(put_user(llIII->descriptor.
bDeviceSubClass,&ioctl->llIlllll)<(0x19a+2110-0x9d8)){IIIll=-EFAULT;break;}if(
put_user(llIII->descriptor.bDeviceProtocol,&ioctl->lllIlllI)<(0xbc+8550-0x2222))
{IIIll=-EFAULT;break;}switch(llIII->speed){case USB_SPEED_LOW:speed=llIIlllIl;
break;case USB_SPEED_FULL:speed=lIIIIllIl;break;case USB_SPEED_HIGH:speed=
lIIIIIIII;break;case USB_SPEED_SUPER:speed=llIIIIlIl;break;
#if KERNEL_GT_EQ((0x588+5869-0x1c71),(0x1827+2382-0x216f),(0x1ae7+1242-0x1fc1))
case USB_SPEED_SUPER_PLUS:speed=IlIIlIlII;break;
#endif
default:speed=IllIIIIII;break;}if(put_user(speed,&ioctl->IIllIlIIl)<
(0x247+4070-0x122d)){IIIll=-EFAULT;break;}if(copy_to_user((void*)&ioctl->llIIllI
,(void*)IIlIIIlI,strlen(IIlIIIlI)+(0x6f2+4311-0x17c8))){IIIll=-EFAULT;break;}if(
copy_to_user((void*)&ioctl->serial,(void*)IIlIIIIl,strlen(IIlIIIIl)+
(0xfc0+2808-0x1ab7))){IIIll=-EFAULT;break;}if(copy_to_user((void*)&ioctl->
description,(void*),strlen()+(0xfb9+4198-0x201e))){IIIll=-EFAULT;break;}}while(
(0x5a5+2818-0x10a7));
#if KERNEL_LT_EQ((0x781+1626-0xdd9),(0x12fb+1891-0x1a58),(0x84+9299-0x24c2))
up_write(&llIII->dev.bus->subsys.rwsem);
#endif
usb_unlock_device(llIII);usb_put_dev(llIII);}else{IIlll(
"\x64\x65\x76\x69\x63\x65\x20\x25\x73\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,lllllI);}}while((0x166a+3465-0x23f3));IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}
#endif
static int llIIIIllI(struct IIIlll*IllII,const char __user*IIIlI){int IIIll=
(0x87f+2761-0x1348);const char __user*llllIlll;struct list_head IlllIIII;struct 
lIlllllIII IlIIIll;IIIIl lllIlI;IIlll("\x2b\x2b" "\n");INIT_LIST_HEAD(&IlllIIII)
;if(copy_from_user(&IlIIIll,IIIlI,sizeof(IlIIIll))){return-EFAULT;}llllIlll=
IIIlI+IlIIIll.lIIlII.lIIIllI;if(IIIlI+sizeof(IlIIIll)>llllIlll){return-EINVAL;}
IIIlI+=sizeof(IlIIIll);IIlll("\x63\x6f\x75\x6e\x74\x3d\x25\x64" "\n",IlIIIll.
IlllIllI);for(lllIlI=(0x521+2841-0x103a);lllIlI<IlIIIll.IlllIllI;lllIlI++){
size_t IlIIIlII;size_t IlIIlllI;struct lIllIIII IIIIllI;struct IllIIIll*IlIlIl;
if(IIIlI+sizeof(IIIIllI)>llllIlll){IIIll=-EINVAL;break;}if(copy_from_user(&
IIIIllI,IIIlI,sizeof(IIIIllI))){IIIll=-EFAULT;break;}IlIIlllI=sizeof(struct 
lIllIIII);IlIIIlII=sizeof(struct IllIIIll);if(IIIlI+IlIIlllI>llllIlll){IIIll=-
EINVAL;break;}IlIlIl=IllIIlI(IlIIIlII,GFP_KERNEL);if(IlIlIl==NULL){IIIll=-ENOMEM
;break;}if(copy_from_user(&IlIlIl->IIIIllI,IIIlI,IlIIlllI)){lIlIll(IlIlIl);IIIll
=-EFAULT;break;}IIlll(
"\x56\x3d\x25\x30\x34\x58\x20\x50\x3d\x25\x30\x34\x58\x20\x51\x3d\x30\x78\x25\x30\x38\x58" "\n"
,IlIlIl->IIIIllI.IIIIIlIl,IlIlIl->IIIIllI.lIIIllIl,IlIlIl->IIIIllI.IllIlIlII);
list_add_tail(&IlIlIl->entry,&IlllIIII);IIIlI+=IlIIlllI;}
if(lllIlI!=IlIIIll.IlllIllI){IIIll=-EINVAL;}
if(IIIll>=(0x1ac5+1795-0x21c8)){IIlll("\x75\x70\x64\x61\x74\x65" "\n");IllIllIlI
(&IlllIIII);}
if(IIIll<(0x1ec4+601-0x211d)){while(!list_empty(&IlllIIII)){struct IllIIIll*
IIIlIII;IIIlIII=list_entry(IlllIIII.next,struct IllIIIll,entry);list_del(&
IIIlIII->entry);lIlIll(IIIlIII);}}IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}
static int lIlIlIIlI(struct IIIlll*IllII,const struct IlllIIlII __user*ioctl){
int IIIll;IIIIl IllllI;IIlll("\x2b\x2b" "\n");do
{if(get_user(IllllI,&ioctl->lIIlII.lIIIllI)<(0x1c4+1864-0x90c)){IIIll=-EFAULT;
break;}if(IllllI!=sizeof(*ioctl)){IIIll=-EINVAL;break;}IlIlIIllI();IIIll=
(0x3f5+3091-0x1008);}while((0x11a3+1625-0x17fc));IIlll(
"\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n",IIIll);return IIIll;}
#endif 

