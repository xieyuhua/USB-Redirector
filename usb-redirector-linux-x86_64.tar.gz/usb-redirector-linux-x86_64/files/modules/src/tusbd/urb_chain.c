/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifdef _USBD_ENABLE_STUB_
#include "usbd.h"
int IlIIlIII(struct llllll*llIlI,struct urb*IIIIIIlI);int IlIIIllII(struct 
llllll*llIlI,struct urb*IIIIIIlI);void lIIIIIIIl(struct urb*IlllI
#if KERNEL_LT((0x190+7243-0x1dd9),(0xa8+6200-0x18da),(0x2357+166-0x23ea))
,struct pt_regs*IIlIlII
#endif
);struct llllll*IlIlIlIlI(int pipe,int interval,int IlIlIllI,int IlIllIl,struct 
usb_device*IlIlII,struct IIlIIll*llIllI,void*context,urb_chain_complete_t 
complete,gfp_t lIIIl){struct llllll*llIlI;int i,IIIll=(0x463+522-0x66d);struct 
usb_host_endpoint*ep;Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x2b\x2b" "\n");ep=
usb_pipein(pipe)?IlIlII->ep_in[usb_pipeendpoint(pipe)]:IlIlII->ep_out[
usb_pipeendpoint(pipe)];if(!ep){Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x2d\x2d\x20\x65\x72\x72\x6f\x72\x2c\x20\x65\x6e\x64\x70\x6f\x69\x6e\x74\x20\x69\x73\x20\x4e\x55\x4c\x4c" "\n"
);return NULL;}llIlI=IllIIlI(sizeof(struct llllll)+sizeof(struct urb*)*llIllI->
IlIII,GFP_KERNEL);if(llIlI==NULL){Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x2d\x2d\x20\x65\x72\x72\x6f\x72\x2c\x20\x6b\x6d\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64" "\n"
);return NULL;}llIlI->pipe=pipe;llIlI->IlIlIllI=IlIlIllI;llIlI->IlIllIl=IlIllIl;
llIlI->IlIlII=IlIlII;llIlI->IlIII=llIllI->IlIII;llIlI->status=
(0x9f7+2203-0x1292);llIlI->llllllIll=(0x12+4501-0x11a7);llIlI->context=context;
llIlI->complete=complete;atomic_set(&llIlI->IlIlIlII,(0x760+6571-0x210b));
spin_lock_init(&llIlI->lock);for(i=(0x163+5000-0x14eb);i<llIlI->IlIII;i++){
if(IIIll<(0xc72+3544-0x1a4a)){break;}llIlI->IIIlII[i]=IIIlllIl(llIllI->IllIIl[i]
.number_of_packets,lIIIl);if(!llIlI->IIIlII[i]){llIlII(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x61\x6c\x6c\x6f\x63\x61\x74\x65\x20\x61\x6e\x20\x75\x72\x62\x20\x2d\x20\x6e\x6f\x20\x6d\x65\x6d\x6f\x72\x79" "\n"
);IIIll=-ENOMEM;break;}llIlI->IIIlII[i]->transfer_flags|=URB_NO_INTERRUPT;switch
(usb_pipetype(pipe)){case PIPE_BULK:usb_fill_bulk_urb(llIlI->IIIlII[i],llIlI->
IlIlII,pipe,llIllI->IllIIl[i].transfer_buffer,llIllI->IllIIl[i].
transfer_buffer_length,lIIIIIIIl,llIlI);if(usb_pipein(pipe)){llIlI->IIIlII[i]->
transfer_flags|=URB_SHORT_NOT_OK;}break;case PIPE_ISOCHRONOUS:llIlI->IIIlII[i]->
dev=IlIlII;llIlI->IIIlII[i]->pipe=pipe;llIlI->IIIlII[i]->transfer_flags=
URB_ISO_ASAP;llIlI->IIIlII[i]->transfer_buffer=llIllI->IllIIl[i].transfer_buffer
;llIlI->IIIlII[i]->transfer_buffer_length=llIllI->IllIIl[i].
transfer_buffer_length;llIlI->IIIlII[i]->start_frame=-(0xb90+584-0xdd7);llIlI->
IIIlII[i]->number_of_packets=llIllI->IllIIl[i].number_of_packets;llIlI->IIIlII[i
]->context=llIlI;llIlI->IIIlII[i]->complete=lIIIIIIIl;if(interval){llIlI->IIIlII
[i]->interval=interval;}else{llIlI->IIIlII[i]->interval=ep?ep->desc.bInterval:
(0x1409+1106-0x185a);llIlI->IIIlII[i]->interval=(0xa99+4045-0x1a65)<<(llIlI->
IIIlII[i]->interval-(0x247+6439-0x1b6d));}break;default:llIlII(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x70\x69\x70\x65\x20\x74\x79\x70\x65" "\n"
);IIIll=-EINVAL;break;}llIlI->IIIlII[i]->dev=NULL;
}if(IIIll<(0x628+6880-0x2108)){
for(i--;i>=(0x1255+121-0x12ce);i--){lIIIlIIl(llIlI->IIIlII[i]);}lIlIll(llIlI);
Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x2d\x2d\x20\x66\x61\x69\x6c\x65\x64" "\n"
);return NULL;}
llIlI->IIIlII[llIlI->IlIII-(0x1eb1+32-0x1ed0)]->transfer_flags&=~
URB_NO_INTERRUPT;Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x2d\x2d\x20\x73\x75\x63\x63\x65\x73\x73" "\n"
);return llIlI;}

void llIllIlll(struct llllll*llIlI){int i;Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x66\x72\x65\x65" "\n");for(i=
(0x721+1620-0xd75);i<llIlI->IlIII;i++){if(llIlI->IIIlII[i])lIIIlIIl(llIlI->
IIIlII[i]);}lIlIll(llIlI);}void lIIIIIIIl(struct urb*IlllI
#if KERNEL_LT((0x209+479-0x3e6),(0x2b7+98-0x313),(0x156+4883-0x1456))
,struct pt_regs*IIlIlII
#endif
){struct llllll*llIlI=IlllI->context;








if(IlllI->status&&IlllI->status!=-ECONNRESET&&IlllI->status!=-ENOENT){int abort=
(0xda8+2632-0x17f0);spin_lock(&llIlI->lock);if(llIlI->status==
(0x153c+3704-0x23b4))
{
if(IlllI->status==-EREMOTEIO&&llIlI->IlIlIllI){llIlI->status=(0x22ef+547-0x2512)
;Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x3a\x20\x73\x68\x6f\x72\x74\x20\x74\x72\x61\x6e\x73\x66\x65\x72\x20\x64\x65\x74\x65\x63\x74\x65\x64\x20\x61\x6e\x64\x20\x69\x73\x20\x6f\x6b\x2e\x20\x61\x63\x74\x75\x61\x6c\x5f\x6c\x65\x6e\x67\x74\x68\x3d\x25\x64" "\n"
,IlllI->actual_length);}else{llIlI->status=IlllI->status;Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x3a\x20\x65\x61\x72\x6c\x79\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,IlllI->status);}abort=(0x166c+3646-0x24a9);}spin_unlock(&llIlI->lock);if(abort)
{IlIIlIII(llIlI,IlllI);}}
#if defined(_USBD_USE_EHCI_FIX_) && KERNEL_GT_EQ((0x78a+4476-0x1904),\
(0xddc+4170-0x1e20),(0x312+6463-0x1c38)) && KERNEL_LT_EQ((0x6d7+4854-0x19cb),\
(0x4e1+7-0x4e2),(0x837+7765-0x2670))
if(llIlI->IlIllIl&&usb_pipeisoc(IlllI->pipe)&&IlllI->status==(0xb0b+1993-0x12d4)
){if(atomic_read(&IlllI->kref.refcount)>(0x530+8200-0x2537))usb_put_urb(IlllI);}
#endif
IlllI->dev=NULL;
llIlI->llllllIll+=IlllI->actual_length;
if(atomic_dec_and_test(&llIlI->IlIlIlII)){Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x3a\x20\x61\x6c\x6c\x20\x75\x72\x62\x73\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x2d\x20\x63\x6f\x6d\x70\x6c\x65\x74\x69\x6e\x67\x20\x74\x68\x65\x20\x63\x68\x61\x69\x6e" "\n"
);llIlI->complete(llIlI);}}int lIIllIIII(struct llllll*llIlI){int i,IIIIIl,IIIll
=(0x13a7+4555-0x2572);unsigned long flags;Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x73\x75\x62\x6d\x69\x74\x3a\x20\x2b\x2b" "\n")
;atomic_set(&llIlI->IlIlIlII,llIlI->IlIII);spin_lock_irqsave(&llIlI->lock,flags)
;for(i=(0x432+2503-0xdf9),IIIIIl=(0x625+6292-0x1eb9);i<llIlI->IlIII;i++){if(
llIlI->status!=(0x18d4+1059-0x1cf7)){break;}llIlI->IIIlII[i]->dev=llIlI->IlIlII;
IIIll=usb_submit_urb(llIlI->IIIlII[i],GFP_ATOMIC);
if(IIIll!=(0xbec+5576-0x21b4)){llIlI->IIIlII[i]->dev=NULL;
}spin_unlock_irqrestore(&llIlI->lock,flags);if(IIIll==-ENXIO||IIIll==-EAGAIN||
IIIll==-ENOMEM){Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x73\x75\x62\x6d\x69\x74\x3a\x20\x72\x65\x74\x72\x79\x69\x6e\x67\x20\x66\x61\x69\x6c\x65\x64\x20\x75\x72\x62" "\n"
);
if(IIIIIl++<(0x4d9+230-0x5b5)){i--;IIIll=(0xc1f+470-0xdf5);yield();}}else{
cpu_relax();IIIIIl=(0x16b5+3284-0x2389);}spin_lock_irqsave(&llIlI->lock,flags);
if(IIIll!=(0x4bb+3244-0x1167)){Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x73\x75\x62\x6d\x69\x74\x3a\x20\x73\x75\x62\x6d\x69\x74\x20\x66\x61\x69\x6c\x65\x64" "\n"
);llIlI->status=-(0xc85+2930-0x17f6);break;}}spin_unlock_irqrestore(&llIlI->lock
,flags);
if(IIIll<(0x3b1+6377-0x1c9a)){IlIIlIII(llIlI,NULL);}else{int llIlIIlll=llIlI->
IlIII-i;
if(llIlIIlll>(0x5e0+4410-0x171a)&&atomic_sub_and_test(llIlIIlll,&llIlI->IlIlIlII
)){Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x73\x75\x62\x6d\x69\x74\x3a\x20\x69\x6f\x63\x6f\x6e\x74\x20\x69\x73\x20\x30\x2c\x20\x63\x61\x6c\x6c\x69\x6e\x67\x20\x63\x6f\x6d\x70\x6c\x65\x74\x69\x6f\x6e" "\n"
);llIlI->complete(llIlI);}}Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x73\x75\x62\x6d\x69\x74\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}int llllllIII(struct llllll*llIlI){int i;for(i=
(0x7d7+7591-0x257e);i<llIlI->IlIII;i++){usb_get_urb(llIlI->IIIlII[i]);}return
(0x6f1+6821-0x2196);}int llllIlIll(struct llllll*llIlI){int i;for(i=
(0x833+6312-0x20db);i<llIlI->IlIII;i++){usb_put_urb(llIlI->IIIlII[i]);}return
(0x497+3600-0x12a7);}int lIlIllIll(struct llllll*llIlI){unsigned long flags;int 
abort=(0x18e0+400-0x1a70);Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x75\x6e\x6c\x69\x6e\x6b\x3a\x20\x2b\x2b" "\n")
;spin_lock_irqsave(&llIlI->lock,flags);if(llIlI->status==(0x483+1692-0xb1f)){
llIlI->status=-ECONNRESET;abort=(0x89b+1988-0x105e);}spin_unlock_irqrestore(&
llIlI->lock,flags);if(abort){IlIIlIII(llIlI,NULL);}Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x75\x6e\x6c\x69\x6e\x6b\x3a\x20\x2d\x2d" "\n")
;return(0xc33+4102-0x1c39);}int lllIlIIIl(struct llllll*llIlI){unsigned long 
flags;Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x6b\x69\x6c\x6c\x3a\x20\x2b\x2b" "\n");
spin_lock_irqsave(&llIlI->lock,flags);if(llIlI->status==(0x58f+2699-0x101a)){
llIlI->status=-ECONNRESET;}spin_unlock_irqrestore(&llIlI->lock,flags);IlIIIllII(
llIlI,NULL);Illll(
"\x75\x73\x62\x64\x5f\x75\x63\x5f\x6b\x69\x6c\x6c\x3a\x20\x2d\x2d" "\n");return
(0xea4+747-0x118f);}int IlIIIllII(struct llllll*llIlI,struct urb*IIIIIIlI){int i
,IIllIIII=(0xb3d+6628-0x2521);for(i=(0x209c+112-0x210c);i<llIlI->IlIII;i++){if(!
IIllIIII&&IIIIIIlI){if(llIlI->IIIlII[i]==IIIIIIlI)IIllIIII=(0x633+3137-0x1273);}
else{if(llIlI->IIIlII[i]&&llIlI->IIIlII[i]->dev){
#if KERNEL_GT_EQ((0xa9f+447-0xc5c),(0x1152+3875-0x206f),(0xc38+353-0xd7d))


usb_poison_urb(llIlI->IIIlII[i]);
#else
usb_kill_urb(llIlI->IIIlII[i]);
#endif
}}}return(0x397+1311-0x8b6);}int IlIIlIII(struct llllll*llIlI,struct urb*
IIIIIIlI){int i,IIllIIII=(0x2f7+5355-0x17e2);for(i=(0x216+8506-0x2350);i<llIlI->
IlIII;i++){if(!IIllIIII&&IIIIIIlI){if(llIlI->IIIlII[i]==IIIIIIlI)IIllIIII=
(0xc36+2023-0x141c);}else{if(llIlI->IIIlII[i]&&llIlI->IIIlII[i]->dev)
usb_unlink_urb(llIlI->IIIlII[i]);}}return(0x6c7+7221-0x22fc);}int llIIllllI(
struct llllll*llIlI,struct urb*IlllI){int i;for(i=(0x2bc+6529-0x1c3d);i<llIlI->
IlIII;i++){if(llIlI->IIIlII[i]==IlllI)break;}return(i==llIlI->IlIII)?-
(0xa46+6394-0x233f):i;}





struct IIlIIll*IIIllIlIl(size_t length,int llllIIlI){struct IIlIIll*llIlI;size_t
 IllIIIIl;size_t IlIIlIlI;size_t IlIII;int i;Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x2b\x2b" "\n");if(
unlikely(llllIIlI==(0xa4d+4104-0x1a55))){Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x2d\x2d\x20\x65\x72\x72\x6f\x72\x2c\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72" "\n"
);return NULL;}if(unlikely(length==(0x1828+2860-0x2354))){Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x2d\x2d\x20\x65\x72\x72\x6f\x72\x2c\x20\x7a\x65\x72\x6f\x2d\x6c\x65\x6e\x67\x74\x68\x20\x62\x75\x66\x66\x65\x72" "\n"
);return NULL;}
IllIIIIl=lIIIIll-(lIIIIll%llllIIlI);IlIII=(length-(0xd17+3243-0x19c1))/IllIIIIl+
(0x22e2+167-0x2388);IlIIlIlI=length%IllIIIIl;
if(IlIIlIlI==(0x797+1786-0xe91)){IlIIlIlI=IllIIIIl;}Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x70\x61\x72\x74\x73\x69\x7a\x65\x3d\x25\x6c\x75\x20\x63\x6f\x75\x6e\x74\x3d\x25\x6c\x75" "\n"
,(unsigned long)IllIIIIl,(unsigned long)IlIII);llIlI=IllIIlI(sizeof(struct 
IIlIIll)+sizeof(((struct IIlIIll*)(0x516+1785-0xc0f))->IllIIl[
(0x153b+3901-0x2478)])*IlIII,GFP_KERNEL);if(unlikely(llIlI==NULL)){Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x2d\x2d\x20\x65\x72\x72\x6f\x72\x2c\x20\x6b\x6d\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64" "\n"
);return NULL;}llIlI->IlIII=IlIII;
for(i=(0x684+6935-0x219b);i<IlIII;i++){
size_t lIllIII=(i==IlIII-(0x32c+8055-0x22a2))?IlIIlIlI:IllIIIIl;Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x61\x6c\x6c\x6f\x63\x61\x74\x69\x6e\x67\x20\x25\x6c\x75\x20\x62\x79\x74\x65\x73" "\n"
,(unsigned long)lIllIII);llIlI->IllIIl[i].transfer_buffer=IllIIlI(lIllIII,
GFP_KERNEL);llIlI->IllIIl[i].transfer_buffer_length=lIllIII;llIlI->IllIIl[i].
actual_length=(0x4c8+4413-0x1605);llIlI->IllIIl[i].number_of_packets=
(0x1c62+14-0x1c70);if(!llIlI->IllIIl[i].transfer_buffer){Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x6b\x6d\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64" "\n"
);break;}}
if(i<IlIII){for(i--;i>=(0xfbf+4985-0x2338);i--){lIlIll(llIlI->IllIIl[i].
transfer_buffer);}lIlIll(llIlI);Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x2d\x2d\x20\x65\x72\x72\x6f\x72" "\n"
);return NULL;}Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x3a\x20\x2d\x2d\x20\x73\x75\x63\x63\x65\x73\x73\x2c\x20\x62\x63\x3d\x30\x78\x25\x70" "\n"
,llIlI);return llIlI;}


struct IIlIIll*lIIIIlIll(size_t length,IllllIlI*lIIIIIll,IIIIl llIlIlII){struct 
IIlIIll*llIlI;int i;size_t IlIII;void*lIIlIIIll;size_t lIllIII;size_t IlllIIIl;
size_t IIIlIIlI;Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x5f\x66\x6f\x72\x5f\x69\x73\x6f\x3a\x20\x2b\x2b\x20\x6c\x65\x6e\x67\x74\x68\x3d\x25\x6c\x75\x20\x6e\x75\x6d\x70\x61\x63\x6b\x65\x74\x73\x3d\x25\x64" "\n"
,(unsigned long)length,llIlIlII);if(unlikely(length==(0x1728+707-0x19eb))){Illll
(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x5f\x66\x6f\x72\x5f\x69\x73\x6f\x3a\x20\x2d\x2d\x20\x7a\x65\x72\x6f\x2d\x6c\x65\x6e\x67\x74\x68\x20\x62\x75\x66\x66\x65\x72\x28\x31\x29" "\n"
);return NULL;}if(unlikely(llIlIlII==(0x621+3005-0x11de))){Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x5f\x66\x6f\x72\x5f\x69\x73\x6f\x3a\x20\x2d\x2d\x20\x7a\x65\x72\x6f\x2d\x6c\x65\x6e\x67\x74\x68\x20\x62\x75\x66\x66\x65\x72\x28\x32\x29" "\n"
);return NULL;}



IlIII=(length-(0x1f9d+1239-0x2473))/lIIIIll+(0x1234+905-0x15bc);llIlI=IllIIlI(
sizeof(struct IIlIIll)+sizeof(struct IIIlI)*IlIII,GFP_KERNEL);if(unlikely(llIlI
==NULL)){Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x5f\x66\x6f\x72\x5f\x69\x73\x6f\x3a\x20\x2d\x2d\x20\x65\x72\x72\x6f\x72\x2c\x20\x6b\x6d\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64" "\n"
);return NULL;}llIlI->IlIII=(0x12ba+3774-0x2178);
lIllIII=(0xcab+4969-0x2014);IlllIIIl=(0xa04+3000-0x15bc);IIIlIIlI=
(0x13a4+3197-0x2021);for(i=(0xb8d+509-0xd8a);i<llIlIlII;i++){lIllIII+=lIIIIIll[i
].Length;IlllIIIl++;

if(IIIlIIlI>lIIIIIll[i].Offset){llIlII(
"\x45\x52\x52\x4f\x52\x21\x21\x21\x20\x4e\x6f\x6e\x2d\x6c\x69\x6e\x65\x61\x72\x20\x69\x73\x6f\x63\x68\x72\x6f\x6e\x6f\x75\x73\x20\x62\x75\x66\x66\x65\x72\x20\x64\x65\x74\x65\x63\x74\x65\x64\x2e\x20\x50\x6c\x65\x61\x73\x65\x20\x72\x65\x70\x6f\x72\x74\x20\x74\x68\x69\x73\x2e" "\n"
);Illll(
"\x5b\x25\x64\x5d\x20\x6c\x61\x73\x74\x5f\x6f\x66\x66\x73\x65\x74\x3d\x30\x78\x25\x6c\x78\x20\x6f\x66\x66\x73\x65\x74\x3d\x30\x78\x25\x6c\x78"
,i,(unsigned long)IIIlIIlI,(unsigned long)lIIIIIll[i].Offset);break;}IIIlIIlI=
lIIIIIll[i].Offset;


if(((llIlIlII-i)==(0x182f+3622-0x2654))||(lIllIII>=lIIIIll&&IlllIIIl>=
(0x1dbf+1081-0x21f6)&&lIIIIIll[i+(0x9e4+2315-0x12ee)].Length>
(0x1540+4365-0x264d)&&(llIlIlII-i)>(0xe01+3386-0x1b39))){if(unlikely(llIlI->
IlIII>=IlIII)){Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x5f\x66\x6f\x72\x5f\x69\x73\x6f\x3a\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x62\x75\x66\x66\x65\x72\x20\x73\x69\x7a\x65" "\n"
);break;}if(unlikely(length<lIllIII)){Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x5f\x66\x6f\x72\x5f\x69\x73\x6f\x3a\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x69\x73\x6f\x20\x62\x75\x66\x66\x65\x72" "\n"
);break;}lIIlIIIll=IllIIlI(lIllIII,GFP_KERNEL);if(unlikely(!lIIlIIIll)){Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x5f\x66\x6f\x72\x5f\x69\x73\x6f\x3a\x20\x6b\x6d\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64" "\n"
);break;}llIlI->IllIIl[llIlI->IlIII].transfer_buffer=lIIlIIIll;llIlI->IllIIl[
llIlI->IlIII].transfer_buffer_length=lIllIII;llIlI->IllIIl[llIlI->IlIII].
actual_length=(0xbb7+4783-0x1e66);llIlI->IllIIl[llIlI->IlIII].number_of_packets=
IlllIIIl;llIlI->IlIII++;length-=lIllIII;lIllIII=(0x13a3+4062-0x2381);IlllIIIl=
(0x518+3758-0x13c6);}}
if(i<llIlIlII){for(i=(0x192d+1601-0x1f6e);i<llIlI->IlIII;i++){lIlIll(llIlI->
IllIIl[i].transfer_buffer);}lIlIll(llIlI);Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x5f\x66\x6f\x72\x5f\x69\x73\x6f\x3a\x20\x2d\x2d\x20\x65\x72\x72\x6f\x72" "\n"
);return NULL;}Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x61\x6c\x6c\x6f\x63\x5f\x66\x6f\x72\x5f\x69\x73\x6f\x3a\x20\x2d\x2d\x20\x73\x75\x63\x63\x65\x73\x73\x2c\x20\x62\x63\x3d\x30\x78\x25\x70" "\n"
,llIlI);return llIlI;}size_t IIIlllIIl(struct IIlIIll*llIlI,const void*IIIlI,
size_t length){int i;size_t lllIlI,IIIll=(0x2078+1504-0x2658);Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x63\x6f\x70\x79\x5f\x66\x72\x6f\x6d\x5f\x75\x73\x65\x72\x3a\x20\x63\x6f\x75\x6e\x74\x3d\x25\x6c\x75" "\n"
,(unsigned long)llIlI->IlIII);for(i=(0x16bb+267-0x17c6);i<llIlI->IlIII&&length>
(0x19cd+436-0x1b81);i++){lllIlI=min_t(size_t,length,llIlI->IllIIl[i].
transfer_buffer_length);if(__copy_from_user(llIlI->IllIIl[i].transfer_buffer,
IIIlI,lllIlI)!=(0x1af2+500-0x1ce6)){Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x63\x6f\x70\x79\x5f\x66\x72\x6f\x6d\x5f\x75\x73\x65\x72\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x66\x72\x6f\x6d\x20\x75\x73\x65\x72\x20\x62\x75\x66\x66\x65\x72" "\n"
);break;}llIlI->IllIIl[i].actual_length=lllIlI;IIIlI+=lllIlI;length-=lllIlI;
IIIll+=lllIlI;}return IIIll;}size_t lIlIlIlII(struct IIlIIll*llIlI,void*IIIlI,
size_t length){int i;size_t lllIlI,IIIll=(0x82f+7887-0x26fe);Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x63\x6f\x70\x79\x5f\x74\x6f\x5f\x75\x73\x65\x72\x3a\x20\x63\x6f\x75\x6e\x74\x3d\x25\x6c\x75" "\n"
,(unsigned long)llIlI->IlIII);for(i=(0x12b6+3940-0x221a);i<llIlI->IlIII&&length>
(0x199c+1925-0x2121);i++){lllIlI=min_t(size_t,length,llIlI->IllIIl[i].
actual_length);if(__copy_to_user(IIIlI,llIlI->IllIIl[i].transfer_buffer,lllIlI)
!=(0x2349+175-0x23f8)){Illll(
"\x75\x73\x62\x64\x5f\x62\x63\x5f\x63\x6f\x70\x79\x5f\x74\x6f\x5f\x75\x73\x65\x72\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x66\x72\x6f\x6d\x20\x75\x73\x65\x72\x20\x62\x75\x66\x66\x65\x72" "\n"
);break;}IIIlI+=lllIlI;length-=lllIlI;IIIll+=lllIlI;}return IIIll;}void 
IllIllllI(struct IIlIIll*llIlI){int i;for(i=(0x654+4355-0x1757);i<llIlI->IlIII;i
++){if(llIlI->IllIIl[i].transfer_buffer){lIlIll(llIlI->IllIIl[i].transfer_buffer
);}}lIlIll(llIlI);}
#endif 

