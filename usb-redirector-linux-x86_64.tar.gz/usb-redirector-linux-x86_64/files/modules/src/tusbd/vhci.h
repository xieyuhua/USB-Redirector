/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IllIllIII
#define IllIllIII
#ifdef _USBD_ENABLE_VHCI_
#include "vhci_hcd.h"


#if KERNEL_LT((0x30c+1318-0x830),(0x208+3912-0x114a),(0x8cb+2263-0x118e))
#  define lIllIll	(0x395+7482-0x20c0)
#else
#  if USB_MAXCHILDREN < (0xcc6+3851-0x1bc2)
#    define lIllIll USB_MAXCHILDREN
#  else
#    define lIllIll (0x549+6087-0x1d01)
#  endif
#endif

#define IIIllIIl ((lIllIll / (0x9da+6182-0x21f8)) + (0x29a+8617-0x2442))
struct lIlIIl{struct list_head llIIII;struct IIIlll*IllII;struct kref IllIll;int
 lIllI;int lllIIlI;int speed;int lIlllIll;
unsigned short lIIIlllII;u16 vid;u16 lIllIIl;u16 lIIlIIl;struct usb_hcd*parent;
wait_queue_head_t IIIIlI;spinlock_t IlllII;struct list_head llllIll;struct 
list_head lIlIIII;struct list_head lllIllll;void*lllIlIIl;
size_t IIlIllIlI;void*llIllIII;
size_t IllIIlII;};struct llIIlll{struct list_head llIIII;struct urb*IlllI;};

struct lIlIlI{struct list_head llllIl;struct lIlIIl*lIIII;IlIIlI lllIl;struct 
list_head IIIIlll;struct llIIlll urb;IIlIl IlIlI;};struct lIIIII{spinlock_t lock
;struct lIlIIl*lllllIl[lIllIll];int lIlIIIlI[lIllIll];int IllIIIl[lIllIll];
unsigned short IIlllIl[lIllIll];unsigned short lIIlIII[lIllIll];unsigned long 
llIlIII[lIllIll];struct usb_hcd*IllIl;struct usb_hcd*IlllIlll;unsigned lIlIIIIII
:(0x19f9+2871-0x252f);};enum lIIIlllIll{llIIllII=(0x1bdf+78-0x1c2d),
IIIIlIll,
lIlIlII,
lIIIlIl,
IIlIIlll,
IIllllI,
llIIlllll,
lIIIlIll,
};enum llllllIIII{IIlIIllI,
IlIlIIII,
llIllllI,
IIlIlIII,
IIllIllI,
IIIIlIIl,
llIlIllI,
IIllIIIl,
IIIIIIIl,
IlllIIIIl,
lllIIIIlI,
lIllIllIl,
lIIIlllI,
lIllIIlI,
lIllllIl,
lIlIIlIII,
lIllIIlII,
llIllIll,
llllIIlIl,
llIIllIlI,
};int IlllIlIII(void);void lllllIlll(void);struct lIlIIl*IlIIllllI(u16 vid,u16 
lIllIIl,u16 lIIlIIl,int speed);void lIlIIlll(struct lIlIIl*lIIII);void llIlIlIII
(void);int lIIlIIIII(struct lIlIIl*lIIII);void llIIIIlII(struct lIlIIl*lIIII);
struct lIlIIl*IIlIIllII(int IIlIII);struct lIlIIl*IllIlllIl(struct usb_hcd*IllIl
,int lllIIlI);struct lIlIIl*IIlIlIllI(struct usb_hcd*IllIl,int lIllI);void 
IIllIlll(struct lIlIIl*lIIII);struct lIlIlI*lIIIIIlll(struct lIlIIl*lIIII,gfp_t 
lIIIl);void lllIllII(struct lIlIlI*IIIII);int IllIlIIlI(struct lIlIlI*IIIII);
void IIlllIIII(struct lIlIIl*lIIII,int status);void lIIIllII(struct lIlIlI*IIIII
,int status);int llIllllIl(struct lIlIIl*lIIII,struct lIlIlI*IllIIIlIII,void*
lllll,size_t IlIIIl);int lllIllIIl(struct lIlIIl*lIIII,struct lIlIlI*IIIII,IIlIl
 IlIlI,int*status);int llllIIIll(struct lIlIIl*lIIII,struct lIlIlI**llIIllIl,
struct urb*IlllI);int lIlIllIl(struct lIlIlI*IIIII);void IIlllIlIl(struct lIlIIl
*lIIII,IIIIl*busnum,IIIIl*devnum);void lIllIlllI(struct kref*IllIlII);static 
inline struct lIlIIl*lllIIIlI(struct lIlIIl*lIIII){kref_get(&lIIII->IllIll);
return lIIII;}static inline void lIlIlIIl(struct lIlIIl*lIIII){kref_put(&lIIII->
IllIll,lIllIlllI);}
#endif 
#endif 

