/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#include "usbd.h"

#if KERNEL_LT((0x176b+3750-0x260f),(0x1a2+2099-0x9cf),(0xfbc+4320-0x208d))
#error This module requires kernel version 2.6.15 or newer
#endif

#if !defined(CONFIG_USB) && !defined(CONFIG_USB_MODULE)
#error This module requires kernel to be compiled with USB support (CONFIG_USB)
#endif

#if KERNEL_LT((0x2c6+7527-0x202a),(0x58f+2399-0xee6),(0xf5a+4161-0x1f9b)) && !\
defined(CONFIG_HOTPLUG)
#error\
 This module requires kernel to be compiled with hotplug support (CONFIG_HOTPLUG)
#endif

#if !defined(CONFIG_NET) && !defined(CONFIG_NET_MODULE)
#error\
 This module requires kernel to be compiled with networking support (CONFIG_NET)
#endif

#if KERNEL_LT_EQ((0x17d5+2344-0x20fb),(0x1803+3857-0x270e),(0x210+6463-0x1b40)) \
&& !defined(CONFIG_KOBJECT_UEVENT)
#error\
 This module requires kernel to be compiled with uevent support (CONFIG_KOBJECT_UEVENT)
#endif

#if !defined(CONFIG_UNIX) && !defined(CONFIG_UNIX_MODULE)
#error\
 This module requires kernel to be compiled with Unix domain sockets support (CONFIG_UNIX)
#endif
#ifdef _USBD_DEBUG_MEMORY_
atomic_t llIIlIllI=ATOMIC_INIT((0x7d2+5737-0x1e3b));atomic_t lllllIlIl=
ATOMIC_INIT((0x1526+800-0x1846));atomic_t IlIIllII=ATOMIC_INIT(
(0x74b+5308-0x1c07));atomic_t IIIIIllII=ATOMIC_INIT((0xbb+1942-0x851));
#ifdef ATOMIC64_INIT
atomic64_t lIIIIlll=ATOMIC64_INIT((0x15d+4658-0x138f));
#endif
atomic_t IlIlIlIl=ATOMIC_INIT((0xf7a+4004-0x1f1e));atomic_t IllllIlII=
ATOMIC_INIT((0x836+4833-0x1b17));atomic_t llIIlIIlI=ATOMIC_INIT(
(0xb34+3917-0x1a81));atomic_t lIIlIllll=ATOMIC_INIT((0x1a05+676-0x1ca9));
atomic_t IlIllIIII=ATOMIC_INIT((0xda2+6120-0x258a));atomic_t lllllllll=
ATOMIC_INIT((0xf5c+4907-0x2287));atomic_t lIllIIlIl=ATOMIC_INIT(
(0xbb3+3179-0x181e));atomic_t IIIIlllII=ATOMIC_INIT((0x1eb5+1781-0x25aa));
atomic_t lIIIIIII=ATOMIC_INIT((0xd76+4876-0x2082));atomic_t IlIIlIlll=
ATOMIC_INIT((0x337+1978-0xaf1));atomic_t llIlIIllI=ATOMIC_INIT(
(0x328+2022-0xb0e));atomic_t IllIlIIl=ATOMIC_INIT((0x22+9372-0x24be));atomic_t 
IIlIIIIII=ATOMIC_INIT((0x3b4+3562-0x119e));
#endif 

size_t lIIIIll=32768;static int IIIlllIll=(0x1741+2749-0x21fe);module_param(
IIIlllIll,int,(0xc8d+89-0xce6));static int __init IIIIllIIIl(void){int IIIll;int
 lllIlIllI=(0x5e2+6984-0x212a);
#ifdef _USBD_ENABLE_STUB_
int lllllIIlI=(0x1a44+793-0x1d5d);
#endif
#ifdef _USBD_ENABLE_VHCI_
int lIIIlIlll=(0xc52+1318-0x1178);
#endif
Illll("\x75\x73\x62\x64\x5f\x69\x6e\x69\x74\x3a\x20\x2b\x2b" "\n");do
{struct sysinfo lIIlIlI;if(IIIlllIll){Illll(
"\x75\x73\x62\x64\x5f\x69\x6e\x69\x74\x3a\x20\x70\x72\x6f\x62\x65\x2d\x6f\x6e\x6c\x79\x20\x6d\x6f\x64\x65" "\n"
);IIIll=(0x32c+3904-0x126c);break;}si_meminfo(&lIIlIlI);


if(lIIlIlI.totalram*lIIlIlI.mem_unit<=1LL*1024LL*1024LL*1024LL)
{lIIIIll=(0xd80+4465-0x1ed1)*(0xc7d+760-0xb75);}else if(lIIlIlI.totalram*lIIlIlI
.mem_unit<=2LL*1024LL*1024LL*1024LL)
{lIIIIll=(0x1329+1511-0x18e0)*(0x18a8+1961-0x1c51);}else if(lIIlIlI.totalram*
lIIlIlI.mem_unit<=4LL*1024LL*1024LL*1024LL)
{lIIIIll=(0xabc+288-0xb9c)*(0xf06+7011-0x2669);}else
{lIIIIll=(0x1125+1514-0x168f)*(0x1050+5451-0x219b);}Illll(
"\x75\x73\x62\x64\x5f\x69\x6e\x69\x74\x3a\x20\x73\x75\x67\x67\x65\x73\x74\x65\x64\x20\x6d\x61\x78\x20\x61\x6c\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x20\x73\x69\x7a\x65\x20\x25\x6c\x75\x4b\x42" "\n"
,(unsigned long)lIIIIll/(0xce6+3084-0x14f2));IIIll=llIlIIIlI();if(IIIll!=
(0xde5+1785-0x14de)){Illll(
"\x75\x73\x62\x64\x5f\x69\x6e\x69\x74\x3a\x20\x75\x73\x62\x64\x5f\x63\x64\x65\x76\x5f\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x6e\x75\x6d\x62\x65\x72\x20\x25\x64" "\n"
,IIIll);break;}lllIlIllI=(0x49c+3985-0x142c);
#ifdef _USBD_ENABLE_STUB_
IIIll=IIlIlIlIl();if(IIIll!=(0x12ec+2028-0x1ad8)){Illll(
"\x75\x73\x62\x64\x5f\x69\x6e\x69\x74\x3a\x20\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x6e\x75\x6d\x62\x65\x72\x20\x25\x64" "\n"
,IIIll);break;}lllllIIlI=(0x7b9+1845-0xeed);
#endif
#ifdef _USBD_ENABLE_VHCI_
IIIll=IlllIlIII();if(IIIll!=(0x66d+2776-0x1145)){Illll(
"\x75\x73\x62\x64\x5f\x69\x6e\x69\x74\x3a\x20\x75\x73\x62\x64\x5f\x76\x68\x63\x69\x5f\x69\x6e\x69\x74\x5f\x6d\x6f\x64\x75\x6c\x65\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x6e\x75\x6d\x62\x65\x72\x20\x25\x64" "\n"
,IIIll);break;}lIIIlIlll=(0xf01+1749-0x15d5);
#endif
}while((0xbe8+2853-0x170d));if(IIIll!=(0x6f1+2058-0xefb)){
#ifdef _USBD_ENABLE_VHCI_
if(lIIIlIlll){lllllIlll();}
#endif
#ifdef _USBD_ENABLE_STUB_
if(lllllIIlI){lIlIlIlll();}
#endif
if(lllIlIllI){IIIIllIII();}}Illll(
"\x75\x73\x62\x64\x5f\x69\x6e\x69\x74\x3a\x20\x2d\x2d" "\n");return IIIll;}
static void __exit usbd_exit(void){if(IIIlllIll){Illll(
"\x75\x73\x62\x64\x5f\x65\x78\x69\x74\x3a\x20\x70\x72\x6f\x62\x65\x2d\x6f\x6e\x6c\x79\x20\x6d\x6f\x64\x65" "\n"
);return;}
#ifdef _USBD_ENABLE_VHCI_
lllllIlll();
#endif
#ifdef _USBD_ENABLE_STUB_
lIlIlIlll();
#endif
IIIIllIII();
#ifdef _USBD_DEBUG_MEMORY_
llIlII("\x73\x74\x61\x74\x73\x3a" "\n");llIlII(
"\x75\x72\x62\x20\x61\x6c\x6c\x6f\x63\x3a\x20\x25\x64" "\n",atomic_read(&
llIIlIllI));llIlII("\x75\x72\x62\x20\x66\x72\x65\x65\x3a\x20\x25\x64" "\n",
atomic_read(&lllllIlIl));llIlII(
"\x6d\x65\x6d\x20\x61\x6c\x6c\x6f\x63\x3a\x20\x25\x64" "\n",atomic_read(&
IlIIllII));llIlII("\x6d\x65\x6d\x20\x66\x72\x65\x65\x3a\x20\x25\x64" "\n",
atomic_read(&IIIIIllII));
#ifdef ATOMIC64_INIT
llIlII("\x6d\x65\x6d\x20\x73\x69\x7a\x65\x3a\x20\x25\x6c\x6c\x64" "\n",(long 
long)atomic64_read(&lIIIIlll));
#endif
llIlII("\x75\x72\x65\x71\x20\x63\x72\x65\x61\x74\x65\x3a\x20\x25\x64" "\n",
atomic_read(&IlIlIlIl));llIlII(
"\x75\x72\x65\x71\x20\x66\x72\x65\x65\x3a\x20\x25\x64" "\n",atomic_read(&
IllllIlII));llIlII(
"\x75\x72\x65\x71\x20\x64\x65\x73\x74\x72\x6f\x79\x3a\x20\x25\x64" "\n",
atomic_read(&llIIlIIlI));llIlII(
"\x74\x72\x61\x6e\x73\x61\x63\x74\x69\x6f\x6e\x20\x61\x6c\x6c\x6f\x63\x3a\x20\x25\x64" "\n"
,atomic_read(&lIIlIllll));llIlII(
"\x74\x72\x61\x6e\x73\x61\x63\x74\x69\x6f\x6e\x20\x64\x65\x73\x74\x72\x6f\x79\x3a\x20\x25\x64" "\n"
,atomic_read(&IlIllIIII));llIlII(
"\x76\x72\x65\x71\x20\x63\x72\x65\x61\x74\x65\x3a\x20\x25\x64" "\n",atomic_read(
&lllllllll));llIlII("\x76\x72\x65\x71\x20\x66\x72\x65\x65\x3a\x20\x25\x64" "\n",
atomic_read(&lIllIIlIl));llIlII(
"\x73\x74\x75\x62\x20\x63\x72\x65\x61\x74\x65\x3a\x20\x25\x64" "\n",atomic_read(
&IIIIlllII));llIlII(
"\x73\x74\x75\x62\x20\x72\x65\x6d\x6f\x76\x65\x3a\x20\x25\x64" "\n",atomic_read(
&lIIIIIII));llIlII(
"\x73\x74\x75\x62\x20\x64\x65\x73\x74\x72\x6f\x79\x3a\x20\x25\x64" "\n",
atomic_read(&IlIIlIlll));llIlII(
"\x76\x73\x74\x75\x62\x20\x63\x72\x65\x61\x74\x65\x3a\x20\x25\x64" "\n",
atomic_read(&llIlIIllI));llIlII(
"\x76\x73\x74\x75\x62\x20\x72\x65\x6d\x6f\x76\x65\x3a\x20\x25\x64" "\n",
atomic_read(&IllIlIIl));llIlII(
"\x76\x73\x74\x75\x62\x20\x64\x65\x73\x74\x72\x6f\x79\x3a\x20\x25\x64" "\n",
atomic_read(&IIlIIIIII));
#endif 
Illll("\x75\x73\x62\x64\x5f\x65\x78\x69\x74" "\n");}module_init(IIIIllIIIl);
module_exit(usbd_exit);MODULE_LICENSE("\x47\x50\x4c");
