/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IllIIlIII
#define IllIIlIII
#ifdef _USBD_ENABLE_VHCI_
#include "cdev.h"
int IIIlIllII(struct lIlIIl*lIIII);void lIlIIIlll(struct lIlIIl*lIIII);int 
IIlIlIIlI(struct lIlIIl*lIIII);void llIlIIIl(struct lIlIIl*lIIII);
#endif 
#endif 

