/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef lllllIllll
#define lllllIllll
struct IllIlllI;struct IIIlll{struct{ssize_t(*read)(void*,char __user*,size_t);
ssize_t(*write)(void*,const char __user*,size_t);long(*unlocked_ioctl)(void*,
unsigned int,unsigned long);long(*compat_ioctl)(void*,unsigned int,unsigned long
);int(*open)(void*,int);int(*release)(void*,int);unsigned int(*poll)(void*,
struct file*lIlllI,poll_table*);int(*mmap)(void*,struct vm_area_struct*Illllll);
void(*IIlIIIII)(void*);void(*IllIIllI)(void*);}ops;int IIlIII;int lllIllI;struct
 mutex mutex;
#if KERNEL_GT_EQ((0x1584+3967-0x2501),(0x1469+1274-0x195d),(0x1349+2608-0x1d5f))\
 
struct device*dev;
#else 
struct class_device*dev;
#endif
struct IllIlllI*IlIlllII;void*context;};

struct IllIlllI{const char*name;const char*IIlIllII;const char*(*IIllllII)(void*
);
};int llIlIIIlI(void);int IIIIllIII(void);int llIIIlIl(struct IIIlll*IllII,int 
llllIIll,int lIllIIIl);void lIIlIIlI(struct IIIlll*IllII);dev_t lIIlIIIlll(
struct IIIlll*IllII);int lIIlIllI(struct IIIlll*IllII);void llIlIIIIl(struct 
IIIlll*IllII);void lllllIIII(struct IIIlll*IllII);
#endif 

