/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifdef _USBD_ENABLE_VHCI_
#include "usbd.h"
ssize_t IIllIIIll(void*,const char __user*,size_t);ssize_t lIlIllIlI(void*,char 
__user*,size_t);long lIlllIIlI(void*,unsigned int,unsigned long);
#ifdef CONFIG_COMPAT
long lIlIIIIIl(void*,unsigned int,unsigned long);
#endif
int IIllIIlll(void*,int);int llllIlllI(void*,int);void lllIIlllI(void*);void 
IIIlIlIIl(void*);unsigned int IllIIlIIl(void*,struct file*,poll_table*IIIIlI);
int lIIllIIIl(void*,struct vm_area_struct*);static struct IllIlllI IllIlIllI[]={
{"\x74\x79\x70\x65","\x76\x73\x74\x75\x62",NULL},{NULL,NULL,NULL},};int 
IIIlIllII(struct lIlIIl*lIIII){struct IIIlll*IllII;IllII=lllIlII(sizeof(*IllII),
GFP_KERNEL);if(IllII){mutex_init(&IllII->mutex);IllII->context=lIIII;IllII->
IIlIII=-(0xac7+6953-0x25ef);IllII->ops.open=IIllIIlll;IllII->ops.release=
llllIlllI;IllII->ops.unlocked_ioctl=lIlllIIlI;
#ifdef CONFIG_COMPAT
IllII->ops.compat_ioctl=lIlIIIIIl;
#endif
IllII->ops.read=lIlIllIlI;IllII->ops.write=IIllIIIll;IllII->ops.poll=IllIIlIIl;
IllII->ops.mmap=lIIllIIIl;IllII->ops.IIlIIIII=lllIIlllI;IllII->ops.IllIIllI=
IIIlIlIIl;IllII->IlIlllII=IllIlIllI;lIIII->IllII=IllII;return(0xd3f+3039-0x191e)
;}return-ENOMEM;}void lIlIIIlll(struct lIlIIl*lIIII){if(lIIII->IllII){llIlIIIl(
lIIII);lIlIll(lIIII->IllII);lIIII->IllII=NULL;}}int IIlIlIIlI(struct lIlIIl*
lIIII){return llIIIlIl(lIIII->IllII,(0xda2+3098-0x19ba),-(0x864+4462-0x19d1));}
void llIlIIIl(struct lIlIIl*lIIII){lIIlIIlI(lIIII->IllII);}ssize_t lIlIllIlI(
void*context,char __user*IIIlI,size_t IlIII){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x72\x65\x61\x64\x3a" "\n"
);return(0x672+3691-0x14dd);}ssize_t IIllIIIll(void*context,const char __user*
IIIlI,size_t IlIII){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x77\x72\x69\x74\x65" "\n"
);return(0x1de7+292-0x1f0b);}int IIllIllII(struct lIlIIl*lIIII,void __user*IIIlI
){unsigned long offset=(unsigned long)IIIlI;int IIIll;unsigned long flags;struct
 lIlIlI*IIIII;void*lllll;size_t IlIIIl;Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2b\x2b" "\n"
);if(offset>=lIIII->IIlIllIlI){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x61\x72\x67\x75\x6d\x65\x6e\x74" "\n"
);return-EINVAL;}if((lIIII->IIlIllIlI-offset)<sizeof(IlIllI)){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x61\x72\x67\x75\x6d\x65\x6e\x74" "\n"
);return-EINVAL;}if(lIIII->lIlllIll){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x72\x65\x73\x65\x74\x20\x69\x6e\x20\x70\x72\x6f\x67\x72\x65\x73\x73" "\n"
);return-ENODATA;}lllll=(char*)lIIII->lllIlIIl+offset;IlIIIl=((IlIllI*)lllll)->
IlIll;IIIII=NULL;
spin_lock_irqsave(&lIIII->IlllII,flags);if(!list_empty(&lIIII->lIlIIII)){IIIII=
list_entry(lIIII->lIlIIII.next,struct lIlIlI,llllIl);list_del_init(&IIIII->
llllIl);}spin_unlock_irqrestore(&lIIII->IlllII,flags);Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x70\x76\x72\x65\x71\x20\x3d\x20\x30\x78\x25\x70" "\n"
,IIIII);if(IIIII){IIIll=llIllllIl(lIIII,IIIII,lllll,IlIIIl);if(IIIll>=
(0x1480+4192-0x24e0)){spin_lock_irqsave(&lIIII->IlllII,flags);if(lIlIllIl(IIIII)
){
spin_unlock_irqrestore(&lIIII->IlllII,flags);Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x72\x65\x71\x75\x65\x73\x74\x20\x68\x61\x73\x20\x62\x65\x65\x6e\x20\x63\x61\x6e\x63\x65\x6c\x6c\x65\x64\x21" "\n"
);lIIIllII(IIIII,-ECONNRESET);lllIllII(IIIII);IIIll=-ENODATA;}else{
list_add_tail(&IIIII->llllIl,&lIIII->lllIllll);spin_unlock_irqrestore(&lIIII->
IlllII,flags);llllIII("\x53\x55\x42\x4d\x49\x54",(IIlIl)lllll);}}else if(IIIll==
-EMSGSIZE){
spin_lock_irqsave(&lIIII->IlllII,flags);if(lIlIllIl(IIIII)){
spin_unlock_irqrestore(&lIIII->IlllII,flags);Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x72\x65\x71\x75\x65\x73\x74\x20\x68\x61\x73\x20\x62\x65\x65\x6e\x20\x63\x61\x6e\x63\x65\x6c\x6c\x65\x64\x21" "\n"
);lIIIllII(IIIII,-ECONNRESET);lllIllII(IIIII);IIIll=-ENODATA;}else{Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x6e\x6f\x74\x20\x65\x6e\x6f\x75\x67\x68\x20\x62\x75\x66\x66\x65\x72\x20\x74\x6f\x20\x70\x61\x63\x6b\x20\x74\x68\x65\x20\x72\x65\x71\x75\x65\x73\x74" "\n"
);
list_add(&IIIII->llllIl,&lIIII->lIlIIII);spin_unlock_irqrestore(&lIIII->IlllII,
flags);
wake_up(&lIIII->IIIIlI);}}else{Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x63\x61\x6e\x20\x6e\x6f\x74\x20\x70\x61\x63\x6b\x20\x72\x65\x71\x75\x65\x73\x74\x2c\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);lIIIllII(IIIII,IIIll);lllIllII(IIIII);IIIll=-ENODATA;}}else{Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x6e\x6f\x20\x65\x6e\x74\x72\x79" "\n"
);IIIll=-ENODATA;}Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}int lIIlllIIII(struct lIlIIl*lIIII,void __user*IIIlI){
unsigned long offset=(unsigned long)IIIlI;int IIIll;IIlIl IlIlI;unsigned long 
flags;struct lIlIlI*IIIII;struct lIlIlI*lIIlIll;Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x2b\x2b" "\n"
);if(offset>=lIIII->IllIIlII){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x61\x72\x67\x75\x6d\x65\x6e\x74" "\n"
);return-EINVAL;}if((lIIII->IllIIlII-offset)<sizeof(IlIllI)){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x61\x72\x67\x75\x6d\x65\x6e\x74" "\n"
);return-EINVAL;}IlIlI=(IIlIl)((char*)lIIII->llIllIII+offset);if((lIIII->
IllIIlII-offset)<IlIlI->lllII.IlIll){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x64\x61\x74\x61" "\n"
);return-EINVAL;}llllIII("\x43\x4f\x4d\x50\x4c\x45\x54\x45",IlIlI);IIIII=NULL;
spin_lock_irqsave(&lIIII->IlllII,flags);list_for_each_entry(lIIlIll,&lIIII->
lllIllll,llllIl){if(lIIlIll->lllIl==IlIlI->lllII.IIllll){
list_del_init(&lIIlIll->llllIl);
IIIII=lIIlIll;break;}}spin_unlock_irqrestore(&lIIII->IlllII,flags);if(IIIII){int
 status;IIIll=lllIllIIl(lIIII,IIIII,IlIlI,&status);if(IIIll<(0x1407+4453-0x256c)
){
spin_lock_irqsave(&lIIII->IlllII,flags);if(lIlIllIl(IIIII)){
spin_unlock_irqrestore(&lIIII->IlllII,flags);lIIIllII(IIIII,-ECONNRESET);
lllIllII(IIIII);}else{



list_add_tail(&IIIII->llllIl,&lIIII->lllIllll);spin_unlock_irqrestore(&lIIII->
IlllII,flags);}}else if(IIIll==(0x6a7+1533-0xca4)){
lIIIllII(IIIII,status);lllIllII(IIIII);}else
{


#if (0x6fb+6705-0x212c)

lllIlIlIl("\x44\x52\x4f\x50\x3a",&IlIlI->llIll+(0x8dc+7720-0x2703),IlIlI->llIll.
IIllI);
#endif
spin_lock_irqsave(&lIIII->IlllII,flags);if(lIlIllIl(IIIII)){
spin_unlock_irqrestore(&lIIII->IlllII,flags);lIIIllII(IIIII,-ECONNRESET);
lllIllII(IIIII);}else{list_add(&IIIII->llllIl,&lIIII->lIlIIII);
spin_unlock_irqrestore(&lIIII->IlllII,flags);
wake_up(&lIIII->IIIIlI);}IIIll=(0x9ef+1636-0x1053);}}else{Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
);IIIll=(0xded+3420-0x1b49);}Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}int IIllIIIlI(struct lIlIIl*lIIII,struct lIIIlllIl __user*
ioctl){IIIIl IllllI;IIIIl devnum;IIIIl busnum;if(get_user(IllllI,&ioctl->lIIlII.
lIIIllI)<(0x20b0+1044-0x24c4)){return-EFAULT;}if(IllllI!=sizeof(struct lIIIlllIl
)){return-EINVAL;}IIlllIlIl(lIIII,&busnum,&devnum);if(put_user(busnum,&ioctl->
busnum)<(0xad5+4456-0x1c3d)){return-EFAULT;}if(put_user(devnum,&ioctl->devnum)<
(0x18f5+442-0x1aaf)){return-EFAULT;}return(0x1796+64-0x17d6);}long IlIIllIlI(
void*context,unsigned int lIIIIl,void __user*IlIIII){struct lIlIIl*lIIII=context
;int IIIll=(0x51c+7065-0x20b5);Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x2b\x2b\x20\x63\x6d\x64\x3d\x25\x64\x20\x61\x72\x67\x3d\x30\x78\x25\x70" "\n"
,lIIIIl,IlIIII);switch(lIIIIl){case lIIIllIII:IIIll=IIllIllII(lIIII,IlIIII);
break;case lIIIlIIll:IIIll=lIIlllIIII(lIIII,IlIIII);break;case lllIIlIlI:IIIll=
IIllIIIlI(lIIII,IlIIII);break;default:Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x69\x6f\x63\x74\x6c" "\n"
);IIIll=-EINVAL;break;}Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}long lIlllIIlI(void*context,unsigned int lIIIIl,unsigned 
long IlIIII){return IlIIllIlI(context,lIIIIl,(void __user*)IlIIII);}
#ifdef CONFIG_COMPAT
long lIlIIIIIl(void*context,unsigned int lIIIIl,unsigned long IlIIII){return 
IlIIllIlI(context,lIIIIl,compat_ptr(IlIIII));}
#endif
int lIIllIIIl(void*context,struct vm_area_struct*Illllll){int IIIll;struct 
lIlIIl*lIIII=context;void*IIIlI;unsigned long IIlIIl;unsigned long offset;Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6d\x6d\x61\x70\x3a\x20\x2b\x2b" "\n"
);IIlIIl=Illllll->vm_end-Illllll->vm_start;offset=Illllll->vm_pgoff<<PAGE_SHIFT;
if(IIlIIl<sizeof(IlIllI)||IIlIIl>lIIlllII){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6d\x6d\x61\x70\x3a\x20\x2d\x2d\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x6c\x65\x6e\x67\x74\x68" "\n"
);return-EINVAL;}if(offset!=(0xcf2+5933-0x241f)&&offset!=0x80000000U){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6d\x6d\x61\x70\x3a\x20\x2d\x2d\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x6f\x66\x66\x73\x65\x74" "\n"
);return-EINVAL;}IIIlI=vmalloc(IIlIIl);if(IIIlI==NULL){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6d\x6d\x61\x70\x3a\x20\x6e\x6f\x20\x6d\x65\x6d\x6f\x72\x79\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x65\x62\x75\x66" "\n"
);return-ENOMEM;}
IIIll=llllllIIl(IIIlI,Illllll);if(IIIll==(0xac1+4582-0x1ca7)){if(offset==
(0x12+597-0x267)){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6d\x6d\x61\x70\x3a\x20\x6d\x61\x70\x20\x72\x65\x61\x64\x62\x75\x66" "\n"
);if(lIIII->lllIlIIl){vfree(lIIII->lllIlIIl);}lIIII->lllIlIIl=IIIlI;lIIII->
IIlIllIlI=IIlIIl;}else{Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6d\x6d\x61\x70\x3a\x20\x6d\x61\x70\x20\x77\x72\x69\x74\x65\x62\x75\x66" "\n"
);if(lIIII->llIllIII){vfree(lIIII->llIllIII);}lIIII->llIllIII=IIIlI;lIIII->
IllIIlII=IIlIIl;}}Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6d\x6d\x61\x70\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}

int IIllIIlll(void*context,int lllIllI){int IIIll=(0x741+2284-0x102d);struct 
lIlIIl*lIIII=context;Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6f\x70\x65\x6e\x3a\x20\x2b\x2b\x20\x25\x64" "\n"
,lllIllI);if(lllIllI==(0x1ff+4545-0x13bf)){
lIIII=lIIII;
}Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6f\x70\x65\x6e\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}

int llllIlllI(void*context,int lllIllI){struct lIlIIl*lIIII=context;Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x72\x65\x6c\x65\x61\x73\x65\x20\x25\x64" "\n"
,lllIllI);if(lllIllI==(0x37+7128-0x1c0f)){if(lIIII->lllIlIIl){vfree(lIIII->
lllIlIIl);lIIII->lllIlIIl=NULL;}if(lIIII->llIllIII){vfree(lIIII->llIllIII);lIIII
->llIllIII=NULL;}

}return(0xbdc+2154-0x1446);}void lllIIlllI(void*context){struct lIlIIl*lIIII=
context;lllIIIlI(lIIII);}void IIIlIlIIl(void*context){struct lIlIIl*lIIII=
context;lIlIlIIl(lIIII);}unsigned int IllIIlIIl(void*context,struct file*lIlllI,
poll_table*IIIIlI){int lIlIllll;unsigned long flags;struct lIlIIl*lIIII=context;
poll_wait(lIlllI,&lIIII->IIIIlI,IIIIlI);spin_lock_irqsave(&lIIII->IlllII,flags);
lIlIllll=list_empty(&lIIII->lIlIIII);spin_unlock_irqrestore(&lIIII->IlllII,flags
);if(!lIlIllll&&!lIIII->lIlllIll){Illll(
"\x75\x73\x62\x64\x5f\x76\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x70\x6f\x6c\x6c\x3a\x20\x71\x75\x65\x75\x65\x20\x6e\x6f\x74\x20\x65\x6d\x70\x74\x79" "\n"
);return((POLLOUT|POLLWRNORM)|(POLLIN|POLLRDNORM));}return(POLLOUT|POLLWRNORM);}
#endif 

