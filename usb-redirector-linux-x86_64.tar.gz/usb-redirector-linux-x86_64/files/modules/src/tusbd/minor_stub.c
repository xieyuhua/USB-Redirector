/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifdef _USBD_ENABLE_STUB_
#include "usbd.h"
int lIIlllllI(void*,int);int IIllIlIII(void*,int);void llllIllll(void*context);
void IlIIllIII(void*context);unsigned int IIlllllII(void*,struct file*,
poll_table*IIIIlI);long IlIIlIIII(void*context,unsigned int lIIIIl,unsigned long
 IlIIII);
#ifdef CONFIG_COMPAT
long lIIIIlIIl(void*context,unsigned int lIIIIl,unsigned long IlIIII);
#endif
int llIIlIlII(struct lIlIl*lIlll);void llIIIlIlI(struct lIlIl*lIlll,int status,
gfp_t lIIIl);void IIlIIIlII(struct lIlIl*lIlll,gfp_t lIIIl);void IIlIll(struct 
lIlIl*lIlll,int status);void llIllIIII(struct lIlIl*lIlIlll,gfp_t lIIIl);void 
llllIIIIl(struct lIlIl*lIlIlll,gfp_t lIIIl);void IIlIlllll(struct lIlIl*lIlIlll,
gfp_t lIIIl);void lllIlIIlI(struct lIlIl*lIlIlll,gfp_t lIIIl);void IllIlIIIl(
struct lIlIl*lIlIlll,gfp_t lIIIl);void lIllIllll(struct lIlIl*lIlIlll,gfp_t 
lIIIl);void IlIIIIllI(struct lIlIl*lIlIlll,gfp_t lIIIl);
#if KERNEL_GT_EQ((0x167b+3530-0x2443),(0x1b88+1510-0x2168),(0x1f0+2218-0xa7b))
void IlIllIllI(struct lIlIl*lIlIlll,gfp_t lIIIl);
#endif
void lIllllIlI(struct lIlIl*lIlIlll,gfp_t lIIIl);void lIllIlIlI(struct lIlIl*
lIlIlll,gfp_t lIIIl);
#if KERNEL_GT_EQ((0x13a4+300-0x14ce),(0x5c2+3749-0x1461),(0x29d+1053-0x69b))
void IIIlIllIl(struct lIlIl*lIlIlll,gfp_t lIIIl);
#endif
void IlIllIlll(struct lIlIl*lIlIlll,gfp_t lIIIl);void lllIllIII(struct lIlIl*
lIlIlll,gfp_t lIIIl);void llllIIIlI(struct lIlIl*lIlIlll,gfp_t lIIIl);void 
IIIIllIlI(struct lIlIl*lIlIlll,gfp_t lIIIl);void lIIlIlllI(struct lIlIl*lIlIlll,
gfp_t lIIIl);void IlIlIlIll(struct lIlIl*lIlIlll,gfp_t lIIIl);void IlllIIllI(
struct lIlIl*lIlIlll,gfp_t lIIIl);void lIIIIlIII(struct lIlIl*lIlIlll,gfp_t 
lIIIl);void IIIIlllIl(struct lIlIl*lIlIlll,gfp_t lIIIl);void lIlIlIIIl(struct 
lIlIl*lIlll,int status,gfp_t lIIIl);void IIlIlIlI(struct lIlIl*lIlll,int status,
gfp_t lIIIl);void IlIIIIIII(struct lIlIl*lIlll,int status,gfp_t lIIIl);void 
IIIIIllIl(struct lIlIl*lIlll,int status,gfp_t lIIIl);void lllIlIlII(struct lIlIl
*lIlll,int status,gfp_t lIIIl);void lIIIlIIlI(struct lIlIl*lIlll,int status,
gfp_t lIIIl);void llIlIllll(struct lIlIl*lIlll,int status,gfp_t lIIIl);void 
IIIIIIIII(struct lIlIl*lIlll,int status,gfp_t lIIIl);void IlIlllIlI(struct lIlIl
*lIlll,int status,gfp_t lIIIl);void IlIlllI(struct lIlIl*lIlll,int status,gfp_t 
lIIIl);void IlIIllIl(struct lIlIl*lIlll,int status,gfp_t lIIIl);void lIlllIlI(
struct lIlIl*lIlll,int status,gfp_t lIIIl);
#if KERNEL_LT((0x20bc+1254-0x25a0),(0x716+3571-0x1503),(0x214f+976-0x250c))
void IIIIIllll(struct urb*IlllI,struct pt_regs*IIlIlII);void lIIllIIlI(struct 
urb*IlllI,struct pt_regs*IIlIlII);void lIIIIlIl(struct urb*IlllI,struct pt_regs*
IIlIlII);void llllIllI(struct urb*IlllI,struct pt_regs*IIlIlII);void IIIllIllI(
struct urb*IlllI,struct pt_regs*IIlIlII);static void IIlIlIIIl(struct urb*IlllI,
struct pt_regs*IIlIlII);static void lIIllIII(struct urb*IlllI,struct pt_regs*
IIlIlII);static void llIlllIlI(struct urb*IlllI,struct pt_regs*IIlIlII);
#else
void IIIIIllll(struct urb*IlllI);void lIIllIIlI(struct urb*IlllI);void lIIIIlIl(
struct urb*IlllI);void llllIllI(struct urb*IlllI);void IIIllIllI(struct urb*
IlllI);static void IIlIlIIIl(struct urb*IlllI);static void lIIllIII(struct urb*
IlllI);static void llIlllIlI(struct urb*IlllI);
#endif
void lIlIIIllI(struct llllll*llIlI);void IIIIIlIII(struct llllll*llIlI);int 
IlIIIIll(struct IlIIl*lIlII);int IlllIIlIl(struct lIlIl*lIlll,gfp_t lIIIl);int 
lIIlIlIlI(struct IlIIl*lIlII,IlIIlI lllIl);void IIlllIIl(struct IlIIl*lIlII);
void lIlllllI(struct IlIIl*lIlII,int IlIIIIl,int IlllllII);void lIllIIIlI(struct
 lIlIII*IIlII,int status,gfp_t lIIIl);void IlIIllIll(struct lIlIII*IIlII,int 
status,gfp_t lIIIl);void lIIlllIII(struct lIlIII*IIlII,int status,gfp_t lIIIl);
void lIlIIIIl(struct lIlIII*IIlII);void IIIIlIIII(struct lIlIII*IIlII);void 
lIIlllIIl(struct lIlIII*IIlII,struct llllIIIl*lIlllII);void IIlIllIlII(struct 
kref*IllIlII);void IllIIlllI(struct lIlIII*IIlII);struct lIlIII*lIIlIIllI(struct
 IlIIl*lIlII,gfp_t lIIIl);int lIlIIllll(struct lIlIl*lIlll);int lIllIIIII(struct
 lIlIl*lIlll);int lIlIIlIlI(struct lIlIl*lIlll);int llIlllllI(struct lIlIII*
IIlII);static inline void lllIIIllI(struct lIlIII*IIlII,gfp_t lIIIl);static 
inline void llIllIIll(struct lIlIII*IIlII,gfp_t lIIIl);static inline void 
IlIIlIIIl(struct lIlIII*IIlII,gfp_t lIIIl);static inline void llIIIIll(struct 
lIlIII*IIlII);static inline void lIlllIl(struct lIlIII*IIlII);void llIIIIII(
struct IlIIl*lIlII,IlIIlI lllIl);struct lIlIl*Illlllll(struct IlIIl*lIlII,IlIIlI
 lllIl);static struct IllIlllI IIllIllll[]={{"\x74\x79\x70\x65",
"\x73\x74\x75\x62",NULL},{"\x64\x65\x76",NULL,lllIIllll},{
"\x73\x75\x70\x70\x72\x65\x73\x73",NULL,IIllllIll},{NULL,NULL,NULL},};int 
IllIlIIII(struct IlIIl*lIlII){struct IIIlll*IllII;IllII=lllIlII(sizeof(*IllII),
GFP_KERNEL);if(IllII){mutex_init(&IllII->mutex);IllII->context=lIlII;IllII->
IIlIII=-(0x13a4+1837-0x1ad0);IllII->ops.open=lIIlllllI;IllII->ops.release=
IIllIlIII;IllII->ops.poll=IIlllllII;IllII->ops.unlocked_ioctl=IlIIlIIII;
#ifdef CONFIG_COMPAT
IllII->ops.compat_ioctl=lIIIIlIIl;
#endif
IllII->ops.IIlIIIII=llllIllll;IllII->ops.IllIIllI=IlIIllIII;IllII->IlIlllII=
IIllIllll;lIlII->IllII=IllII;return(0x1634+19-0x1647);}return-ENOMEM;}void 
IIlllIIIl(struct IlIIl*lIlII){if(lIlII->IllII){lllIlIIII(lIlII);lIlIll(lIlII->
IllII);lIlII->IllII=NULL;}}int IIllllIIl(struct IlIIl*lIlII){return llIIIlIl(
lIlII->IllII,(0xafa+2404-0x145c),-(0x1563+736-0x1842));}void lllIlIIII(struct 
IlIIl*lIlII){lIIlIIlI(lIlII->IllII);}int IlIllllIl(struct IlIIl*lIlII,void 
__user*IIIlI){int IIIll=(0x1478+39-0x149f);unsigned long flags;struct lIlIl*
lIlll;IIIIl llllllllI;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2b\x2b" "\n"
);
#if KERNEL_GT_EQ((0x17f9+2587-0x220f),(0x18bf+3577-0x26b8),(0xfd2+3192-0x1c4a)) \
|| RHEL_RELEASE_GT_EQ((0xce3+136-0xd63),(0x60d+2340-0xf31))
if(!access_ok(IIIlI,sizeof(IlIllI)))
#else
if(!access_ok(VERIFY_READ,IIIlI,sizeof(IlIllI)))
#endif
{Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x6d\x65\x6d\x6f\x72\x79\x20\x61\x63\x63\x65\x73\x73\x20\x63\x68\x65\x63\x6b\x20\x66\x61\x69\x6c\x65\x64" "\n"
);return-EINVAL;}
if(get_user(llllllllI,&((IlIllI*)IIIlI)->IlIll)<(0x5bd+6437-0x1ee2)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x63\x61\x6e\x6e\x6f\x74\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x75\x73\x65\x72\x20\x62\x75\x66\x66\x65\x72" "\n"
);return-EFAULT;}lIlll=NULL;spin_lock_irqsave(&lIlII->lllllll,flags);if(!
list_empty(&lIlII->llIlIlIl)){lIlll=list_entry(lIlII->llIlIlIl.next,struct lIlIl
,llllIl);list_del_init(&lIlll->llllIl);}spin_unlock_irqrestore(&lIlII->lllllll,
flags);if(lIlll){IIIll=IllIlIlIl(lIlll,IIIlI,llllllllI);if(IIIll==-EMSGSIZE){




spin_lock_irqsave(&lIlII->lllllll,flags);list_add(&lIlll->llllIl,&lIlII->
llIlIlIl);spin_unlock_irqrestore(&lIlII->lllllll,flags);
wake_up(&lIlII->IIIIlI);}else{llIllll(lIlll);}}else{Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x6e\x6f\x20\x6d\x6f\x72\x65\x20\x64\x61\x74\x61" "\n"
);IIIll=-ENODATA;}Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x72\x65\x74\x75\x72\x6e\x69\x6e\x67\x20\x25\x64" "\n"
,IIIll);return IIIll;}int llIlIllIl(struct IlIIl*lIlII,void __user*IIIlI){int 
IIIll;IIlIl IlIlI;struct lIlIl*lIlll;IlIllI llllllII;size_t lIlIIllI;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x2b\x2b" "\n"
);if(unlikely(lIlllIlll(lIlII))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x64\x65\x76\x69\x63\x65\x20\x6f\x66\x66\x6c\x69\x6e\x65" "\n"
);return-ENODEV;}if(copy_from_user(&llllllII,IIIlI,sizeof(llllllII))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x63\x6f\x70\x79\x20\x66\x61\x69\x6c\x65\x64" "\n"
);return-EFAULT;}lIlIIllI=llllllII.IlIll;if(llllllII.IIIIIIl==IIlllIlII){
lIlIIllI-=sizeof(IlIllI);IIIlI+=sizeof(IlIllI);}while(lIlIIllI>
(0x139+1702-0x7df)){lIlll=llIlIIlII(lIlII,IIIlI,lIlIIllI);if(!lIlll){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x63\x61\x6e\x6e\x6f\x74\x20\x61\x6c\x6c\x6f\x63\x61\x74\x65\x20\x72\x65\x71\x75\x65\x73\x74" "\n"
);return-ENOMEM;}IlIlI=(IIlIl)(lIlll+(0xb61+5991-0x22c7));if(lIlIIllI<IlIlI->
lllII.IlIll){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x73\x69\x7a\x65" "\n"
);return-EINVAL;}lIlIIllI-=IlIlI->lllII.IlIll;IIIlI+=IlIlI->lllII.IlIll;llllIII(
"\x53\x55\x42\x4d\x49\x54",IlIlI);IIIll=llIIlIlII(lIlll);if(likely(IIIll>
(0x2f5+9040-0x2645))){
IIlIIIlII(lIlll,GFP_KERNEL);}else if(IIIll==(0x4ba+890-0x834)){
}else if(lIlll->IlIIIIl)
{llIllll(lIlll);}else{llIIIlIlI(lIlll,IIIll,GFP_KERNEL);IIlIll(lIlll,IIIll);}}
Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x30" "\n"
);return(0x2+950-0x3b8);}int lIllIllII(struct IlIIl*lIlII){unsigned long flags;
struct list_head Illlll;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x64\x72\x61\x69\x6e\x5f\x72\x65\x71\x75\x65\x73\x74\x73\x3a\x20\x2b\x2b" "\n"
);






IIIlIlII(lIlII,NULL,(0x597+7551-0x2315),(0x632+998-0xa17));

INIT_LIST_HEAD(&Illlll);spin_lock_irqsave(&lIlII->lllllll,flags);
list_splice_init(&lIlII->llIlIlIl,&Illlll);spin_unlock_irqrestore(&lIlII->
lllllll,flags);while(!list_empty(&Illlll)){struct lIlIl*lllIlllll;lllIlllll=
list_entry(Illlll.next,struct lIlIl,llllIl);list_del(&lllIlllll->llllIl);llIllll
(lllIlllll);}Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x64\x72\x61\x69\x6e\x5f\x72\x65\x71\x75\x65\x73\x74\x73\x3a\x20\x2d\x2d" "\n"
);return(0x1135+1347-0x1678);}int lIIIIllll(struct IlIIl*lIlII,struct lllllllIl 
__user*ioctl){IIIIl IllllI;IIIIl lllIlIl;if(get_user(IllllI,&ioctl->lIIlII.
lIIIllI)<(0x58b+1052-0x9a7)){return-EFAULT;}if(IllllI!=sizeof(struct lllllllIl))
{return-EINVAL;}if(get_user(lllIlIl,&ioctl->lllIlIl)<(0x1fb7+1703-0x265e)){
return-EFAULT;}if(lllIlIl>=IllIIlIlI){return-EINVAL;}lIlII->IlIIllll=lllIlIl;
return(0x237+6427-0x1b52);}int IllIIIlIl(struct IlIIl*lIlII,struct IIIlllllI 
__user*ioctl){IIIIl IllllI;IIIIl IlIlIII;if(get_user(IllllI,&ioctl->lIIlII.
lIIIllI)<(0xed3+5835-0x259e)){return-EFAULT;}if(IllllI!=sizeof(struct IIIlllllI)
){return-EINVAL;}if(get_user(IlIlIII,&ioctl->IlIlIII)<(0x2126+570-0x2360)){
return-EFAULT;}lIlII->IlIlIII=IlIlIII;return(0x8cf+1713-0xf80);}
int llIlIllII(struct IlIIl*lIlII,struct IIIIlIlIl __user*ioctl){IIIIl IllllI;if(
get_user(IllllI,&ioctl->lIIlII.lIIIllI)<(0x717+1768-0xdff)){return-EFAULT;}if(
IllllI!=sizeof(struct IIIIlIlIl)){return-EINVAL;}IlIlIllII(lIlII,lIlII->IlIIllll
);return(0x55d+3160-0x11b5);}int IlIIlllII(struct IlIIl*lIlII,struct llIllllIIl 
__user*ioctl){IIIIl IllllI;IIIIl llIlIIll;if(get_user(IllllI,&ioctl->lIIlII.
lIIIllI)<(0x595+4180-0x15e9)){return-EFAULT;}if(IllllI!=sizeof(*ioctl)){return-
EINVAL;}llIlIIll=lIlII->lIlllIIl;if(put_user(llIlIIll,&ioctl->llIlIIll)<
(0x19b6+232-0x1a9e)){return-EFAULT;}return(0x789+6324-0x203d);}long IllllIlIl(
void*context,unsigned int lIIIIl,void __user*IlIIII){struct IlIIl*lIlII=context;
ssize_t IIIll=(0x137d+3111-0x1fa4);Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x2b\x2b\x20\x63\x6d\x64\x3d\x25\x64\x20\x61\x72\x67\x3d\x30\x78\x25\x70" "\n"
,lIIIIl,IlIIII);switch(lIIIIl){case lIIIllIII:IIIll=IlIllllIl(lIlII,IlIIII);
break;case lIIIlIIll:IIIll=llIlIllIl(lIlII,IlIIII);break;case llIIIlllI:IIIll=
lIllIllII(lIlII);break;case IIIllIIII:IIIll=lIIIIllll(lIlII,IlIIII);break;case 
IIIlIlllll:IIIll=IllIIIlIl(lIlII,IlIIII);break;case llIIllIIl:IIIll=llIlIllII(
lIlII,IlIIII);break;case IIIIIlIll:IIIll=IlIIlllII(lIlII,IlIIII);break;default:
Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x69\x6f\x63\x74\x6c" "\n"
);IIIll=-EINVAL;break;}Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x6c\x75" "\n"
,(unsigned long)IIIll);return IIIll;}long IlIIlIIII(void*context,unsigned int 
lIIIIl,unsigned long IlIIII){return IllllIlIl(context,lIIIIl,(void __user*)
IlIIII);}
#ifdef CONFIG_COMPAT
long lIIIIlIIl(void*context,unsigned int lIIIIl,unsigned long IlIIII){return 
IllllIlIl(context,lIIIIl,compat_ptr(IlIIII));}
#endif


int lIIlllllI(void*context,int lllIllI){int IIIll=(0xcb4+1998-0x1482);
Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6f\x70\x65\x6e\x3a\x20\x2b\x2b\x20\x25\x64" "\n"
,lllIllI);
Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6f\x70\x65\x6e\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}

int IIllIlIII(void*context,int lllIllI){struct IlIIl*lIlII=context;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x72\x65\x6c\x65\x61\x73\x65\x20\x25\x64" "\n"
,lllIllI);if(lllIllI==(0x172f+3224-0x23c7)){

lIllIllII(lIlII);if(lIlII->lIlllIIl){IlIlIllII(lIlII,lIlII->IlIIllll);}

}return(0xd47+180-0xdfb);}void llllIllll(void*context){struct IlIIl*lIlII=
context;IIlllIII(lIlII);}void IlIIllIII(void*context){struct IlIIl*lIlII=context
;lIIlIIIl(lIlII);}unsigned int IIlllllII(void*context,struct file*lIlllI,
poll_table*IIIIlI){struct IlIIl*lIlII=context;int lIlIllll;unsigned long flags;
poll_wait(lIlllI,&lIlII->IIIIlI,IIIIlI);spin_lock_irqsave(&lIlII->lllllll,flags)
;lIlIllll=list_empty(&lIlII->llIlIlIl);spin_unlock_irqrestore(&lIlII->lllllll,
flags);if(!lIlIllll){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x70\x6f\x6c\x6c\x3a\x20\x71\x75\x65\x75\x65\x20\x6e\x6f\x74\x20\x65\x6d\x70\x74\x79" "\n"
);return((POLLOUT|POLLWRNORM)|(POLLIN|POLLRDNORM));}return(POLLOUT|POLLWRNORM);}
int llIIlIlII(struct lIlIl*lIlll){unsigned long flags;struct IlIIl*lIlII=lIlll->
lIlII;
if(lIlll->IIIIIlI.IlIlIIlI==(0x114f+2804-0x1c43)){
spin_lock_irqsave(&lIlII->IlIlll,flags);list_add_tail(&lIlll->llllIl,&lIlII->
llllIll);spin_unlock_irqrestore(&lIlII->IlIlll,flags);return(0x430+2215-0xcd6);}
else{
struct IllllIII*IIIIIII,*IIIIIIIll;struct lIlIl*lIlllIIll,*lIIIIlII;




if(lIlll->IIIIIlI.IIlIIIlllI){IIIIIII=lllIlII(sizeof(*IIIIIII),GFP_KERNEL);
if(IIIIIII==NULL){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x61\x6c\x6c\x6f\x63\x61\x74\x65\x20\x55\x4e\x52\x42" "\n"
);return-ENOMEM;}IIIIIII->lllIl=lIlll->lllIl;spin_lock_irqsave(&lIlII->IlIlll,
flags);list_add_tail(&IIIIIII->llIIII,&lIlII->lllIIlll);list_add_tail(&lIlll->
llllIl,&lIlII->llllIll);spin_unlock_irqrestore(&lIlII->IlIlll,flags);return
(0x12ca+2231-0x1b80);}







spin_lock_irqsave(&lIlII->IlIlll,flags);

IIIIIII=NULL;list_for_each_entry(IIIIIIIll,&lIlII->lllIIlll,llIIII){if(IIIIIIIll
->lllIl==lIlll->lllIl){IIIIIII=IIIIIIIll;break;}}


if(IIIIIII==NULL){spin_unlock_irqrestore(&lIlII->IlIlll,flags);lIlll->IlIIIIl=
(0x40c+7683-0x220e);return-ECONNRESET;}


lIlllIIll=NULL;list_for_each_entry(lIIIIlII,&lIlII->llllIll,llllIl){if(lIIIIlII
->lllIl==lIlll->lllIl&&lIIIIlII->IIIIIlI.IlIlIIlI){lIlllIIll=lIIIIlII;break;}}


if(lIlllIIll==NULL){
if(IIIIIII->IlllllllI){atomic_xchg(&lIlll->state,IIIIlII);IIIIIII->IlllllllI=
(0x1931+12-0x193d);}switch(IIIIIII->lllIlllIl){case IlllIlIlI:
spin_unlock_irqrestore(&lIlII->IlIlll,flags);lIlll->IlIIIIl=(0xfb0+1022-0x13ad);
return-ECONNRESET;case llllllIlI:list_add_tail(&lIlll->llllIl,&lIlII->llllIll);
spin_unlock_irqrestore(&lIlII->IlIlll,flags);return(0xe94+2911-0x19f2);case 
IlIlIlIII:atomic_xchg(&lIlll->state,IIIIlII);list_add_tail(&lIlll->llllIl,&lIlII
->llllIll);spin_unlock_irqrestore(&lIlII->IlIlll,flags);return-ECONNRESET;case 
IllllIIll:IIIIIII->lllIlllIl=lIlll->IIIIIlI.IIlllIIll;spin_unlock_irqrestore(&
lIlII->IlIlll,flags);lIlll->IlIIIIl=(0x650+1728-0xd0f);return-ECONNRESET;}}





list_add_tail(&lIlll->llllIl,&lIlII->llllIll);spin_unlock_irqrestore(&lIlII->
IlIlll,flags);return(0x1c66+1265-0x2157);}}void IIlIIIlII(struct lIlIl*lIlll,
gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+(0xc+6788-0x1a8f));if(unlikely(
atomic_cmpxchg(&lIlll->state,lllIIIIl,llIlIll)!=lllIIIIl)){llIIIlIlI(lIlll,-
ECONNRESET,lIIIl);IIlIll(lIlll,-ECONNRESET);return;}lIlll->lIlII->lIlllIIl=
(0xba7+4259-0x1c49);switch(IlIlI->lllII.IIIIIIl){case lllllIIl:llIllIIII(lIlll,
lIIIl);break;case IlIIIIII:llllIIIIl(lIlll,lIIIl);break;case IIIlIIIl:IIlIlllll(
lIlll,lIIIl);break;case lllllIlI:lllIlIIlI(lIlll,lIIIl);break;case IIlIlllI:if(
IlllIIlIl(lIlll,lIIIl)>=(0x1b39+2217-0x23e2)){break;}IllIlIIIl(lIlll,lIIIl);
break;case llIIlIII:lIllllIlI(lIlll,lIIIl);break;case IIIlIIII:IlIllIlll(lIlll,
lIIIl);break;case IIIIIIll:IIIIllIlI(lIlll,lIIIl);break;case lIIlIIll:lIIlIlllI(
lIlll,lIIIl);break;case llIIIlll:IlIlIlIll(lIlll,lIIIl);break;case IIIlllII:
IlllIIllI(lIlll,lIIIl);break;case llIIlIIl:lIIIIlIII(lIlll,lIIIl);break;case 
IlllIIlI:IIIIlllIl(lIlll,lIIIl);break;}}void llIIIlIlI(struct lIlIl*lIlll,int 
status,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+(0xa24+3975-0x19aa));switch(IlIlI
->lllII.IIIIIIl){case lllllIIl:lIlIlIIIl(lIlll,status,lIIIl);break;case IlIIIIII
:IIlIlIlI(lIlll,status,lIIIl);break;case IIIlIIIl:lllIlIlII(lIlll,status,lIIIl);
break;case lllllIlI:IlIlllIlI(lIlll,status,lIIIl);break;case IIlIlllI:IlIlllI(
lIlll,status,lIIIl);break;case llIIlIII:IlIIllIl(lIlll,status,lIIIl);break;case 
IIIlIIII:lIlllIlI(lIlll,status,lIIIl);break;case IIIIIIll:IlIIIIIII(lIlll,status
,lIIIl);break;case lIIlIIll:IIIIIllIl(lIlll,status,lIIIl);break;case llIIIlll:
lIIIlIIlI(lIlll,status,lIIIl);break;case IIIlllII:llIlIllll(lIlll,status,lIIIl);
break;case llIIlIIl:
break;case IlllIIlI:IIIIIIIII(lIlll,status,lIIIl);break;}}void llIllIIII(struct 
lIlIl*lIlll,gfp_t lIIIl){int IIIll=(0xce1+833-0x1022);struct usb_ctrlrequest*
IlIIlII;IIlIl IlIlI=(IIlIl)(lIlll+(0x6a4+425-0x84c));do{struct urb*IlllI;IlllI=
IIIlllIl((0x103f+4794-0x22f9),lIIIl);if(unlikely(!IlllI)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x67\x65\x74\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-ENOMEM;break;}lIlll->lIIIll.IlllI=IlllI;IlIIlII=IllIIlI(sizeof(*IlIIlII
),lIIIl);if(unlikely(!IlIIlII)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x67\x65\x74\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-ENOMEM;break;}IlIIlII->bRequest=USB_REQ_GET_DESCRIPTOR;IlIIlII->
bRequestType=USB_DIR_IN+((IlIlI->IIlllI.llIIIII&(0x182b+227-0x190b))<<
(0x39d+963-0x75b))+(IlIlI->IIlllI.IIIIIllI&(0x285+6237-0x1ac3));IlIIlII->wValue=
cpu_to_le16((IlIlI->IIlllI.lIIlllll<<(0x1dc6+236-0x1eaa))+IlIlI->IIlllI.IllIIlll
);IlIIlII->wIndex=cpu_to_le16(IlIlI->IIlllI.IIllIlIl);IlIIlII->wLength=
cpu_to_le16(IlIlI->IIlllI.IIllI);usb_fill_control_urb(IlllI,lIlll->lIlII->lIIlI,
usb_rcvctrlpipe(lIlll->lIlII->lIIlI,(0x6a+9320-0x24d2)),(unsigned char*)IlIIlII,
lIlll->lIIIll.lllll,IlIlI->IIlllI.IIllI,IIIIIllll,lIlll);if(atomic_cmpxchg(&
lIlll->state,llIlIll,IllIIll)!=llIlIll){IIIll=-ECONNRESET;break;}IIIll=
usb_submit_urb(IlllI,lIIIl);if(unlikely(IIIll<(0x435+2199-0xccc))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x67\x65\x74\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IIIll);break;}}while((0x120+7544-0x1e98));if(unlikely(IIIll<
(0x15e0+2689-0x2061))){lIlIlIIIl(lIlll,IIIll,lIIIl);IIlIll(lIlll,IIIll);}}void 
lIlIlIIIl(struct lIlIl*lIlll,int status,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x871+3479-0x1607));IlIlI->IIlllI.IIllI=(0x1fa+6923-0x1d05);IlIlI->lllII.IlIll=
sizeof(IlIlI->IIlllI)+IlIlI->IIlllI.IIllI;IlIlI->lllII.Status=status;}void 
llllIIIIl(struct lIlIl*lIlll,gfp_t lIIIl){int i;int IIIll=(0x2022+1271-0x2519);
IIlIl IlIlI=(IIlIl)(lIlll+(0x227d+1122-0x26de));do
{
IlIlI->lllII.Status=(0xb5a+1832-0x1282);
IIIlIlII(lIlll->lIlII,lIlll,(0xc25+51-0xc58),(0x6b0+1552-0xcc0));if(IlIlI->
IIIllll.lllIlIll==(0xbc7+383-0xd46)){IIIll=(0x54d+4580-0x1731);break;}
usb_lock_device(lIlll->lIlII->lIIlI);







if(lIlll->lIlII->lIIlI->actconfig==NULL||lIlll->lIlII->lIIlI->actconfig->desc.
bConfigurationValue!=IlIlI->IIIllll.lllIlIll){usb_unlock_device(lIlll->lIlII->
lIIlI);
IIIll=-EINPROGRESS;break;}Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x65\x6c\x65\x63\x74\x65\x64" "\n"
);
IlIIIIll(lIlll->lIlII);for(i=(0x2338+828-0x2674);i<IlIlI->IIIllll.IIIllIlI;i++){
struct usb_interface*lllIII;struct usb_host_interface*IIllIIl;lllIII=
usb_ifnum_to_if(lIlll->lIlII->lIIlI,IlIlI->IIIllll.lIlllll[i].IlllIlI);if(!
lllIII){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,IlIlI->IIIllll.lIlllll[i].IlllIlI);continue;}IIllIIl=usb_altnum_to_altsetting(
lllIII,IlIlI->IIIllll.lIlllll[i].IllIIII);if(!IIllIIl){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x61\x6c\x74\x73\x65\x74\x74\x69\x6e\x67\x20\x25\x64\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,IlIlI->IIIllll.lIlllll[i].IlllIlI,IlIlI->IIIllll.lIlllll[i].IllIIII);continue;}
if(lllIII->cur_altsetting){if(lllIII->num_altsetting==(0x181+3872-0x10a0)){Illll
(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x68\x61\x73\x20\x6f\x6e\x6c\x79\x20\x6f\x6e\x65\x20\x61\x6c\x74\x73\x65\x74\x74\x69\x6e\x67" "\n"
,IlIlI->IIIllll.lIlllll[i].IlllIlI);continue;}if(IIllIIl->desc.bAlternateSetting
==lllIII->cur_altsetting->desc.bAlternateSetting){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x61\x6c\x74\x73\x65\x74\x74\x69\x6e\x67\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x65\x74" "\n"
,IlIlI->IIIllll.lIlllll[i].IlllIlI);continue;}}IIIll=usb_set_interface(lIlll->
lIlII->lIIlI,IlIlI->IIIllll.lIlllll[i].IlllIlI,IlIlI->IIIllll.lIlllll[i].IllIIII
);if(IIIll!=(0xf21+4880-0x2231)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x75\x73\x62\x5f\x73\x65\x74\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IIIll);IIIll=(0x562+3243-0x120d);
}if(lllIII->cur_altsetting){int IIIIIl;int pipe;for(IIIIIl=(0x255f+286-0x267d);
IIIIIl<lllIII->cur_altsetting->desc.bNumEndpoints;IIIIIl++){if(lllIII->
cur_altsetting->endpoint[IIIIIl].desc.bEndpointAddress&(0x500+2035-0xc73)){pipe=
usb_rcvisocpipe(lIlll->lIlII->lIIlI,lllIII->cur_altsetting->endpoint[IIIIIl].
desc.bEndpointAddress&(0x1af6+212-0x1bbb));}else{pipe=usb_sndisocpipe(lIlll->
lIlII->lIIlI,lllIII->cur_altsetting->endpoint[IIIIIl].desc.bEndpointAddress&
(0x563+1849-0xc8d));}IlIlllll(lIlll->lIlII,pipe,(0xb1d+5100-0x1f09));}}}
usb_unlock_device(lIlll->lIlII->lIIlI);}while((0xb43+3084-0x174f));if(unlikely(
IIIll<(0x1ce5+1669-0x236a))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IIIll);IIlIlIlI(lIlll,IIIll,lIIIl);}IIlIll(lIlll,IIIll);}void IIlIlIlI(struct 
lIlIl*lIlll,int status,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0xea1+5975-0x25f7));IlIlI->lllII.Status=status;}void IIIIllIlI(struct lIlIl*
lIlll,gfp_t lIIIl){int IIIll=(0xaa8+1903-0x1217);IIlIl IlIlI=(IIlIl)(lIlll+
(0x398+66-0x3d9));
IlIlI->lllII.Status=(0x15f4+358-0x175a);if(lIlll->lIlII->llIllII&&(lIlll->
endpoint==lIlll->lIlII->IIIIIlll||lIlll->endpoint==lIlll->lIlII->IllIlIII)){
IIlllIIl(lIlll->lIlII);}do
{
#if KERNEL_GT_EQ((0x333+6626-0x1d13),(0x9c2+4-0x9c0),(0x8b9+1033-0xcb8))
int pipe=(0xf6c+2282-0x1856),IlIIlIll;struct usb_host_endpoint*ep;ep=(IlIlI->
llIIlII.Flags&IIIllI)?lIlll->lIlII->lIIlI->ep_in[IlIlI->llIIlII.Endpoint]:lIlll
->lIlII->lIIlI->ep_out[IlIlI->llIIlII.Endpoint];if(ep){switch(ep->desc.
bmAttributes&USB_ENDPOINT_XFERTYPE_MASK){case USB_ENDPOINT_XFER_ISOC:pipe=(IlIlI
->llIIlII.Flags&IIIllI)?usb_rcvisocpipe(lIlll->lIlII->lIIlI,IlIlI->llIIlII.
Endpoint):usb_sndisocpipe(lIlll->lIlII->lIIlI,IlIlI->llIIlII.Endpoint);break;
case USB_ENDPOINT_XFER_BULK:pipe=(IlIlI->llIIlII.Flags&IIIllI)?usb_rcvbulkpipe(
lIlll->lIlII->lIIlI,IlIlI->llIIlII.Endpoint):usb_sndbulkpipe(lIlll->lIlII->lIIlI
,IlIlI->llIIlII.Endpoint);break;case USB_ENDPOINT_XFER_INT:pipe=(IlIlI->llIIlII.
Flags&IIIllI)?usb_rcvintpipe(lIlll->lIlII->lIIlI,IlIlI->llIIlII.Endpoint):
usb_sndintpipe(lIlll->lIlII->lIIlI,IlIlI->llIIlII.Endpoint);break;case 
USB_ENDPOINT_XFER_CONTROL:default:break;}}
#endif
if(ep&&(ep->desc.bmAttributes&USB_ENDPOINT_XFERTYPE_MASK)==
USB_ENDPOINT_XFER_ISOC){IlIlllll(lIlll->lIlII,pipe,(0x50f+184-0x5c7));IlIIlIll=
usb_pipeendpoint(pipe);
#if KERNEL_GT_EQ((0x167+7720-0x1f8d),(0x6aa+3203-0x1327),(0x9d+3155-0xcd2))
if(usb_pipein(pipe)){IlIIlIll|=USB_DIR_IN;}usb_reset_endpoint(lIlll->lIlII->
lIIlI,IlIIlIll);
#else
usb_settoggle(lIlll->lIlII->lIIlI,IlIIlIll,usb_pipeout(pipe),(0x316+7992-0x224e)
);
#endif
IIIll=(0x1bcf+2032-0x23bf);}else{IIIll=usb_clear_halt(lIlll->lIlII->lIIlI,pipe);
}}while((0x120c+2404-0x1b70));if(unlikely(IIIll<(0xab7+6100-0x228b))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x63\x6c\x65\x61\x72\x73\x74\x61\x6c\x6c\x3a\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IIIll);IlIIIIIII(lIlll,IIIll,lIIIl);}IIlIll(lIlll,IIIll);}void IlIIIIIII(struct
 lIlIl*lIlll,int status,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x20c9+1242-0x25a2));IlIlI->lllII.Status=status;}void lIIlIlllI(struct lIlIl*
lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+(0x12d7+3663-0x2125));IlIlI->lllII.
Status=(0xee5+489-0x10ce);IlIlI->IllIlIll.llIIllIll=usb_get_current_frame_number
(lIlll->lIlII->lIIlI);IIlIll(lIlll,(0x430+8121-0x23e9));}void IIIIIllIl(struct 
lIlIl*lIlll,int status,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x128c+367-0x13fa));IlIlI->IllIlIll.llIIllIll=(0xf37+2724-0x19db);IlIlI->lllII.
Status=status;}void IIlIlllll(struct lIlIl*lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl
)(lIlll+(0xc+3938-0xf6d));struct usb_interface*lllIII;struct usb_host_interface*
IIllIIl;
IlIlI->lllII.Status=(0x15ac+2839-0x20c3);usb_lock_device(lIlll->lIlII->lIIlI);do
{lllIII=usb_ifnum_to_if(lIlll->lIlII->lIIlI,IlIlI->llIlllI.IlllIlI);if(!lllIII){
Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,IlIlI->llIlllI.IllIIII);break;}


lIlIIlIIl(lIlll->lIlII,lllIII,lIlll,(0x8d2+7678-0x26d0));IIllIIl=
usb_altnum_to_altsetting(lllIII,IlIlI->llIlllI.IllIIII);if(!IIllIIl){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x61\x6c\x74\x73\x65\x74\x74\x69\x6e\x67\x20\x25\x64\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,IlIlI->llIlllI.IlllIlI,IlIlI->llIlllI.IllIIII);break;}if(lllIII->cur_altsetting
){if(lllIII->num_altsetting==(0x11b3+3382-0x1ee8)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x68\x61\x73\x20\x6f\x6e\x6c\x79\x20\x6f\x6e\x65\x20\x61\x6c\x74\x73\x65\x74\x74\x69\x6e\x67" "\n"
,IlIlI->llIlllI.IlllIlI);break;}if(IIllIIl->desc.bAlternateSetting==lllIII->
cur_altsetting->desc.bAlternateSetting){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x61\x6c\x74\x73\x65\x74\x74\x69\x6e\x67\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x65\x74" "\n"
,IlIlI->llIlllI.IlllIlI);break;}}IlIlI->lllII.Status=usb_set_interface(lIlll->
lIlII->lIIlI,IlIlI->llIlllI.IlllIlI,IlIlI->llIlllI.IllIIII);if(IlIlI->lllII.
Status!=(0x170f+2552-0x2107)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3a\x20\x75\x73\x62\x5f\x73\x65\x74\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IlIlI->lllII.Status);}if(lllIII->cur_altsetting){int IIIIIl;int pipe;for(IIIIIl
=(0x1ec9+1427-0x245c);IIIIIl<lllIII->cur_altsetting->desc.bNumEndpoints;IIIIIl++
){if(lllIII->cur_altsetting->endpoint[IIIIIl].desc.bEndpointAddress&
(0x4e7+5837-0x1b34)){pipe=usb_rcvisocpipe(lIlll->lIlII->lIIlI,lllIII->
cur_altsetting->endpoint[IIIIIl].desc.bEndpointAddress&(0xd65+5317-0x221b));}
else{pipe=usb_sndisocpipe(lIlll->lIlII->lIIlI,lllIII->cur_altsetting->endpoint[
IIIIIl].desc.bEndpointAddress&(0x6e4+2528-0x10b5));}IlIlllll(lIlll->lIlII,pipe,
(0x5ca+437-0x77f));}}}while((0x1858+1140-0x1ccc));if(!lIlll->lIlII->llIllII)
{
IlIIIIll(lIlll->lIlII);}usb_unlock_device(lIlll->lIlII->lIIlI);IIlIll(lIlll,
(0x2d+8907-0x22f8));}void lllIlIlII(struct lIlIl*lIlll,int status,gfp_t lIIIl){
IIlIl IlIlI=(IIlIl)(lIlll+(0x6e8+7352-0x239f));IlIlI->lllII.Status=status;}void 
IlIlIlIll(struct lIlIl*lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x7a6+4430-0x18f3));enum usb_device_state state;usb_lock_device(lIlll->lIlII->
lIIlI);state=lIlll->lIlII->lIIlI->state;usb_unlock_device(lIlll->lIlII->lIIlI);
IlIlI->lllII.Status=(0x149a+1098-0x18e4);IlIlI->IIIlllll.IIllIIlI=
(0x3af+4052-0x1383);if(state!=USB_STATE_SUSPENDED&&state!=USB_STATE_NOTATTACHED)
{IlIlI->IIIlllll.IIllIIlI|=lIlIIllIl;if(state==USB_STATE_CONFIGURED){IlIlI->
IIIlllll.IIllIIlI|=IlIIlIIll;}}IIlIll(lIlll,(0x82+6329-0x193b));}void lIIIlIIlI(
struct lIlIl*lIlll,int status,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x7ef+4417-0x192f));IlIlI->IIIlllll.IIllIIlI=(0xc54+3056-0x1844);IlIlI->lllII.
Status=status;}void IlllIIllI(struct lIlIl*lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl
)(lIlll+(0x7da+4914-0x1b0b));IlIlI->lllII.Status=-(0x4a9+4854-0x179e);if(lIlll->
lIlII->llIllII)
{IIlllIIl(lIlll->lIlII);}if(usb_lock_device_for_reset(lIlll->lIlII->lIIlI,NULL)
>=(0x1ef1+1476-0x24b5)){
IlIlI->lllII.Status=usb_reset_device(lIlll->lIlII->lIIlI);usb_unlock_device(
lIlll->lIlII->lIIlI);}if(IlIlI->lllII.Status!=(0x1233+3737-0x20cc)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x72\x65\x73\x65\x74\x70\x6f\x72\x74\x3a\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IlIlI->lllII.Status);}IIlIll(lIlll,IlIlI->lllII.Status);}void llIlIllll(struct 
lIlIl*lIlll,int status,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x17bf+1627-0x1e19));IlIlI->lllII.Status=status;}void lIIIIlIII(struct lIlIl*
lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+(0xff3+200-0x10ba));IlIlI->lllII.
Status=(0x3aa+2734-0xe58);
lIIIlIlIl(lIlll->lIlII,lIlll->lllIl,lIlll);lIlll->IlIIIIl=(0xb27+6102-0x22fc);
IIlIll(lIlll,(0xdd0+4758-0x2066));}void IIIIlllIl(struct lIlIl*lIlll,gfp_t lIIIl
){IIlIl IlIlI=(IIlIl)(lIlll+(0x121a+2199-0x1ab0));int endpoint;endpoint=IlIlI->
lIlIllII.Endpoint;endpoint|=(IlIlI->lIlIllII.Flags&IIIllI)?(0x9e4+4334-0x1a52):
(0xb6d+1853-0x12aa);IlIlI->lllII.Status=(0x21e4+355-0x2347);

lIllIIlll(lIlll->lIlII,endpoint,lIlll);IIlIll(lIlll,(0x7b7+63-0x7f6));}void 
IIIIIIIII(struct lIlIl*lIlll,int status,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x196f+499-0x1b61));IlIlI->lllII.Status=status;}void lllIlIIlI(struct lIlIl*
lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+(0x4a+2193-0x8da));int IIIll=
(0x5dd+3309-0x12ca);struct usb_ctrlrequest*IlIIlII=NULL;do{struct urb*IlllI;int 
pipe;IlllI=IIIlllIl((0x860+6234-0x20ba),lIIIl);if(unlikely(!IlllI)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-ENOMEM;break;}lIlll->lIIIll.IlllI=IlllI;IlIIlII=IllIIlI(sizeof(*IlIIlII
),lIIIl);if(!IlIIlII){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-ENOMEM;break;}IlIIlII->bRequestType=IlIlI->IIllIl.llIIIII;IlIIlII->
bRequest=IlIlI->IIllIl.lIlllIIIl;IlIIlII->wValue=cpu_to_le16(IlIlI->IIllIl.
llIlIIII);IlIIlII->wIndex=cpu_to_le16(IlIlI->IIllIl.IlllIllIl);IlIIlII->wLength=
cpu_to_le16(IlIlI->IIllIl.IIllI);pipe=(IlIlI->IIllIl.Flags&IIIllI)?
usb_rcvctrlpipe(lIlll->lIlII->lIIlI,IlIlI->IIllIl.Endpoint):usb_sndctrlpipe(
lIlll->lIlII->lIIlI,IlIlI->IIllIl.Endpoint);usb_fill_control_urb(IlllI,lIlll->
lIlII->lIIlI,pipe,(unsigned char*)IlIIlII,lIlll->lIIIll.lllll,IlIlI->IIllIl.
IIllI,lIIllIIlI,lIlll);if(atomic_cmpxchg(&lIlll->state,llIlIll,IllIIll)!=llIlIll
){IIIll=-ECONNRESET;break;}IIIll=usb_submit_urb(IlllI,lIIIl);if(unlikely(IIIll<
(0x1c60+1786-0x235a))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IIIll);}}while((0x917+4908-0x1c43));if(unlikely(IIIll<(0x1fc+4674-0x143e))){
IlIlllIlI(lIlll,IIIll,lIIIl);IIlIll(lIlll,IIIll);}}void IlIlllIlI(struct lIlIl*
lIlll,int status,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+(0x195f+3263-0x261d));
IlIlI->IIllIl.IIllI=(0x1356+27-0x1371);IlIlI->lllII.IlIll=sizeof(IlIlI->IIllIl);
IlIlI->lllII.Status=status;}void IllIlIIIl(struct lIlIl*lIlll,gfp_t lIIIl){
switch(lIlll->lIllll){case IIlIlI:lIllIllll(lIlll,lIIIl);return;case llIIlIl:
IlIIIIllI(lIlll,lIIIl);return;
#if KERNEL_GT_EQ((0x16d4+1494-0x1ca8),(0x12c8+4115-0x22d5),(0x8d5+3591-0x16bd))
case lllIIII:IlIllIllI(lIlll,lIIIl);return;
#endif
default:IlIlllI(lIlll,-EINVAL,lIIIl);IIlIll(lIlll,-EINVAL);return;}}void 
lIllIllll(struct lIlIl*lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x400+1148-0x87b));int IIIll=(0xcf+7736-0x1f07);do{struct urb*IlllI;int pipe=(
IlIlI->llIll.Flags&IIIllI)?usb_rcvbulkpipe(lIlll->lIlII->lIIlI,IlIlI->llIll.
Endpoint):usb_sndbulkpipe(lIlll->lIlII->lIIlI,IlIlI->llIll.Endpoint);IlllI=
IIIlllIl((0x1b67+1969-0x2318),lIIIl);if(unlikely(!IlllI)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-ENOMEM;break;}lIlll->lIIIll.IlllI=IlllI;usb_fill_bulk_urb(IlllI,lIlll->
lIlII->lIIlI,pipe,lIlll->lIIIll.lllll,IlIlI->llIll.IIllI,lIIIIlIl,lIlll);if(
IlIlI->llIll.Flags&IIIllI){if((IlIlI->llIll.Flags&lIIIIlI)==(0x51f+315-0x65a)){
IlllI->transfer_flags|=URB_SHORT_NOT_OK;}}if(unlikely(atomic_cmpxchg(&lIlll->
state,llIlIll,IllIIll)!=llIlIll)){IIIll=-ECONNRESET;break;}IIIll=usb_submit_urb(
IlllI,lIIIl);if(unlikely(IIIll<(0x1e9a+306-0x1fcc))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x6f\x6c\x69\x64\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IIIll);}}while((0x76b+848-0xabb));if(unlikely(IIIll<(0x765+3578-0x155f))){
IlIlllI(lIlll,IIIll,lIIIl);IIlIll(lIlll,IIIll);}}
#if KERNEL_GT_EQ((0x527+5939-0x1c58),(0x1103+2948-0x1c81),(0xf55+4526-0x20e4))
void IlIllIllI(struct lIlIl*lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x2b2+4282-0x136b));int IIIll=(0x1424+3549-0x2201);do{struct urb*IlllI;int pipe
=(IlIlI->llIll.Flags&IIIllI)?usb_rcvbulkpipe(lIlll->lIlII->lIIlI,IlIlI->llIll.
Endpoint):usb_sndbulkpipe(lIlll->lIlII->lIIlI,IlIlI->llIll.Endpoint);IlllI=
IIIlllIl((0xac5+4010-0x1a6f),lIIIl);if(unlikely(!IlllI)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-ENOMEM;break;}lIlll->lIIllII.IlllI=IlllI;usb_fill_bulk_urb(IlllI,lIlll
->lIlII->lIIlI,pipe,NULL,IlIlI->llIll.IIllI,lIIIIlIl,lIlll);IlllI->sg=lIlll->
lIIllII.sg.IlIlIIl;IlllI->num_sgs=lIlll->lIIllII.sg.num_sgs;if(IlIlI->llIll.
Flags&IIIllI){if((IlIlI->llIll.Flags&lIIIIlI)==(0x162+7245-0x1daf)){IlllI->
transfer_flags|=URB_SHORT_NOT_OK;}}if(unlikely(atomic_cmpxchg(&lIlll->state,
llIlIll,IllIIll)!=llIlIll)){IIIll=-ECONNRESET;break;}IIIll=usb_submit_urb(IlllI,
lIIIl);if(unlikely(IIIll<(0x437+7873-0x22f8))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x6f\x6c\x69\x64\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IIIll);}}while((0x975+2366-0x12b3));if(unlikely(IIIll<(0x97a+4342-0x1a70))){
IlIlllI(lIlll,IIIll,lIIIl);IIlIll(lIlll,IIIll);}}
#endif
void IlIIIIllI(struct lIlIl*lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x9fa+463-0xbc8));int IIIll=(0x155+2686-0xbd3);do{int pipe;pipe=(IlIlI->llIll.
Flags&IIIllI)?usb_rcvbulkpipe(lIlll->lIlII->lIIlI,IlIlI->llIll.Endpoint):
usb_sndbulkpipe(lIlll->lIlII->lIIlI,IlIlI->llIll.Endpoint);lIlll->lIllII.llllIlI
=IlIlIlIlI(pipe,(0xfc2+5186-0x2404),!!(IlIlI->llIll.Flags&lIIIIlI),lIlll->lIlII
->IlIllIl,lIlll->lIlII->lIIlI,lIlll->lIllII.llIllI,lIlll,lIlIIIllI,lIIIl);if(
unlikely(lIlll->lIllII.llllIlI==NULL)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64\x3a\x20\x75\x73\x62\x64\x5f\x75\x63\x5f\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-ENOMEM;break;}if(unlikely(atomic_cmpxchg(&lIlll->state,llIlIll,IllIIll)
!=llIlIll)){IIIll=-ECONNRESET;break;}IIIll=lIIllIIII(lIlll->lIllII.llllIlI);if(
unlikely(IIIll<(0xee8+4656-0x2118))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64\x3a\x20\x75\x73\x62\x64\x5f\x75\x63\x5f\x73\x75\x62\x6d\x69\x74\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64\x20\x66\x6f\x72\x20\x55\x6e\x69\x71\x75\x65\x49\x64\x3d\x30\x78\x25\x2e\x38\x58\x25\x2e\x38\x58" "\n"
,IIIll,(IIIIl)(IlIlI->lllII.IIllll>>(0x3cd+6749-0x1e0a)),(IIIIl)(IlIlI->lllII.
IIllll));}}while((0x14aa+1987-0x1c6d));if(unlikely(IIIll<(0x177c+944-0x1b2c))){
IlIlllI(lIlll,IIIll,lIIIl);IIlIll(lIlll,IIIll);}}void IlIlllI(struct lIlIl*lIlll
,int status,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+(0x11aa+2578-0x1bbb));IlIlI->
llIll.IIllI=(0x917+2323-0x122a);IlIlI->lllII.IlIll=sizeof(IlIlI->llIll)+IlIlI->
llIll.IIllI;IlIlI->lllII.Status=status;}void lIllllIlI(struct lIlIl*lIlll,gfp_t 
lIIIl){switch(lIlll->lIllll){case IIlIlI:lIllIlIlI(lIlll,lIIIl);return;
#if KERNEL_GT_EQ((0x1292+2031-0x1a7f),(0x2e5+9124-0x2683),(0x39c+330-0x4c7))
case lllIIII:IIIlIllIl(lIlll,lIIIl);return;
#endif
default:IlIIllIl(lIlll,-EINVAL,lIIIl);IIlIll(lIlll,-EINVAL);return;}}void 
lIllIlIlI(struct lIlIl*lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x1632+4018-0x25e3));int IIIll=(0x1fd0+1186-0x2472);do{int pipe;struct urb*
IlllI;struct usb_host_endpoint*ep;IlllI=IIIlllIl((0x6ea+5379-0x1bed),lIIIl);if(
unlikely(!IlllI)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-ENOMEM;break;}lIlll->lIIIll.IlllI=IlllI;pipe=(IlIlI->llIIlI.Flags&
IIIllI)?usb_rcvintpipe(lIlll->lIlII->lIIlI,IlIlI->llIIlI.Endpoint):
usb_sndintpipe(lIlll->lIlII->lIIlI,IlIlI->llIIlI.Endpoint);Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x20\x69\x73\x20\x25\x64" "\n"
,IlIlI->llIIlI.Interval);usb_fill_int_urb(IlllI,lIlll->lIlII->lIIlI,pipe,lIlll->
lIIIll.lllll,IlIlI->llIIlI.IIllI,llllIllI,lIlll,(0x816+6438-0x213b));if(likely(
IlIlI->llIIlI.Interval)){IlllI->interval=IlIlI->llIIlI.Interval;}else{
#if KERNEL_GT_EQ((0xaa9+5107-0x1e9a),(0x3cd+8121-0x2380),(0x282+6681-0x1c91))
ep=(IlIlI->llIIlI.Flags&IIIllI)?lIlll->lIlII->lIIlI->ep_in[IlIlI->llIIlI.
Endpoint]:lIlll->lIlII->lIIlI->ep_out[IlIlI->llIIlI.Endpoint];Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x64\x69\x72\x65\x63\x74\x69\x6f\x6e\x3d\x25\x73\x20\x65\x70\x3d\x30\x78\x25\x70\x20\x65\x70\x5f\x69\x6e\x5b\x25\x64\x5d\x3d\x30\x78\x25\x70\x20\x65\x70\x5f\x6f\x75\x74\x5b\x25\x64\x5d\x3d\x30\x78\x25\x70" "\n"
,(IlIlI->llIIlI.Flags&IIIllI)?"\x69\x6e":"\x6f\x75\x74",ep,IlIlI->llIIlI.
Endpoint,lIlll->lIlII->lIIlI->ep_in[IlIlI->llIIlI.Endpoint],IlIlI->llIIlI.
Endpoint,lIlll->lIlII->lIIlI->ep_out[IlIlI->llIIlI.Endpoint]);if(ep){if(lIlll->
lIlII->lIIlI->speed==USB_SPEED_HIGH){IlllI->interval=(0x1c+3685-0xe80)<<(ep->
desc.bInterval-(0x1531+2749-0x1fed));}else{IlllI->interval=ep->desc.bInterval;}}
else{IlllI->interval=(0x3f6+1186-0x897);}
#else
IlllI->interval=(0xebc+3517-0x1c78);
#endif
}if(IlIlI->llIIlI.Flags&IIIllI){if((IlIlI->llIIlI.Flags&lIIIIlI)==
(0x15f6+2569-0x1fff)){IlllI->transfer_flags|=URB_SHORT_NOT_OK;}}if(
atomic_cmpxchg(&lIlll->state,llIlIll,IllIIll)!=llIlIll){IIIll=-ECONNRESET;break;
}while((0x1127+1073-0x1557)){IIIll=usb_submit_urb(IlllI,lIIIl);if((IIIll==-
ENOMEM)&&(lIlll->lIlII->lIIlI->speed==USB_SPEED_HIGH)&&(IlllI->interval<=
(0x471+2424-0xd69))){
IlllI->interval<<=(0xe4f+1384-0x13b6);}else{break;}yield();}if(unlikely(IIIll<
(0x7d+1284-0x581))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64\x20\x66\x6f\x72\x20\x55\x6e\x69\x71\x75\x65\x49\x64\x3d\x30\x78\x25\x2e\x38\x58\x25\x2e\x38\x58" "\n"
,IIIll,(IIIIl)(IlIlI->lllII.IIllll>>(0x1d7b+1368-0x22b3)),(IIIIl)(IlIlI->lllII.
IIllll));}}while((0x132b+1789-0x1a28));if(unlikely(IIIll<(0x598+6705-0x1fc9))){
IlIIllIl(lIlll,IIIll,lIIIl);IIlIll(lIlll,IIIll);}}
#if KERNEL_GT_EQ((0x1eb4+986-0x228c),(0x9cc+1931-0x1151),(0x225+6169-0x1a1f))
void IIIlIllIl(struct lIlIl*lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x4af+6823-0x1f55));int IIIll=(0x63f+3044-0x1223);do{int pipe;struct urb*IlllI;
struct usb_host_endpoint*ep;IlllI=IIIlllIl((0x1611+2911-0x2170),lIIIl);if(
unlikely(!IlllI)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x73\x67\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-ENOMEM;break;}lIlll->lIIllII.IlllI=IlllI;pipe=(IlIlI->llIIlI.Flags&
IIIllI)?usb_rcvintpipe(lIlll->lIlII->lIIlI,IlIlI->llIIlI.Endpoint):
usb_sndintpipe(lIlll->lIlII->lIIlI,IlIlI->llIIlI.Endpoint);Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x20\x69\x73\x20\x25\x64" "\n"
,IlIlI->llIIlI.Interval);usb_fill_int_urb(IlllI,lIlll->lIlII->lIIlI,pipe,NULL,
IlIlI->llIIlI.IIllI,llllIllI,lIlll,(0x8a1+5799-0x1f47));IlllI->sg=lIlll->lIIllII
.sg.IlIlIIl;IlllI->num_sgs=lIlll->lIIllII.sg.num_sgs;if(likely(IlIlI->llIIlI.
Interval)){IlllI->interval=IlIlI->llIIlI.Interval;}else{
#if KERNEL_GT_EQ((0x249+5143-0x165e),(0xda2+2765-0x1869),(0xbf1+3851-0x1af2))
ep=(IlIlI->llIIlI.Flags&IIIllI)?lIlll->lIlII->lIIlI->ep_in[IlIlI->llIIlI.
Endpoint]:lIlll->lIlII->lIIlI->ep_out[IlIlI->llIIlI.Endpoint];Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x64\x69\x72\x65\x63\x74\x69\x6f\x6e\x3d\x25\x73\x20\x65\x70\x3d\x30\x78\x25\x70\x20\x65\x70\x5f\x69\x6e\x5b\x25\x64\x5d\x3d\x30\x78\x25\x70\x20\x65\x70\x5f\x6f\x75\x74\x5b\x25\x64\x5d\x3d\x30\x78\x25\x70" "\n"
,(IlIlI->llIIlI.Flags&IIIllI)?"\x69\x6e":"\x6f\x75\x74",ep,IlIlI->llIIlI.
Endpoint,lIlll->lIlII->lIIlI->ep_in[IlIlI->llIIlI.Endpoint],IlIlI->llIIlI.
Endpoint,lIlll->lIlII->lIIlI->ep_out[IlIlI->llIIlI.Endpoint]);if(ep){if(lIlll->
lIlII->lIIlI->speed==USB_SPEED_HIGH){IlllI->interval=(0x1fc+4333-0x12e8)<<(ep->
desc.bInterval-(0xb06+595-0xd58));}else{IlllI->interval=ep->desc.bInterval;}}
else{IlllI->interval=(0x121b+3203-0x1e9d);}
#else
IlllI->interval=(0x45f+23-0x475);
#endif
}if(IlIlI->llIIlI.Flags&IIIllI){if((IlIlI->llIIlI.Flags&lIIIIlI)==
(0x377+8087-0x230e)){IlllI->transfer_flags|=URB_SHORT_NOT_OK;}}if(atomic_cmpxchg
(&lIlll->state,llIlIll,IllIIll)!=llIlIll){IIIll=-ECONNRESET;break;}while(
(0x131f+2528-0x1cfe)){IIIll=usb_submit_urb(IlllI,lIIIl);if((IIIll==-ENOMEM)&&(
lIlll->lIlII->lIIlI->speed==USB_SPEED_HIGH)&&(IlllI->interval<=
(0x189a+3667-0x266d))){
IlllI->interval<<=(0x134c+702-0x1609);}else{break;}yield();}if(unlikely(IIIll<
(0x228+6757-0x1c8d))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64\x20\x66\x6f\x72\x20\x55\x6e\x69\x71\x75\x65\x49\x64\x3d\x30\x78\x25\x2e\x38\x58\x25\x2e\x38\x58" "\n"
,IIIll,(IIIIl)(IlIlI->lllII.IIllll>>(0x15cb+3359-0x22ca)),(IIIIl)(IlIlI->lllII.
IIllll));}}while((0x3f8+4167-0x143f));if(unlikely(IIIll<(0xfb4+40-0xfdc))){
IlIIllIl(lIlll,IIIll,lIIIl);IIlIll(lIlll,IIIll);}}
#endif
void IlIIllIl(struct lIlIl*lIlll,int status,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(
lIlll+(0x94b+7333-0x25ef));IlIlI->llIIlI.IIllI=(0x307+3764-0x11bb);IlIlI->lllII.
IlIll=sizeof(IlIlI->llIIlI)+IlIlI->llIIlI.IIllI;IlIlI->lllII.Status=status;}void
 IlIllIlll(struct lIlIl*lIlll,gfp_t lIIIl){switch(lIlll->lIllll){case IIlIlI:
lllIllIII(lIlll,lIIIl);return;case llIIlIl:llllIIIlI(lIlll,lIIIl);return;default
:lIlllIlI(lIlll,-EINVAL,lIIIl);IIlIll(lIlll,-EINVAL);return;}}void llllIIIlI(
struct lIlIl*lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+(0x6fc+5177-0x1b34));
int pipe,IIIll=(0x1579+2237-0x1e36);do{int i,IIIIIl,IIllII,IlIIIlI,llllIlII,
IlIllllI;int IIIIllll;struct urb*IlllI;pipe=(IlIlI->llIIl.Flags&IIIllI)?
usb_rcvisocpipe(lIlll->lIlII->lIIlI,IlIlI->llIIl.Endpoint):usb_sndisocpipe(lIlll
->lIlII->lIIlI,IlIlI->llIIl.Endpoint);IlIllllI=IIIllllII(lIlll->lIlII,pipe);
lIlll->lIllII.llllIlI=IlIlIlIlI(pipe,IlIlI->llIIl.Interval,!!(IlIlI->llIIl.Flags
&lIIIIlI),lIlll->lIlII->IlIllIl,lIlll->lIlII->lIIlI,lIlll->lIllII.llIllI,lIlll,
IIIIIlIII,lIIIl);if(unlikely(lIlll->lIllII.llllIlI==NULL)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64\x3a\x20\x75\x73\x62\x64\x5f\x75\x63\x5f\x61\x6c\x6c\x6f\x63\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-ENOMEM;break;}lIlll->lIllII.llllIlI->IIIlII[(0x347+2316-0xc53)]->
start_frame=IlIlI->llIIl.llIIIIIl;if(!(IlIlI->llIIl.Flags&lIlIIllII)){lIlll->
lIllII.llllIlI->IIIlII[(0xd98+5307-0x2253)]->transfer_flags&=~URB_ISO_ASAP;}


IlllI=lIlll->lIllII.llllIlI->IIIlII[(0x10ca+415-0x1269)];IIIIllll=
(0x1b2b+2787-0x260e);for(i=(0x4d6+4722-0x1748),IIIIIl=(0x2bb+7401-0x1fa4),IIllII
=(0x1b63+245-0x1c58);i<IlIlI->llIIl.llIIIIl;i++,IIllII++){if(IIllII>=IlllI->
number_of_packets){if(++IIIIIl>=lIlll->lIllII.llllIlI->IlIII){break;}IIIIllll=
(0x1d28+2008-0x2500);IlllI=lIlll->lIllII.llllIlI->IIIlII[IIIIIl];IIllII=
(0xee4+281-0xffd);}IlllI->iso_frame_desc[IIllII].offset=IIIIllll;IlllI->
iso_frame_desc[IIllII].length=IlIlI->llIIl.llIIIlI[i].Length;IIIIllll+=IlllI->
iso_frame_desc[IIllII].length;
}


IlIIIlI=IlllIlII(lIlll->lIlII,pipe);llllIlII=usb_get_current_frame_number(lIlll
->lIlII->lIIlI);if(!(lIlll->lIllII.llllIlI->IIIlII[(0x14bf+1265-0x19b0)]->
transfer_flags&URB_ISO_ASAP)&&(IlIIIlI==(0x1236+371-0x13a9))){IlIIIlI=(llllIlII+
(0x357+7514-0x20af))-lIlll->lIllII.llllIlI->IIIlII[(0xd66+4686-0x1fb4)]->
start_frame;IlIlllll(lIlll->lIlII,pipe,IlIIIlI);}if(IlIllllI==
(0x10a4+3592-0x1eab)){if(lIlll->lIllII.llllIlI->IIIlII[(0x1eb3+262-0x1fb9)]->
transfer_flags&URB_ISO_ASAP){lIlll->lIllII.llllIlI->IIIlII[(0x3aa+7072-0x1f4a)]
->transfer_flags&=~URB_ISO_ASAP;lIlll->lIllII.llllIlI->IIIlII[
(0xd07+3000-0x18bf)]->start_frame=llllIlII+(0x224+9041-0x2574)-IlIIIlI;}}if(!(
lIlll->lIllII.llllIlI->IIIlII[(0x5d4+6597-0x1f99)]->transfer_flags&URB_ISO_ASAP)
){lIlll->lIllII.llllIlI->IIIlII[(0x824+4269-0x18d1)]->start_frame+=IlIIIlI;if(
lIlll->lIllII.llllIlI->IIIlII[(0x94a+6363-0x2225)]->start_frame<llllIlII+
(0xd7a+360-0xee1)){IlIlI->lllII.Status=-EXDEV;IlIlI->lllII.IlIll=IIIllllI(IlIlI)
;IlIlI->llIIl.IIllI=(0xbe1+1558-0x11f7);IlIlI->llIIl.IIllllIl=IlIlI->llIIl.
llIIIIl;for(i=(0x133a+1381-0x189f);i<IlIlI->llIIl.llIIIIl;i++){IlIlI->llIIl.
llIIIlI[i].Status=-EINVAL;IlIlI->llIIl.llIIIlI[i].Length=(0x10aa+2166-0x1920);}
IIIll=(0x1969+446-0x1b27);IIlIll(lIlll,-EXDEV);break;}}if(atomic_cmpxchg(&lIlll
->state,llIlIll,IllIIll)!=llIlIll){IIIll=-ECONNRESET;break;}IIIll=lIIllIIII(
lIlll->lIllII.llllIlI);if(unlikely(IIIll<(0xbd1+4369-0x1ce2))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64\x3a\x20\x75\x73\x62\x64\x5f\x75\x63\x5f\x73\x75\x62\x6d\x69\x74\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64\x20\x66\x6f\x72\x20\x55\x6e\x69\x71\x75\x65\x49\x64\x3d\x30\x78\x25\x2e\x38\x58\x25\x2e\x38\x58" "\n"
,IIIll,(IIIIl)(IlIlI->lllII.IIllll>>(0x12c5+4322-0x2387)),(IIIIl)(IlIlI->lllII.
IIllll));}}while((0x248+4185-0x12a1));if(unlikely(IIIll<(0x3c+2813-0xb39))){
IlIIIIlI(lIlll->lIlII,pipe);lIlllIlI(lIlll,IIIll,lIIIl);IIlIll(lIlll,IIIll);}}
void lllIllIII(struct lIlIl*lIlll,gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+
(0x5f0+8173-0x25dc));int pipe,IIIll=(0x2+5223-0x1469);int IIIIllll;do{int i,
IlIIIlI,llllIlII,IlIllllI;struct urb*IlllI;struct usb_host_endpoint*ep;pipe=(
IlIlI->llIIl.Flags&IIIllI)?usb_rcvisocpipe(lIlll->lIlII->lIIlI,IlIlI->llIIl.
Endpoint):usb_sndisocpipe(lIlll->lIlII->lIIlI,IlIlI->llIIl.Endpoint);IlIllllI=
IIIllllII(lIlll->lIlII,pipe);IlllI=IIIlllIl(IlIlI->llIIl.llIIIIl,lIIIl);if(
unlikely(!IlllI)){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x73\x6f\x6c\x69\x64\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IIIll=-ENOMEM;break;}lIlll->lIIIll.IlllI=IlllI;IlllI->dev=lIlll->lIlII->lIIlI;
IlllI->pipe=pipe;IlllI->transfer_flags=(IlIlI->llIIl.Flags&lIlIIllII)?
URB_ISO_ASAP:(0xb8f+1913-0x1308);IlllI->transfer_buffer_length=IlIlI->llIIl.
IIllI;IlllI->start_frame=IlIlI->llIIl.llIIIIIl;IlllI->number_of_packets=IlIlI->
llIIl.llIIIIl;IlllI->context=lIlll;IlllI->complete=IIIllIllI;IlllI->
transfer_buffer=lIlll->lIIIll.lllll;if(likely(IlIlI->llIIl.Interval)){IlllI->
interval=IlIlI->llIIl.Interval;}else{
#if KERNEL_GT_EQ((0xdac+168-0xe52),(0x499+1425-0xa24),(0x152a+2460-0x1ebc))

ep=(IlIlI->llIIl.Flags&IIIllI)?lIlll->lIlII->lIIlI->ep_in[IlIlI->llIIl.Endpoint]
:lIlll->lIlII->lIIlI->ep_out[IlIlI->llIIl.Endpoint];if(ep){if(lIlll->lIlII->
lIIlI->speed==USB_SPEED_HIGH){IlllI->interval=(0xca+7464-0x1df1)<<(ep->desc.
bInterval-(0x9d4+413-0xb70));}else{IlllI->interval=ep->desc.bInterval;}}else{
IlllI->interval=(0x6ba+3774-0x1577);}
#else
IlllI->interval=(0x59b+6529-0x1f1b);
#endif
}Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x73\x6f\x6c\x69\x64\x3a\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x20\x69\x73\x20\x25\x64" "\n"
,IlllI->interval);for(IIIIllll=(0x1043+2512-0x1a13),i=(0x18f3+160-0x1993);i<
IlIlI->llIIl.llIIIIl;i++){IlllI->iso_frame_desc[i].offset=IIIIllll;IlllI->
iso_frame_desc[i].length=IlIlI->llIIl.llIIIlI[i].Length;IIIIllll+=IlllI->
iso_frame_desc[i].length;}


IlIIIlI=IlllIlII(lIlll->lIlII,pipe);llllIlII=usb_get_current_frame_number(lIlll
->lIlII->lIIlI);if(!(IlllI->transfer_flags&URB_ISO_ASAP)&&(IlIIIlI==
(0x8a0+4071-0x1887))){IlIIIlI=(llllIlII+(0x437+8014-0x2383))-IlllI->start_frame;
IlIlllll(lIlll->lIlII,pipe,IlIIIlI);}if(IlIllllI==(0x5f6+906-0x97f)){if(IlllI->
transfer_flags&URB_ISO_ASAP){IlllI->transfer_flags&=~URB_ISO_ASAP;IlllI->
start_frame=llllIlII+(0x1f9f+23-0x1fb5)-IlIIIlI;}}if(!(IlllI->transfer_flags&
URB_ISO_ASAP)){IlllI->start_frame+=IlIIIlI;if(IlllI->start_frame<llllIlII+
(0x9b8+7257-0x2610)){IlIlI->lllII.Status=-EXDEV;IlIlI->lllII.IlIll=IIIllllI(
IlIlI);IlIlI->llIIl.IIllI=(0x1e76+1076-0x22aa);IlIlI->llIIl.IIllllIl=IlIlI->
llIIl.llIIIIl;for(i=(0xf62+2042-0x175c);i<IlIlI->llIIl.llIIIIl;i++){IlIlI->llIIl
.llIIIlI[i].Status=-EINVAL;IlIlI->llIIl.llIIIlI[i].Length=(0x345+4642-0x1567);}
IIIll=(0x47b+5951-0x1bba);IIlIll(lIlll,-EXDEV);break;}}Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x73\x6f\x6c\x69\x64\x3a\x20\x66\x6c\x61\x67\x73\x3d\x25\x64\x20\x73\x74\x61\x72\x74\x66\x72\x61\x6d\x65\x3d\x25\x64\x20\x63\x75\x72\x66\x72\x61\x6d\x65\x3d\x25\x64\x20\x64\x65\x6c\x74\x61\x3d\x25\x64" "\n"
,IlllI->transfer_flags,IlllI->start_frame,usb_get_current_frame_number(lIlll->
lIlII->lIIlI),IlllIlII(lIlll->lIlII,pipe));if(atomic_cmpxchg(&lIlll->state,
llIlIll,IllIIll)!=llIlIll){IIIll=-ECONNRESET;break;}IIIll=usb_submit_urb(IlllI,
lIIIl);if(unlikely(IIIll<(0x273+6843-0x1d2e))){Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x73\x6f\x6c\x69\x64\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64\x20\x66\x6f\x72\x20\x55\x6e\x69\x71\x75\x65\x49\x64\x3d\x30\x78\x25\x6c\x6c\x78" "\n"
,IIIll,(unsigned long long)IlIlI->lllII.IIllll);}}while((0x9c8+4278-0x1a7e));if(
unlikely(IIIll<(0xa2d+1180-0xec9))){IlIIIIlI(lIlll->lIlII,pipe);lIlllIlI(lIlll,
IIIll,lIIIl);IIlIll(lIlll,IIIll);}}void lIlllIlI(struct lIlIl*lIlll,int status,
gfp_t lIIIl){IIlIl IlIlI=(IIlIl)(lIlll+(0x1535+1132-0x19a0));IlIlI->llIIl.IIllI=
(0x140a+2941-0x1f87);IlIlI->lllII.IlIll=IIIllllI(IlIlI)+IlIlI->llIIl.IIllI;IlIlI
->lllII.Status=status;
}void IIIIIllll(struct urb*IlllI
#if KERNEL_LT((0x1237+4898-0x2557),(0xc36+2773-0x1705),(0x19c2+981-0x1d84))
,struct pt_regs*IIlIlII
#endif
){struct lIlIl*lIlll=IlllI->context;IIlIl IlIlI=(IIlIl)(lIlll+(0x26a+216-0x341))
;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x67\x65\x74\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72" "\n"
);
IlIlI->IIlllI.IIllI=(IlllI->actual_length<(0x4e0+6324-0x1d94))?
(0x8d6+6351-0x21a5):IlllI->actual_length;IlIlI->IIlllI.IlIIll.IlIll=sizeof(IlIlI
->IIlllI)+IlIlI->IIlllI.IIllI;IlIlI->IIlllI.IlIIll.Status=IlllI->status;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x67\x65\x74\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,IlllI->status);llllIII("\x43\x4f\x4d\x50\x4c\x45\x54\x45",IlIlI);
IIlIll(lIlll,IlllI->status);}void lIIllIIlI(struct urb*IlllI
#if KERNEL_LT((0x1068+1369-0x15bf),(0x1f5+3256-0xea7),(0xf27+4711-0x217b))
,struct pt_regs*IIlIlII
#endif
){struct lIlIl*lIlll=IlllI->context;IIlIl IlIlI=(IIlIl)(lIlll+
(0x2019+133-0x209d));Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x74\x72\x61\x6e\x73\x66\x65\x72" "\n"
);
IlIlI->IIllIl.IIllI=(IlllI->actual_length<(0x11b1+5366-0x26a7))?
(0xc88+2931-0x17fb):IlllI->actual_length;IlIlI->lllII.IlIll=sizeof(IlIlI->IIllIl
);if(usb_pipein(IlllI->pipe)){IlIlI->lllII.IlIll+=IlIlI->IIllIl.IIllI;}IlIlI->
IIllIl.IlIIll.Status=IlllI->status;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,IlllI->status);llllIII("\x43\x4f\x4d\x50\x4c\x45\x54\x45",IlIlI);
IIlIll(lIlll,IlllI->status);}void lIIIIlIl(struct urb*IlllI
#if KERNEL_LT((0x462+4354-0x1562),(0x1a9d+1815-0x21ae),(0xeb0+3938-0x1dff))
,struct pt_regs*IIlIlII
#endif
){struct lIlIl*lIlll=IlllI->context;IIlIl IlIlI=(IIlIl)(lIlll+(0x6+9530-0x253f))
;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72" "\n"
);IlIlI->llIll.IIllI=IlllI->actual_length;IlIlI->lllII.IlIll=sizeof(IlIlI->llIll
);if(usb_pipein(IlllI->pipe)){IlIlI->lllII.IlIll+=IlIlI->llIll.IIllI;}IlIlI->
llIll.IlIIll.Status=IlllI->status;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,IlllI->status);llllIII("\x43\x4f\x4d\x50\x4c\x45\x54\x45",IlIlI);
IIlIll(lIlll,IlllI->status);}void llllIllI(struct urb*IlllI
#if KERNEL_LT((0xd6f+6219-0x25b8),(0xbc+3620-0xeda),(0x16e4+1962-0x1e7b))
,struct pt_regs*IIlIlII
#endif
){struct lIlIl*lIlll=IlllI->context;IIlIl IlIlI=(IIlIl)(lIlll+
(0x532+6844-0x1fed));Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72" "\n"
);IlIlI->llIIlI.IIllI=IlllI->actual_length;IlIlI->lllII.IlIll=sizeof(IlIlI->
llIIlI);if(usb_pipein(IlllI->pipe)){IlIlI->lllII.IlIll+=IlIlI->llIIlI.IIllI;}
IlIlI->llIIlI.IlIIll.Status=IlllI->status;Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,IlllI->status);llllIII("\x43\x4f\x4d\x50\x4c\x45\x54\x45",IlIlI);
IIlIll(lIlll,IlllI->status);}void IIIllIllI(struct urb*IlllI
#if KERNEL_LT((0x1de6+542-0x2002),(0x2ca+1445-0x869),(0x742+2326-0x1045))
,struct pt_regs*IIlIlII
#endif
){int i;struct lIlIl*lIlll=IlllI->context;struct IlIIl*lIlII=lIlll->lIlII;IIlIl 
IlIlI=(IIlIl)(lIlll+(0x1594+1177-0x1a2c));Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x73\x6f\x6c\x69\x64\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,IlllI->status);IlIIIIlI(lIlII,IlllI->pipe);IlllI->start_frame-=IlllIlII(lIlII,
IlllI->pipe);
#if KERNEL_LT((0x2460+531-0x2671),(0xf8+5542-0x1698),(0x118f+2535-0x1b5e))


if(IlllI->status!=-ECONNRESET&&IlllI->status!=-ENOENT&&IlllI->status!=-ESHUTDOWN
){IlllI->status=(0x7d7+7970-0x26f9);}
#endif
IlIlI->llIIl.IlIIll.Status=IlllI->status;IlIlI->llIIl.IIllllIl=IlllI->
error_count;IlIlI->llIIl.llIIIIIl=IlllI->start_frame;if(usb_pipein(IlllI->pipe))
{IlIlI->llIIl.IIllI=IIlIIlIl(IlllI->iso_frame_desc,IlllI->number_of_packets,
IlllI->transfer_buffer,IlllI->transfer_buffer,(0xfa+7986-0x202b));}else{IlIlI->
llIIl.IIllI=IlIllIIll(IlllI->iso_frame_desc,IlllI->number_of_packets,
(0x2037+711-0x22fd));}for(i=(0x92+1970-0x844);i<IlIlI->llIIl.llIIIIl;i++){IlIlI
->llIIl.llIIIlI[i].Length=IlllI->iso_frame_desc[i].actual_length;IlIlI->llIIl.
llIIIlI[i].Status=IlllI->iso_frame_desc[i].status;}IlIlI->lllII.IlIll=IIIllllI(
IlIlI);if(usb_pipein(IlllI->pipe)){IlIlI->lllII.IlIll+=IlIlI->llIIl.IIllI;}
llllIII("\x43\x4f\x4d\x50\x4c\x45\x54\x45",IlIlI);
#if defined(_USBD_USE_EHCI_FIX_) && KERNEL_GT_EQ((0x48f+6136-0x1c85),\
(0x1644+2488-0x1ff6),(0x246b+278-0x2568)) && KERNEL_LT_EQ((0x1d0+6335-0x1a8d),\
(0x3c4+2368-0xcfe),(0xe43+6058-0x25d1))
if(lIlII->IlIllIl&&(IlllI->status==(0x13b6+3137-0x1ff7))&&(atomic_read(&IlllI->
kref.refcount)>(0x1099+920-0x1430))){usb_put_urb(IlllI);}
#endif

IIlIll(lIlll,IlllI->status);}void lIlIIIllI(struct llllll*llIlI){int i;struct 
lIlIl*lIlll=llIlI->context;IIlIl IlIlI=(IIlIl)(lIlll+(0xcd1+5655-0x22e7));Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64" "\n"
);IlIlI->llIll.IIllI=llIlI->llllllIll;IlIlI->lllII.IlIll=sizeof(IlIlI->llIll);if
(usb_pipein(llIlI->pipe)){IlIlI->llIll.IlIIll.IlIll+=IlIlI->llIll.IIllI;}IlIlI->
llIll.IlIIll.Status=llIlI->status;for(i=(0x457+6333-0x1d14);i<llIlI->IlIII;i++)
lIlll->lIllII.llIllI->IllIIl[i].actual_length=llIlI->IIIlII[i]->actual_length;
Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,llIlI->status);llllIII("\x43\x4f\x4d\x50\x4c\x45\x54\x45",IlIlI);
IIlIll(lIlll,llIlI->status);}void IIIIIlIII(struct llllll*llIlI){int i,IIIIIl,
IIllII;struct lIlIl*lIlll=llIlI->context;struct IlIIl*lIlII=lIlll->lIlII;IIlIl 
IlIlI=(IIlIl)(lIlll+(0xd3f+3065-0x1937));Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64" "\n"
);IlIIIIlI(lIlII,llIlI->pipe);llIlI->IIIlII[(0x8a7+1106-0xcf9)]->start_frame-=
IlllIlII(lIlII,llIlI->pipe);IlIlI->llIIl.IlIIll.Status=llIlI->status;IlIlI->
llIIl.llIIIIIl=llIlI->IIIlII[(0x1b74+2021-0x2359)]->start_frame;IlIlI->llIIl.
IIllllIl=(0xfd4+1479-0x159b);IlIlI->llIIl.IIllI=(0xb32+4503-0x1cc9);for(i=
(0xa29+6176-0x2249),IIllII=(0x10b4+885-0x1429);i<llIlI->IlIII;i++){struct urb*
IlllI=llIlI->IIIlII[i];if(usb_pipein(llIlI->pipe)){lIlll->lIllII.llIllI->IllIIl[
i].actual_length=IIlIIlIl(IlllI->iso_frame_desc,IlllI->number_of_packets,IlllI->
transfer_buffer,IlllI->transfer_buffer,(0x1320+4183-0x2376));}else{lIlll->lIllII
.llIllI->IllIIl[i].actual_length=IlIllIIll(IlllI->iso_frame_desc,IlllI->
number_of_packets,(0xe13+4640-0x2032));}IlIlI->llIIl.IIllI+=lIlll->lIllII.llIllI
->IllIIl[i].actual_length;IlIlI->llIIl.IIllllIl+=IlllI->error_count;for(IIIIIl=
(0x228+5847-0x18ff);IIIIIl<IlllI->number_of_packets;IIIIIl++){
IlIlI->llIIl.llIIIlI[IIllII].Length=IlllI->iso_frame_desc[IIIIIl].actual_length;
IlIlI->llIIl.llIIIlI[IIllII].Status=IlllI->iso_frame_desc[IIIIIl].status;IIllII
++;}}IlIlI->lllII.IlIll=IIIllllI(IlIlI);if(usb_pipein(llIlI->pipe)){IlIlI->lllII
.IlIll+=IlIlI->llIIl.IIllI;}Illll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,llIlI->status);llllIII("\x43\x4f\x4d\x50\x4c\x45\x54\x45",IlIlI);
IIlIll(lIlll,llIlI->status);}
void llIIIIII(struct IlIIl*lIlII,IlIIlI lllIl){struct IllllIII*IIIIIII;

list_for_each_entry(IIIIIII,&lIlII->lllIIlll,llIIII){if(IIIIIII->lllIl==lllIl){
list_del(&IIIIIII->llIIII);lIlIll(IIIIIII);return;}}}static inline void 
IllIIIIll(struct IlIIl*lIlII,IlIIlI lllIl,int IIlIIII){struct IllllIII*IIIIIII;
list_for_each_entry(IIIIIII,&lIlII->lllIIlll,llIIII){if(IIIIIII->lllIl==lllIl){
IIIIIII->lllIlllIl=IIlIIII;return;}}}struct lIlIl*Illlllll(struct IlIIl*lIlII,
IlIIlI lllIl){struct lIlIl*lIlll;list_for_each_entry(lIlll,&lIlII->llllIll,
llllIl){if(lIlll->lllIl==lllIl){return lIlll;}}return NULL;}struct lIlIl*
IIIIIIllI(struct lIlIl*lIlll,int IIlIIII){struct lIlIl*IllIII;struct list_head*
llIlllII;


if(unlikely(list_empty(&lIlll->llllIl))){return NULL;}IllIII=lIlll;
list_for_each_entry_continue(IllIII,&lIlll->lIlII->llllIll,llllIl){if(IllIII->
lllIl==lIlll->lllIl){switch(IIlIIII){case IlllIlIlI:llIlllII=IllIII->llllIl.prev
;list_del(&IllIII->llllIl);llIllll(IllIII);IllIII=list_entry(llIlllII,struct 
lIlIl,llllIl);break;case llllllIlI:IIlIIII=IIlIIII;return IllIII;case IlIlIlIII:
IIlIIII=IIlIIII;atomic_xchg(&IllIII->state,IIIIlII);return IllIII;case IllllIIll
:IIlIIII=IllIII->IIIIIlI.IIlllIIll;llIlllII=IllIII->llllIl.prev;list_del(&IllIII
->llllIl);llIllll(IllIII);IllIII=list_entry(llIlllII,struct lIlIl,llllIl);break;
}}}if(unlikely(IIlIIII==IlllIlIlI)){llIIIIII(lIlll->lIlII,lIlll->lllIl);}else{
IllIIIIll(lIlll->lIlII,lIlll->lllIl,IIlIIII);}
return NULL;}





void IIlIll(struct lIlIl*lIlll,int status){struct IlIIl*lIlII=IIlllIII(lIlll->
lIlII);struct lIlIl*llIlIIlIl=NULL;unsigned long flags;int llIIIll;int lIlIlIlIl
=(0xa58+3775-0x1917);int lIIlIlII;int IIlIIII;spin_lock_irqsave(&lIlII->IlIlll,
flags);
llIIIll=atomic_xchg(&lIlll->state,lllIlllII);










if(lIlll->IllIlIl&&llIIIll==IIIIlII&&(status==-ECONNRESET||status==-ENOENT)){
IIlIl IlIlI=(IIlIl)(lIlll+(0x117c+4249-0x2214));IlIlI->lllII.Status=-ESHUTDOWN;
IIlll(
"\x72\x65\x71\x75\x65\x73\x74\x20\x63\x61\x6e\x63\x65\x6c\x6c\x65\x64\x20\x64\x75\x65\x20\x74\x6f\x20\x64\x65\x74\x61\x63\x68\x20\x6f\x66\x20\x64\x65\x76\x69\x63\x65" "\n"
);}
if(lIlll->IIIIIlI.IlIlIIlI){

if(unlikely(llIIIll==IIIIlII)){




lIIlIlII=lIlll->IIIIIlI.lllIIIIIl;IIlIIII=lIlll->IIIIIlI.IllllIllI;
}else if(likely(status==(0xe59+4822-0x212f))){lIIlIlII=lIlll->IIIIIlI.IIIIIIIlI;
IIlIIII=lIlll->IIIIIlI.IIlIIIIll;
}else if(status==-EREMOTEIO){lIIlIlII=lIlll->IIIIIlI.IIllIlIIlI;IIlIIII=lIlll->
IIIIIlI.llIIIIIlll;
}else{lIIlIlII=lIlll->IIIIIlI.IIllIllIl;IIlIIII=lIlll->IIIIIlI.IlIlllllI;
}if(unlikely(lIIlIlII==lIllllIll)){lIlll->IlIIIIl=(0x4c1+5246-0x193e);}llIlIIlIl
=IIIIIIllI(lIlll,IIlIIII);
}
list_del(&lIlll->llllIl);
if(unlikely(lIlll->IlIIIIl)){spin_unlock_irqrestore(&lIlII->IlIlll,flags);
llIllll(lIlll);}else{spin_lock(&lIlII->lllllll);list_add_tail(&lIlll->llllIl,&
lIlII->llIlIlIl);spin_unlock(&lIlII->lllllll);spin_unlock_irqrestore(&lIlII->
IlIlll,flags);lIlIlIlIl=(0x1cd4+760-0x1fcb);}
if(llIlIIlIl){





IIlIIIlII(llIlIIlIl,GFP_ATOMIC);}
if(likely(lIlIlIlIl)){wake_up(&lIlII->IIIIlI);}








lIIlIIIl(lIlII);}
#ifdef _USBD_DEBUG_MEMORY_
extern atomic_t lIIlIllll;extern atomic_t IlIllIIII;
#endif 

int IlIIIIll(struct IlIIl*lIlII){int i;int lllIIlII,lIlIlIlI;struct usb_device*
llIII=lIlII->lIIlI;lllIIlII=lIlIlIlI=-(0xe2f+293-0xf53);
for(i=(0x1401+2805-0x1ef6);i<llIII->actconfig->desc.bNumInterfaces;i++){struct 
usb_interface*interface=llIII->actconfig->interface[i];if(interface==NULL){
continue;}if(interface->cur_altsetting==NULL){continue;}Illll(
"\x44\x65\x74\x65\x63\x74\x65\x64\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x63\x6c\x61\x73\x73\x3d\x30\x78\x25\x30\x32\x78\x20\x73\x75\x62\x63\x6c\x61\x73\x73\x3d\x30\x78\x25\x30\x32\x78\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x3d\x30\x78\x25\x30\x32\x78" "\n"
,interface->cur_altsetting->desc.bInterfaceClass,interface->cur_altsetting->desc
.bInterfaceSubClass,interface->cur_altsetting->desc.bInterfaceProtocol);if(
interface->cur_altsetting->desc.bInterfaceClass==(0x14d1+2429-0x1e46)&&interface
->cur_altsetting->desc.bInterfaceProtocol==(0x15bc+148-0x1600)){int IIIIIl;
lllIIlII=lIlIlIlI=-(0xe4b+1245-0x1327);for(IIIIIl=(0x15a2+1382-0x1b08);IIIIIl<
interface->cur_altsetting->desc.bNumEndpoints;IIIIIl++){struct usb_host_endpoint
*endpoint=&interface->cur_altsetting->endpoint[IIIIIl];if((endpoint->desc.
bmAttributes&USB_ENDPOINT_XFERTYPE_MASK)==USB_ENDPOINT_XFER_BULK){if(endpoint->
desc.bEndpointAddress&USB_ENDPOINT_DIR_MASK){lllIIlII=endpoint->desc.
bEndpointAddress;}else{lIlIlIlI=endpoint->desc.bEndpointAddress;}}}if(lllIIlII!=
-(0x245+1749-0x919)&&lIlIlIlI!=-(0x1d9a+403-0x1f2c)){unsigned long flags;Illll(
"\x44\x65\x74\x65\x63\x74\x65\x64\x20\x65\x6e\x64\x70\x6f\x69\x6e\x74\x73\x20\x30\x78\x25\x30\x32\x78\x20\x61\x6e\x64\x20\x30\x78\x25\x30\x32\x78" "\n"
,lllIIlII,lIlIlIlI);

spin_lock_irqsave(&lIlII->lIIIlI,flags);if(!lIlII->llIllII&&lIlII->IIIlIl!=
lllllII){lIlII->IlIlIIll=interface->cur_altsetting->desc.bInterfaceNumber;lIlII
->IIIIIlll=lllIIlII;lIlII->IllIlIII=lIlIlIlI;lIlII->IIIlIl=llllllll;lIlII->
llIllII=(0xe27+1672-0x14ae);
}else{
}spin_unlock_irqrestore(&lIlII->lIIIlI,flags);break;
}}}
return(0xbb2+4907-0x1edd);}void IIlllIIl(struct IlIIl*lIlII){struct lIlIII*IIlII
;unsigned long flags;Illll(
"\x21\x21\x21\x21\x20\x72\x65\x73\x65\x74\x20\x74\x72\x61\x6e\x73\x61\x63\x74\x69\x6f\x6e" "\n"
);spin_lock_irqsave(&lIlII->lIIIlI,flags);if(lIlII->IIIlIl==lllllII){


lIlII->llIllII=(0x81c+4777-0x1ac5);}else{lIlII->IIIlIl=llllllll;}IIlII=lIlII->
IIIllII;lIlII->IIIllII=NULL;spin_unlock_irqrestore(&lIlII->lIIIlI,flags);if(
IIlII){usb_unlink_urb(IIlII->IlllI);lIlllIl(IIlII);}}int lIIlIlIlI(struct IlIIl*
lIlII,IlIIlI lllIl){struct lIlIII*IIlII=NULL;unsigned long flags;Illll(
"\x21\x21\x21\x21\x72\x65\x73\x65\x74\x20\x74\x72\x61\x6e\x73\x61\x63\x74\x69\x6f\x6e\x20\x62\x79\x20\x75\x6e\x69\x71\x75\x65\x5f\x69\x64" "\n"
);spin_lock_irqsave(&lIlII->lIIIlI,flags);if(lIlII->IIIllII){if((lIlII->IIIllII
->IlllIIIll==lllIl)||(lIlII->IIIllII->IlIlIIIlI==lllIl)||(lIlII->IIIllII->
IIIIlIlII==lllIl)){if(lIlII->IIIlIl==lllllII){


lIlII->llIllII=(0xfb0+1852-0x16ec);}else{lIlII->IIIlIl=llllllll;}IIlII=lIlII->
IIIllII;lIlII->IIIllII=NULL;}}spin_unlock_irqrestore(&lIlII->lIIIlI,flags);if(
IIlII){usb_unlink_urb(IIlII->IlllI);lIlllIl(IIlII);return(0x1e9+1799-0x8ef);}
return(0x1d16+952-0x20ce);}void lIlllllI(struct IlIIl*lIlII,int IlIIIIl,int 
IlllllII){struct lIlIII*IIlII;unsigned long flags;Illll(
"\x21\x21\x21\x21\x20\x64\x69\x73\x61\x62\x6c\x65" "\n");spin_lock_irqsave(&
lIlII->lIIIlI,flags);lIlII->llIllII=(0x175d+305-0x188e);lIlII->IIIIIlll=-
(0x981+1377-0xee1);lIlII->IllIlIII=-(0xbc9+5474-0x212a);lIlII->IlIlIIll=-
(0x35f+8623-0x250d);if(lIlII->IIIlIl!=lllllII){lIlII->IIIlIl=lllIIIII;}IIlII=
lIlII->IIIllII;lIlII->IIIllII=NULL;if(IIlII){



IIlII->IlIIIIl=IlIIIIl;


IIlII->IllIlIl=IlllllII;}spin_unlock_irqrestore(&lIlII->lIIIlI,flags);if(IIlII){



#if KERNEL_GT_EQ((0xaa8+145-0xb37),(0xf53+850-0x129f),(0x1443+208-0x14f7))


usb_poison_urb(IIlII->IlllI);
#else
usb_kill_urb(IIlII->IlllI);
#endif
lIlllIl(IIlII);}}int IlllIIlIl(struct lIlIl*lIlll,gfp_t lIIIl){IIlIl IlIlI=(
IIlIl)(lIlll+(0x443+4760-0x16da));struct IlIIl*lIlII=lIlll->lIlII;struct lIlIII*
IIlII;unsigned long flags;



if(lIlll->IIIIIlI.IlIlIIlI){return-(0x16fd+1712-0x1dac);}
if(!lIlII->llIllII){return-(0x1882+1214-0x1d3f);}
if(lIlll->endpoint!=lIlII->IIIIIlll&&lIlll->endpoint!=lIlII->IllIlIII){return-
(0x420+5851-0x1afa);}
spin_lock_irqsave(&lIlII->lIIIlI,flags);IIlII=lIlII->IIIllII;if(lIlII->IIIlIl==
llllllll){


if(lIlIIllll(lIlll)){struct llllIIIl*lIlllII=lIlll->lIIIll.lllll;
if(IIlII==NULL){
IIlII=lIIlIIllI(lIlII,GFP_ATOMIC);lIlII->IIIllII=IIlII;}else{IllIIlllI(IIlII);}
if(IIlII){IIlII->IlllIIIll=IlIlI->lllII.IIllll;IIlII->IIlIlIll=le32_to_cpu(
lIlllII->IllllIIIlI);IIlII->lIIllIlI=((lIlllII->llIIIlIll&(0x117+1481-0x660))?
(0x162+7362-0x1e24):(0xf65+3405-0x1cb1));lIIlllIIl(IIlII,lIlllII);if(IIlII->
IIlIlIll){lIlII->IIIlIl=IIIlIlIII;spin_unlock_irqrestore(&lIlII->lIIIlI,flags);}
else{lIlII->IIIlIl=lllIIlIl;llIIIIll(IIlII);spin_unlock_irqrestore(&lIlII->
lIIIlI,flags);lllIIIllI(IIlII,lIIIl);}IlIlI->llIll.IlIIll.IlIll=sizeof(IlIlI->
llIll);IlIlI->llIll.IlIIll.Status=(0x1a65+2853-0x258a);
IIlIll(lIlll,(0x1882+3278-0x2550));}else{spin_unlock_irqrestore(&lIlII->lIIIlI,
flags);IlIlllI(lIlll,-ENOMEM,lIIIl);IIlIll(lIlll,-ENOMEM);}return
(0xca2+2796-0x178d);
}else{Illll(
"\x21\x21\x21\x21\x20\x53\x6b\x69\x70\x20\x6e\x6f\x6e\x2d\x43\x4f\x4d\x4d\x41\x4e\x44" "\n"
);




spin_unlock_irqrestore(&lIlII->lIIIlI,flags);return-(0x1fe3+691-0x2295);
}}else if(lIlII->IIIlIl==IIIlIlIII){


if(lIllIIIII(lIlll)){Illll(
"\x21\x21\x21\x21\x20\x44\x41\x54\x41\x20\x64\x65\x74\x65\x63\x74\x65\x64" "\n")
;IIlII->IlIlIIIlI=IlIlI->lllII.IIllll;IIlII->lIIlIl=lIlll;lIlII->IIIlIl=lllIIlIl
;llIIIIll(IIlII);spin_unlock_irqrestore(&lIlII->lIIIlI,flags);
lllIIIllI(IIlII,lIIIl);return(0x16b+2764-0xc36);
}else{Illll(
"\x21\x21\x21\x21\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x44\x41\x54\x41" "\n");
lIlII->IIIlIl=lllIIlIl;}}else if(lIlII->IIIlIl==lllIIlIl){if(IIlII->lIIlIl==NULL
&&
lIlIIlIlI(lIlll)){Illll(
"\x21\x21\x21\x21\x20\x53\x54\x41\x54\x55\x53\x20\x64\x65\x74\x65\x63\x74\x65\x64" "\n"
);IIlII->IIIIlIlII=IlIlI->lllII.IIllll;IIlII->IllllIl=lIlll;if(IIlII->status!=-
EINPROGRESS){int status=IIlII->status;if(llIlllllI(IIlII)){lIlII->IIIlIl=
llllllll;}else{lIlII->IIIlIl=lllllII;}IIlII->IllllIl=NULL;spin_unlock_irqrestore
(&lIlII->lIIIlI,flags);IIlIll(lIlll,status);}else{lIlII->IIIlIl=IIlIIIlIl;
spin_unlock_irqrestore(&lIlII->lIIIlI,flags);}return(0x1316+4898-0x2637);
}else{Illll(
"\x21\x21\x21\x21\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x53\x54\x41\x54\x55\x53" "\n"
);
lIlII->IIIlIl=lllllII;}}else if(lIlII->IIIlIl==IIlIIIlIl){


lIlII->IIIlIl=lllllII;}spin_unlock_irqrestore(&lIlII->lIIIlI,flags);IlIlllI(
lIlll,-EPIPE,lIIIl);IIlIll(lIlll,-EPIPE);return(0xc31+73-0xc79);
}int lIlIIllll(struct lIlIl*lIlll){struct IlIIl*lIlII=lIlll->lIlII;IIlIl IlIlI=(
IIlIl)(lIlll+(0x117b+2746-0x1c34));struct llllIIIl*lIlllII;if(lIlll->lIllll!=
IIlIlI){
return(0xb67+2980-0x170b);}lIlllII=lIlll->lIIIll.lllll;if(lIlllII&&lIlll->
endpoint==lIlII->IllIlIII&&IlIlI->llIll.IIllI==sizeof(struct llllIIIl)&&
le32_to_cpu(lIlllII->IllIlIIll)==1128420181){return(0xa02+6467-0x2344);}return
(0x17b+1245-0x658);}int lIllIIIII(struct lIlIl*lIlll){struct IlIIl*lIlII=lIlll->
lIlII;IIlIl IlIlI=(IIlIl)(lIlll+(0x10f1+506-0x12ea));if((IlIlI->llIll.IIllI>=
lIlII->IIIllII->IIlIlIll)&&((lIlII->IIIllII->lIIllIlI&&(lIlll->endpoint==lIlII->
IllIlIII))||(!lIlII->IIIllII->lIIllIlI&&(lIlll->endpoint==lIlII->IIIIIlll)))){
return(0x102d+4301-0x20f9);}return(0x353+4445-0x14b0);}int lIlIIlIlI(struct 
lIlIl*lIlll){struct IlIIl*lIlII=lIlll->lIlII;IIlIl IlIlI=(IIlIl)(lIlll+
(0x79b+2516-0x116e));if((lIlll->endpoint==lIlII->IIIIIlll)&&IlIlI->llIll.IIllI>=
sizeof(struct IIIlIIIIl)){return(0x435+5984-0x1b94);}return(0x15fa+1989-0x1dbf);
}struct lIlIII*lIIlIIllI(struct IlIIl*lIlII,gfp_t lIIIl){struct lIlIII*IIlII=
IllIIlI(sizeof(*IIlII),lIIIl);if(IIlII){memset(IIlII,(0x749+1769-0xe32),sizeof(*
IIlII));kref_init(&IIlII->IllIll);IIlII->lIlII=IIlllIII(lIlII);IIlII->ep_in=
lIlII->IIIIIlll;IIlII->ep_out=lIlII->IllIlIII;IIlII->status=-EINPROGRESS;IIlII->
IlllI=IIIlllIl((0x449+3168-0x10a9),lIIIl);if(likely(IIlII->IlllI)){IIlII->lllll=
IllIIlI(lIlIIIlII,lIIIl);if(likely(IIlII->lllll)){
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&lIIlIllll);
#endif
return IIlII;}lIIIlIIl(IIlII->IlllI);}lIlIll(IIlII);}return NULL;}void IllIIlllI
(struct lIlIII*IIlII){IIlII->IlllIIIll=(0x1309+4938-0x2653);IIlII->IlIlIIIlI=
(0x231+3981-0x11be);IIlII->IIIIlIlII=(0xe5a+3418-0x1bb4);IIlII->lIIlIl=NULL;
IIlII->IllllIl=NULL;IIlII->IIlIlIll=(0x10e5+444-0x12a1);IIlII->lIIllIlI=
(0xeac+4845-0x2199);IIlII->status=-EINPROGRESS;IIlII->lllIlIlI=
(0x1cb0+858-0x200a);IIlII->IlIIIIl=(0x513+7831-0x23aa);IIlII->IllIlIl=
(0x100+3796-0xfd4);}void IIIIIlIIl(struct kref*IllIlII){struct lIlIII*IIlII=
container_of(IllIlII,struct lIlIII,IllIll);struct IlIIl*lIlII=IIlII->lIlII;if(
IIlII->lIIlIl){Illll(
"\x21\x21\x21\x21\x20\x66\x72\x65\x65\x3a\x20\x64\x61\x74\x61\x20\x65\x78\x69\x73\x74\x73" "\n"
);IIlII->lIIlIl->IlIIIIl=IIlII->IlIIIIl;IIlII->lIIlIl->IllIlIl=IIlII->IllIlIl;
IlIlllI(IIlII->lIIlIl,-ECONNRESET,GFP_ATOMIC);IIlIll(IIlII->lIIlIl,-ECONNRESET);
}if(IIlII->IllllIl){Illll("!!!! free: �tatus exists\n");IIlII->IllllIl->IlIIIIl=
IIlII->IlIIIIl;IIlII->IllllIl->IllIlIl=IIlII->IllIlIl;IlIlllI(IIlII->IllllIl,-
ECONNRESET,GFP_ATOMIC);IIlIll(IIlII->IllllIl,-ECONNRESET);}lIIIlIIl(IIlII->IlllI
);lIlIll(IIlII->lllll);lIlIll(IIlII);lIIlIIIl(lIlII);
#ifdef _USBD_DEBUG_MEMORY_
atomic_inc(&IlIllIIII);
#endif
Illll(
"\x21\x21\x21\x21\x20\x4d\x61\x73\x73\x53\x74\x6f\x72\x61\x67\x65\x46\x72\x65\x65\x54\x72\x61\x6e\x73\x61\x63\x74\x69\x6f\x6e" "\n"
);}static inline void llIIIIll(struct lIlIII*IIlII){kref_get(&IIlII->IllIll);}
static inline void lIlllIl(struct lIlIII*IIlII){kref_put(&IIlII->IllIll,
IIIIIlIIl);}void lIIlllIIl(struct lIlIII*IIlII,struct llllIIIl*lIlllII){struct 
IlIIl*lIlII=IIlII->lIlII;memcpy(IIlII->lllll,lIlllII,sizeof(struct llllIIIl));
#if KERNEL_GT_EQ((0xbf3+1071-0x1020),(0xf00+5578-0x24c4),(0x4a7+2076-0xca4))
IIlII->IlllI->sg=NULL;IIlII->IlllI->num_sgs=(0xff+747-0x3ea);
#endif
#if KERNEL_GT_EQ((0x8f2+1152-0xd6f),(0xb37+520-0xd3c),(0xaf7+960-0xeb7))
IIlII->IlllI->num_mapped_sgs=(0x16b8+2280-0x1fa0);
#endif
IIlII->IlllI->transfer_dma=(0x1bd+871-0x524);usb_fill_bulk_urb(IIlII->IlllI,
lIlII->lIIlI,usb_sndbulkpipe(lIlII->lIIlI,IIlII->ep_out&USB_ENDPOINT_NUMBER_MASK
),IIlII->lllll,sizeof(struct llllIIIl),IIlIlIIIl,IIlII);IIlII->IlllI->
transfer_flags&=~URB_SHORT_NOT_OK;}void IIIIlIIII(struct lIlIII*IIlII){struct 
IlIIl*lIlII=IIlII->lIlII;struct lIlIl*lIlll=IIlII->lIIlIl;IIlIl IlIlI=(IIlIl)(
lIlll+(0x12d1+2247-0x1b97));int pipe=(IlIlI->llIll.Flags&IIIllI)?usb_rcvbulkpipe
(lIlll->lIlII->lIIlI,IlIlI->llIll.Endpoint):usb_sndbulkpipe(lIlll->lIlII->lIIlI,
IlIlI->llIll.Endpoint);
#if KERNEL_GT_EQ((0x536+5984-0x1c94),(0xd2+2487-0xa83),(0x9bb+5153-0x1dbd))
IIlII->IlllI->sg=NULL;IIlII->IlllI->num_sgs=(0x9ac+1179-0xe47);
#endif
#if KERNEL_GT_EQ((0xefc+3784-0x1dc1),(0x820+2000-0xfed),(0x7a4+4965-0x1b09))
IIlII->IlllI->num_mapped_sgs=(0xa69+177-0xb1a);
#endif
IIlII->IlllI->transfer_dma=(0x1174+4954-0x24ce);switch(lIlll->lIllll){case 
IIlIlI:usb_fill_bulk_urb(IIlII->IlllI,lIlII->lIIlI,pipe,lIlll->lIIIll.lllll,
IlIlI->llIll.IIllI,lIIllIII,IIlII);break;case llIIlIl:usb_fill_bulk_urb(IIlII->
IlllI,lIlII->lIIlI,pipe,lIlll->lIllII.llIllI->IllIIl[IIlII->lllIlIlI].
transfer_buffer,lIlll->lIllII.llIllI->IllIIl[IIlII->lllIlIlI].
transfer_buffer_length,lIIllIII,IIlII);break;
#if KERNEL_GT_EQ((0x1585+869-0x18e8),(0x240+1374-0x798),(0xf9c+3054-0x1b6b))
case lllIIII:usb_fill_bulk_urb(IIlII->IlllI,lIlII->lIIlI,pipe,NULL,IlIlI->llIll.
IIllI,lIIllIII,IIlII);IIlII->IlllI->sg=lIlll->lIIllII.sg.IlIlIIl;IIlII->IlllI->
num_sgs=lIlll->lIIllII.sg.num_sgs;break;
#endif
}if(IlIlI->llIll.Flags&IIIllI){if((IlIlI->llIll.Flags&lIIIIlI)==
(0x11f9+5350-0x26df)){IIlII->IlllI->transfer_flags|=URB_SHORT_NOT_OK;}else{IIlII
->IlllI->transfer_flags&=~URB_SHORT_NOT_OK;}}}void lIlIIIIl(struct lIlIII*IIlII)
{struct IlIIl*lIlII=IIlII->lIlII;
#if KERNEL_GT_EQ((0x2149+1091-0x258a),(0x161b+2430-0x1f93),(0xc68+621-0xeb6))
IIlII->IlllI->sg=NULL;IIlII->IlllI->num_sgs=(0x12d+8336-0x21bd);
#endif
#if KERNEL_GT_EQ((0x885+4839-0x1b69),(0x1e71+1779-0x2561),(0x180f+846-0x1b5d))
IIlII->IlllI->num_mapped_sgs=(0xab3+7232-0x26f3);
#endif
IIlII->IlllI->transfer_dma=(0xac3+7200-0x26e3);usb_fill_bulk_urb(IIlII->IlllI,
lIlII->lIIlI,usb_rcvbulkpipe(lIlII->lIIlI,IIlII->ep_in&USB_ENDPOINT_NUMBER_MASK)
,IIlII->lllll,lIlIIIlII,llIlllIlI,IIlII);IIlII->IlllI->transfer_flags&=~
URB_SHORT_NOT_OK;}static inline void lllIIIllI(struct lIlIII*IIlII,gfp_t lIIIl){
int status=usb_submit_urb(IIlII->IlllI,lIIIl);if(status<(0x138c+4718-0x25fa)){
lIllIIIlI(IIlII,status,lIIIl);lIlllIl(IIlII);}}static inline void llIllIIll(
struct lIlIII*IIlII,gfp_t lIIIl){int status=usb_submit_urb(IIlII->IlllI,lIIIl);
if(status<(0x5ec+5150-0x1a0a)){IlIIllIll(IIlII,status,lIIIl);lIlllIl(IIlII);}}
static inline void IlIIlIIIl(struct lIlIII*IIlII,gfp_t lIIIl){int status=
usb_submit_urb(IIlII->IlllI,lIIIl);if(status<(0x5e5+7992-0x251d)){lIIlllIII(
IIlII,status,lIIIl);lIlllIl(IIlII);}}void lIllIIIlI(struct lIlIII*IIlII,int 
status,gfp_t lIIIl){struct IlIIl*lIlII=IIlII->lIlII;unsigned long flags;
spin_lock_irqsave(&lIlII->lIIIlI,flags);if(lIlII->IIIllII!=IIlII){



spin_unlock_irqrestore(&lIlII->lIIIlI,flags);Illll(
"\x21\x21\x21\x21\x20\x43\x4f\x4d\x4d\x41\x4e\x44\x20\x63\x61\x6e\x63\x65\x6c\x6c\x65\x64" "\n"
);}else if(status==(0xb1d+2208-0x13bd)){





if(IIlII->IIlIlIll==(0x160f+4245-0x26a4)){lIlIIIIl(IIlII);llIIIIll(IIlII);}else{
IIIIlIIII(IIlII);llIIIIll(IIlII);}spin_unlock_irqrestore(&lIlII->lIIIlI,flags);
if(IIlII->IIlIlIll==(0x4a3+7387-0x217e)){IlIIlIIIl(IIlII,lIIIl);}else{llIllIIll(
IIlII,lIIIl);}}else
{struct lIlIl*lIIlIl;struct lIlIl*IllllIl;

lIIlIl=IIlII->lIIlIl;IIlII->lIIlIl=NULL;IllllIl=IIlII->IllllIl;IIlII->IllllIl=
NULL;if(lIlII->IIIlIl!=lllllII){lIlII->IIIlIl=lllIIIII;}spin_unlock_irqrestore(&
lIlII->lIIIlI,flags);if(lIIlIl){IlIlllI(lIIlIl,status,lIIIl);IIlIll(lIIlIl,
status);}if(IllllIl){IlIlllI(IllllIl,status,lIIIl);IIlIll(IllllIl,status);}}}
void IlIIllIll(struct lIlIII*IIlII,int status,gfp_t lIIIl){struct IlIIl*lIlII=
IIlII->lIlII;struct lIlIl*lIIlIl=IIlII->lIIlIl;IIlIl IIllIlII=(IIlIl)(lIIlIl+
(0x1183+3402-0x1ecc));unsigned long flags;
if(IIlII->lllIlIlI==(0x7fd+894-0xb7b)){IIllIlII->llIll.IIllI=IIlII->IlllI->
actual_length;}else{IIllIlII->llIll.IIllI+=IIlII->IlllI->actual_length;}
if(usb_pipein(IIlII->IlllI->pipe)){IIllIlII->lllII.IlIll=sizeof(IIllIlII->llIll)
+IIllIlII->llIll.IIllI;}else{IIllIlII->lllII.IlIll=sizeof(IIllIlII->llIll);}
if(lIIlIl->lIllll==llIIlIl){lIIlIl->lIllII.llIllI->IllIIl[IIlII->lllIlIlI].
actual_length=IIlII->IlllI->actual_length;}IIllIlII->llIll.IlIIll.Status=status;
spin_lock_irqsave(&lIlII->lIIIlI,flags);if(lIlII->IIIllII!=IIlII){



Illll(
"\x21\x21\x21\x21\x20\x44\x41\x54\x41\x20\x63\x61\x6e\x63\x65\x6c\x6c\x65\x64" "\n"
);spin_unlock_irqrestore(&lIlII->lIIIlI,flags);}else if(status==
(0x1ebb+1633-0x251c)){




if(lIIlIl->lIllll==llIIlIl){IIlII->lllIlIlI++;if((IIlII->IlllI->actual_length==
IIlII->IlllI->transfer_buffer_length)&&(IIlII->lllIlIlI<lIIlIl->lIllII.llIllI->
IlIII)){
lIIlIl=NULL;

IIIIlIIII(IIlII);llIIIIll(IIlII);}else{

IIlII->lIIlIl=NULL;
lIlIIIIl(IIlII);llIIIIll(IIlII);}}else{
IIlII->lIIlIl=NULL;
lIlIIIIl(IIlII);llIIIIll(IIlII);}spin_unlock_irqrestore(&lIlII->lIIIlI,flags);if
(lIIlIl){
IIlIll(lIIlIl,(0x193+4972-0x14ff));
IlIIlIIIl(IIlII,lIIIl);}else{llIllIIll(IIlII,lIIIl);}}else
{
IIlII->lIIlIl=NULL;if(lIlII->IIIlIl!=lllllII){lIlII->IIIlIl=lllIIIII;}
spin_unlock_irqrestore(&lIlII->lIIIlI,flags);if(lIIlIl){
IIlIll(lIIlIl,status);}}}void lIIlllIII(struct lIlIII*IIlII,int status,gfp_t 
lIIIl){struct IlIIl*lIlII=IIlII->lIlII;unsigned long flags;spin_lock_irqsave(&
lIlII->lIIIlI,flags);if(lIlII->IIIllII!=IIlII){



Illll(
"\x21\x21\x21\x21\x20\x53\x54\x41\x54\x55\x53\x20\x63\x61\x6e\x63\x65\x6c\x6c\x65\x64" "\n"
);spin_unlock_irqrestore(&lIlII->lIIIlI,flags);}else{struct lIlIl*IllllIl=NULL;





IIlII->status=status;

if(IIlII->IllllIl){if(llIlllllI(IIlII)){if(lIlII->IIIlIl!=lllllII){lIlII->IIIlIl
=llllllll;}}else{lIlII->IIIlIl=lllllII;}IllllIl=IIlII->IllllIl;IIlII->IllllIl=
NULL;}spin_unlock_irqrestore(&lIlII->lIIIlI,flags);if(IllllIl){IIlIll(IllllIl,
status);}}}static void IIlIlIIIl(struct urb*IlllI
#if KERNEL_LT((0x1db+802-0x4fb),(0x2139+642-0x23b5),(0x1ae2+2991-0x267e))
,struct pt_regs*IIlIlII
#endif
){struct lIlIII*IIlII=IlllI->context;Illll(
"\x21\x21\x21\x21\x20\x43\x4f\x4d\x4d\x41\x4e\x44\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x2d\x20\x73\x74\x61\x74\x75\x73\x3d\x25\x64" "\n"
,IlllI->status);
lIllIIIlI(IIlII,IlllI->status,GFP_ATOMIC);lIlllIl(IIlII);}static void lIIllIII(
struct urb*IlllI
#if KERNEL_LT((0x636+7852-0x24e0),(0x1b27+380-0x1c9d),(0x1858+487-0x1a2c))
,struct pt_regs*IIlIlII
#endif
){struct lIlIII*IIlII=IlllI->context;Illll(
"\x21\x21\x21\x21\x20\x44\x41\x54\x41\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x2d\x20\x73\x74\x61\x74\x75\x73\x3d\x25\x64" "\n"
,IlllI->status);
IlIIllIll(IIlII,IlllI->status,GFP_ATOMIC);lIlllIl(IIlII);}static void llIlllIlI(
struct urb*IlllI
#if KERNEL_LT((0xc37+4221-0x1cb2),(0x1553+74-0x1597),(0x10f+8956-0x23f8))
,struct pt_regs*IIlIlII
#endif
){struct lIlIII*IIlII=IlllI->context;Illll(
"\x21\x21\x21\x21\x20\x53\x54\x41\x54\x55\x53\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x2d\x20\x73\x74\x61\x74\x75\x73\x3d\x25\x64" "\n"
,IlllI->status);
lIIlllIII(IIlII,IlllI->status,GFP_ATOMIC);lIlllIl(IIlII);}int llIlllllI(struct 
lIlIII*IIlII){IIlIl IlIlI=(IIlIl)(IIlII->IllllIl+(0x178a+2256-0x2059));
if(IlIlI->llIll.IIllI>=IIlII->IlllI->actual_length){IlIlI->llIll.IIllI=IIlII->
IlllI->actual_length;IlIlI->llIll.IlIIll.IlIll=sizeof(IlIlI->llIll)+IlIlI->llIll
.IIllI;IlIlI->llIll.IlIIll.Status=IIlII->status;memcpy(IIlII->IllllIl->lIIIll.
lllll,IIlII->lllll,IIlII->IlllI->actual_length);return(0x1bba+675-0x1e5c);}


IlIlI->llIll.IlIIll.IlIll=sizeof(IlIlI->llIll)+IlIlI->llIll.IIllI;IlIlI->llIll.
IlIIll.Status=-EOVERFLOW;memcpy(IIlII->IllllIl->lIIIll.lllll,IIlII->lllll,IlIlI
->llIll.IIllI);return(0x1ab6+894-0x1e34);}
#endif 

