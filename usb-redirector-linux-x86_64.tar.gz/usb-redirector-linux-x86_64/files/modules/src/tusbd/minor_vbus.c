/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifdef _USBD_ENABLE_VHCI_
#include "usbd.h"
ssize_t IIIlIIlII(void*,const char __user*,size_t);ssize_t IlIllIIIl(void*,char 
__user*,size_t);long IllllIIIl(void*,unsigned int,unsigned long);
#ifdef CONFIG_COMPAT
long lIIIIIIll(void*,unsigned int,unsigned long);
#endif
int lllllIIIl(void*,int);int IlllllIII(void*,int);unsigned int lIlIIIIll(void*,
struct file*,poll_table*IIIIlI);int lllIIIlIl(struct IIIlll*IllII,struct 
llIlIIIll __user*ioctl);int lIIIllllI(struct IIIlll*IllII,struct llIIlIIIl 
__user*ioctl);int IllllIlll(struct IIIlll*IllII,struct IlIIIIIlI __user*ioctl);
static struct IllIlllI IlIllIIlI[]={{"\x74\x79\x70\x65","\x76\x62\x75\x73",NULL}
,{NULL,NULL,NULL}};struct IIIlll*llIIIIlll(void){struct IIIlll*IllII;IllII=
lllIlII(sizeof(*IllII),GFP_KERNEL);if(IllII){mutex_init(&IllII->mutex);IllII->
context=IllII;IllII->IIlIII=-(0x164d+3180-0x22b8);IllII->ops.open=lllllIIIl;
IllII->ops.release=IlllllIII;IllII->ops.unlocked_ioctl=IllllIIIl;
#ifdef CONFIG_COMPAT
IllII->ops.compat_ioctl=lIIIIIIll;
#endif
IllII->ops.read=IlIllIIIl;IllII->ops.write=IIIlIIlII;IllII->ops.poll=lIlIIIIll;
IllII->IlIlllII=IlIllIIlI;if(llIIIlIl(IllII,(0x660+5276-0x1afb),(0x6ab+36-0x6ce)
)<(0x1890+218-0x196a)){lIlIll(IllII);IllII=NULL;}}return IllII;}void IIIlIlIll(
struct IIIlll*IllII){if(IllII){lIIlIIlI(IllII);lIlIll(IllII);}}ssize_t IlIllIIIl
(void*context,char __user*IIIlI,size_t IlIII){
ssize_t IIIll=(0x35b+3769-0x1214);Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x72\x65\x61\x64\x3a\x20\x62\x75\x66\x20\x69\x73\x20\x30\x78\x25\x70\x2c\x20\x72\x65\x71\x75\x65\x73\x74\x65\x64\x20\x25\x6c\x75\x20\x62\x79\x74\x65\x73" "\n"
,IIIlI,(unsigned long)IlIII);return IIIll;}ssize_t IIIlIIlII(void*context,const 
char __user*IIIlI,size_t IlIII){
ssize_t IIIll=IlIII;Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x77\x72\x69\x74\x65\x3a\x20\x62\x75\x66\x20\x69\x73\x20\x30\x78\x25\x70\x2c\x20\x72\x65\x71\x75\x65\x73\x74\x65\x64\x20\x25\x6c\x75\x20\x62\x79\x74\x65\x73" "\n"
,IIIlI,(unsigned long)IlIII);return IIIll;}long lllIIlIII(void*context,unsigned 
int lIIIIl,void __user*IlIIII){struct IIIlll*IllII=context;ssize_t IIIll=
(0x1df+5008-0x156f);Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x64\x6f\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x2b\x2b\x20\x63\x6d\x64\x3d\x25\x64\x20\x61\x72\x67\x3d\x30\x78\x25\x70" "\n"
,lIIIIl,IlIIII);switch(lIIIIl){case IIllIIIIl:IIIll=lllIIIlIl(IllII,IlIIII);
break;case IlIlIIIll:IIIll=lIIIllllI(IllII,IlIIII);break;case lIIlIlIII:IIIll=
IllllIlll(IllII,IlIIII);break;default:Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x64\x6f\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x69\x6f\x63\x74\x6c" "\n"
);IIIll=-EINVAL;break;}Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x64\x6f\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x6c\x75" "\n"
,(unsigned long)IIIll);return IIIll;}long IllllIIIl(void*context,unsigned int 
lIIIIl,unsigned long IlIIII){Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x69\x6f\x63\x74\x6c" "\n");return 
lllIIlIII(context,lIIIIl,(void __user*)IlIIII);}
#ifdef CONFIG_COMPAT
long lIIIIIIll(void*context,unsigned int lIIIIl,unsigned long IlIIII){Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x63\x6f\x6d\x70\x61\x74\x5f\x69\x6f\x63\x74\x6c" "\n"
);return lllIIlIII(context,lIIIIl,compat_ptr(IlIIII));}
#endif


int lllllIIIl(void*context,int lllIllI){
Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x6f\x70\x65\x6e\x20\x25\x64" "\n",
lllIllI);return(0x1d17+2398-0x2675);}

int IlllllIII(void*context,int lllIllI){
Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x72\x65\x6c\x65\x61\x73\x65\x20\x25\x64" "\n"
,lllIllI);if(lllIllI==(0x139c+94-0x13fa)){
llIlIlIII();}return(0xf17+5689-0x2550);}unsigned int lIlIIIIll(void*context,
struct file*lIlllI,poll_table*IIIIlI){
return(POLLOUT|POLLWRNORM);}int lllIIIlIl(struct IIIlll*IllII,struct llIlIIIll 
__user*ioctl){int IIIll=(0x6b0+5397-0x1bc5);struct lIlIIl*lIIII=NULL;IIIIl 
IllllI;IlllIl vid;IlllIl lIllIIl;IlllIl lIIlIIl;IlllIl lIIlIlIll;lIllIl speed;
Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x69\x6f\x63\x74\x6c\x5f\x70\x6c\x75\x67\x5f\x64\x65\x76\x69\x63\x65\x3a\x20\x2b\x2b" "\n"
);do
{if(get_user(IllllI,&ioctl->lIIlII.lIIIllI)<(0x3ad+6706-0x1ddf)){IIIll=-EFAULT;
break;}if(IllllI!=sizeof(struct llIlIIIll)){IIIll=-EINVAL;break;}if(get_user(vid
,&ioctl->IIIIIlIl)<(0x37+1725-0x6f4)){IIIll=-EFAULT;break;}if(get_user(lIllIIl,&
ioctl->lIIIllIl)<(0x1c64+1748-0x2338)){IIIll=-EFAULT;break;}if(get_user(lIIlIIl,
&ioctl->lIlIlIII)<(0xa2d+2201-0x12c6)){IIIll=-EFAULT;break;}if(get_user(
lIIlIlIll,&ioctl->llIIllll)<(0xc1b+6850-0x26dd)){IIIll=-EFAULT;break;}if(
get_user(speed,&ioctl->IIllIlIIl)<(0x17d2+3848-0x26da)){IIIll=-EFAULT;break;}
switch(speed){case llIIlllIl:speed=USB_SPEED_LOW;break;case lIIIIllIl:speed=
USB_SPEED_FULL;break;case lIIIIIIII:speed=USB_SPEED_HIGH;break;case llIIIIlIl:
#if KERNEL_GT_EQ((0x354+6215-0x1b99),(0x6c8+6907-0x21bd),(0x1e43+922-0x21b6)) ||\
 RHEL_RELEASE_GT_EQ((0x60b+2374-0xf4b),(0x184+3179-0xdec)) 
speed=USB_SPEED_SUPER;
#else
llIlII(
"\x55\x53\x42\x20\x33\x2e\x30\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x6b\x65\x72\x6e\x65\x6c\x2c\x20\x75\x73\x65\x20\x6b\x65\x72\x6e\x65\x6c\x20\x32\x2e\x36\x2e\x33\x39\x20\x6f\x72\x20\x6e\x65\x77\x65\x72" "\n"
);IIIll=-EINVAL;
#endif
break;case IlIIlIlII:
#if KERNEL_GT_EQ((0x41a+5651-0x1a29),(0x914+5705-0x1f57),(0x2521+408-0x26b9))
speed=USB_SPEED_SUPER_PLUS;
#else

llIlII(
"\x55\x53\x42\x20\x33\x2e\x31\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x6b\x65\x72\x6e\x65\x6c\x2c\x20\x75\x73\x65\x20\x6b\x65\x72\x6e\x65\x6c\x20\x34\x2e\x36\x20\x6f\x72\x20\x6e\x65\x77\x65\x72" "\n"
);IIIll=-EINVAL;
#endif
break;default:Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x69\x6f\x63\x74\x6c\x5f\x70\x6c\x75\x67\x5f\x64\x65\x76\x69\x63\x65\x3a\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x64\x65\x76\x69\x63\x65\x20\x73\x70\x65\x65\x64" "\n"
);IIIll=-EINVAL;break;}if(IIIll<(0xc1b+2634-0x1665)){break;}lIIII=IlIIllllI(vid,
lIllIIl,lIIlIIl,speed);if(lIIII==(0x141+694-0x3f7)){IIIll=-ENOMEM;break;}IIIll=
lIIlIIIII(lIIII);if(IIIll<(0x43d+1192-0x8e5)){lIlIIlll(lIIII);break;}IIlll(
"\x64\x65\x76\x69\x63\x65\x69\x64\x3d\x25\x64" "\n",lIIlIllI(lIIII->IllII));if(
put_user((IIIIl)lIIlIllI(lIIII->IllII),&ioctl->llllIIIII)<(0x14ca+3772-0x2386)){
lIlIIlll(lIIII);IIIll=-EFAULT;break;}}while((0xc2d+108-0xc99));if(IIIll<
(0x985+5738-0x1fef)){if(lIIII){lIlIIlll(lIIII);}}Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x69\x6f\x63\x74\x6c\x5f\x70\x6c\x75\x67\x5f\x64\x65\x76\x69\x63\x65\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}int lIIIllllI(struct IIIlll*IllII,struct llIIlIIIl __user*
ioctl){int IIIll=(0xd73+1468-0x132f);struct lIlIIl*lIIII;IIIIl IllllI;IIIIl 
llIIIlIIl;Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x69\x6f\x63\x74\x6c\x5f\x75\x6e\x70\x6c\x75\x67\x5f\x64\x65\x76\x69\x63\x65\x3a\x20\x2b\x2b" "\n"
);do
{if(get_user(IllllI,&ioctl->lIIlII.lIIIllI)<(0x1f48+254-0x2046)){IIIll=-EFAULT;
break;}if(IllllI!=sizeof(struct llIIlIIIl)){IIIll=-EINVAL;break;}if(get_user(
llIIIlIIl,&ioctl->llllIIIII)<(0x7a5+3229-0x1442)){IIIll=-EFAULT;break;}lIIII=
IIlIIllII(llIIIlIIl);if(lIIII==NULL){Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x69\x6f\x63\x74\x6c\x5f\x75\x6e\x70\x6c\x75\x67\x5f\x64\x65\x76\x69\x63\x65\x3a\x20\x64\x65\x76\x69\x63\x65\x20\x25\x75\x20\x69\x73\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,llIIIlIIl);IIIll=-ENODEV;break;}

lIlIIlll(lIIII);
lIlIlIIl(lIIII);}while((0xd74+5625-0x236d));Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x69\x6f\x63\x74\x6c\x5f\x75\x6e\x70\x6c\x75\x67\x5f\x64\x65\x76\x69\x63\x65\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}int IllllIlll(struct IIIlll*IllII,struct IlIIIIIlI __user*
ioctl){int IIIll=(0x7d3+2226-0x1085);IIIIl IllllI;Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x69\x6f\x63\x74\x6c\x5f\x75\x73\x62\x33\x5f\x73\x75\x70\x70\x6f\x72\x74\x3a\x20\x2b\x2b" "\n"
);do
{if(get_user(IllllI,&ioctl->lIIlII.lIIIllI)<(0xa+7729-0x1e3b)){IIIll=-EFAULT;
break;}if(IllllI!=sizeof(struct IlIIIIIlI)){IIIll=-EINVAL;break;}
#if KERNEL_GT_EQ((0x227+9245-0x2642),(0x1a7b+2833-0x2586),(0x11da+41-0x11dc)) ||\
 RHEL_RELEASE_GT_EQ((0x1fb7+1223-0x2478),(0x1568+1997-0x1d32))
IIIll=(0x2206+1148-0x2682);
#else
IIIll=-EPIPE;
#endif
}while((0x5ec+5713-0x1c3d));Illll(
"\x75\x73\x62\x64\x5f\x76\x62\x75\x73\x5f\x69\x6f\x63\x74\x6c\x5f\x75\x73\x62\x33\x5f\x73\x75\x70\x70\x6f\x72\x74\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IIIll);return IIIll;}
#endif 

