/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef lIIlllIll
#define lIIlllIll

#ifdef __KERNEL__
#include <linux/types.h>
#else
#include <stdint.h>
#endif
typedef int8_t IIIIIIIlII;typedef int16_t IlIIlIlIII;typedef int32_t Illlllllll;
typedef int64_t IIlIIIlIll;typedef uint8_t lIllIl;typedef uint16_t IlllIl;
typedef uint32_t IIIIl;typedef uint64_t IlIIlI;typedef int BOOL;
#ifndef __KERNEL__
#include <semaphore.h>
typedef sem_t*IlIlIIIIlI;
#endif
#ifndef TRUE
#define TRUE (0xa7b+4106-0x1a84)
#endif
#ifndef FALSE
#define FALSE (0x87c+2280-0x1164)
#endif
#ifndef __KERNEL__
#include <endian.h>
#include <byteswap.h>
#if __BYTE_ORDER == __BIG_ENDIAN
#define lIlIlIIll(lIIllI) lIllllIII((lIIllI))
#define IIlIlIIII(lIIllI) lIIlIlIIII((lIIllI))
#define lIllIIllI(lIIllI) lIlllllll((lIIllI))
#define llIllIlII(lIIllI) lIllllIII((lIIllI))
#define llIllIIlI(lIIllI) lIIlIlIIII((lIIllI))
#define IlIlIlllI(lIIllI) lIlllllll((lIIllI))
#else
#define lIlIlIIll(lIIllI) (lIIllI)
#define IIlIlIIII(lIIllI) (lIIllI)
#define lIllIIllI(lIIllI) (lIIllI)
#define llIllIlII(lIIllI) (lIIllI)
#define llIllIIlI(lIIllI) (lIIllI)
#define IlIlIlllI(lIIllI) (lIIllI)
#endif
# endif
#endif 

