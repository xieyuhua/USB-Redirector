/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef lIlIIIlIl
#define lIlIIIlIl
struct IIlIlll{IIIIl lIIIllI;};


#define lIIIllIII			_IO(((char)(0x1af5+2699-0x2540)), (0x1422+1769-0x1a6b))
#define lIIIlIIll			_IO(((char)(0x35f+2514-0xcf1)), (0x19b4+304-0x1a43))
#define llIIIlllI			_IO(((char)(0x109b+1224-0x1523)), (0x1f67+20-0x1ed9))
#define lllIIlIlI	_IO(((char)(0xc44+1265-0x10f5)), (0x1e4f+1716-0x2460))
#define IIIllIIII		_IO(((char)(0x48+6814-0x1aa6)), (0x1cef+1092-0x208f))
#define IIIlIlllll			_IO(((char)(0x88a+6064-0x1ffa)), (0x1b9c+591-0x1d46))
#define llIIllIIl				_IO(((char)(0x1a1b+1442-0x1f7d)), (0x6c6+1763-0xd03))
#define IIIIIlIll	_IO(((char)(0xef+3933-0x100c)), (0x718+2157-0xede))
struct lIIIlllIl{struct IIlIlll lIIlII;IIIIl busnum;IIIIl devnum;};struct 
lllllllIl{struct IIlIlll lIIlII;IIIIl lllIlIl;};struct IIIlllllI{struct IIlIlll 
lIIlII;IIIIl IlIlIII;};struct IIIIlIlIl{struct IIlIlll lIIlII;};struct 
llIllllIIl{struct IIlIlll lIIlII;IIIIl llIlIIll;};


#define IIlIIlIlI	(0x1211+4424-0x2359)
#define llIIIlllll		(0x846+7569-0x25d6)
#define lIIlIIlll		(0x302+3508-0x10b4)
#define llIlllIIl		(0x223+8477-0x233d)
#define IllIIlIlI		(0xe92+2412-0x17fb)






#define llIIlllIl						((lIllIl)(0x53+2303-0x952))
#define lIIIIllIl					((lIllIl)(0x7db+1172-0xc6e))
#define lIIIIIIII					((lIllIl)(0x1e00+106-0x1e68))
#define llIIIIlIl					((lIllIl)(0x1fd2+401-0x2160))
#define IlIIlIlII				((lIllIl)(0xd65+4791-0x2018))
#define IllIIIIII					((lIllIl)-(0x1d41+2080-0x2560))
#define IIllIIIIl		_IO(((char)(0x12aa+262-0x1370)), (0x2096+521-0x21eb))
#define IlIlIIIll		_IO(((char)(0x2f3+6213-0x1af8)), (0x7a9+5069-0x1ac1))
#define lIIlIlIII		_IO(((char)(0xea2+3123-0x1a95)), (0x502+3782-0x1312))
struct llIlIIIll{struct IIlIlll lIIlII;IIIIl llllIIIII;IlllIl IIIIIlIl;IlllIl 
lIIIllIl;IlllIl lIlIlIII;IlllIl llIIllll;lIllIl IIllIlIIl;
};struct llIIlIIIl{struct IIlIlll lIIlII;IIIIl llllIIIII;};struct IlIIIIIlI{
struct IIlIlll lIIlII;};


#define lllIIllIll		_IO(((char)(0x1c63+2713-0x26bc)), (0x2230+163-0x220b))
#define lIlllIllI		_IO(((char)(0x76+9017-0x236f)), (0x7a8+440-0x897))
#define lIllIIIIl		_IO(((char)(0x1172+1896-0x189a)), (0x1762+1211-0x1b53))
#define IIlIllIIl		_IO(((char)(0x13b0+3139-0x1fb3)), (0x123f+2197-0x1a09))
#define lllIIlIIl		_IO(((char)(0xe71+1009-0x1222)), (0xa43+269-0xa84))
#define lIlIIlllI	_IO(((char)(0x1f55+255-0x2014)), (0x690+6583-0x1f7a))
#define IlIIlIlIl	_IO(((char)(0x3fc+7886-0x228a)), (0x5cf+6731-0x1f4c))
#define IIIllIIIl		_IO(((char)(0xdbd+5832-0x2445)), (0x1434+1593-0x199e))
#define lIlIlIllI		_IO(((char)(0x1510+2614-0x1f06)), (0x611+5129-0x194a))
struct IIIIllllI{struct IIlIlll lIIlII;IIIIl IlllIllI;
};struct IIIIIIIIl{struct IIlIlll lIIlII;};struct IlIIIlIll{struct IIlIlll 
lIIlII;lIllIl IlIIIlIIl;char lllllI[(0x88f+5248-0x1cee)];
};struct IIIIlIllI{struct IIlIlll lIIlII;lIllIl IIIIIlII;char lllllI[
(0x6d4+2549-0x10a8)];
};struct lIIlIllIl{struct IIlIlll lIIlII;char lllllI[(0x80a+6250-0x2053)];
};struct lIlllllIl{struct IIlIlll lIIlII;char lllllI[(0x1187+1699-0x1809)];

};struct IllIIIlll{struct IIlIlll lIIlII;char lllllI[(0x827+993-0xbe7)];

};struct lIlllllIII{struct IIlIlll lIIlII;IIIIl IlllIllI;
};struct IlllIIlII{struct IIlIlll lIIlII;};
#if (0x884+7599-0x2633)
struct lIllIlIIl{struct IIlIlll lIIlII;char lllllI[(0x88b+4830-0x1b48)];
IlllIl IIIIIlIl;IlllIl lIIIllIl;IlllIl lIlIlIII;IlllIl llIIllll;lIllIl llIIIIlI;
lIllIl llIlllll;lIllIl lllIlllI;lIllIl IIllIlIIl;
lIllIl IlIlIllIlI;lIllIl IlIIlIIlII;char llIIllI[(0x18d4+205-0x18a1)];char 
serial[(0xc87+386-0xd09)];char lIIIIIIlll[(0x1008+2185-0x1791)];char description
[(0x176c+3752-0x2514)];};
#endif




#define llIIlllII			(0x21aa+478-0x2387)
#define lIlllIIII			(0x2e6+1366-0x83a)
#define IIlIIlIIl			(0xf1f+2448-0x18ab)
#define IlIlIlllII		(0x6bd+5839-0x1d84)
#define IIlIIIlll	(0x143a+2880-0x1f6a)
#define IlIIIIIIl	(0xee1+1514-0x14ab)
#define llIllllII		(0xb35+3895-0x1a2c)
#define IlIIIIlll		(0x1354+3098-0x1eee)

#define lIIIIlIlI	268435456
#define lIlIIlIll		536870912
#define IllllllII		1073741824
typedef struct IllIllll{IIIIl lIlIllI;IIIIl IlllIIl;IIIIl llIIlIll;IIIIl 
lIIIlIlI;IlllIl IIIIIlIl;IlllIl lIIIllIl;IlllIl lIlIlIII;lIllIl llIIIIlI;lIllIl 
llIlllll;lIllIl lllIlllI;


}lIIIlIlllI,*llIIlllIlI;



#define IIIlIIIIII		(0x66a+6073-0x1e21)
typedef struct lIllIIII{IlllIl IIIIIlIl;IlllIl lIIIllIl;IIIIl IllIlIlII;}
IIlIlIlIlI,*llIIIIIIlI;
#endif 

