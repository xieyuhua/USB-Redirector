/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef lllIIIl
#define lllIIIl
#define IllIIIII 		(128UL*1024UL+4096UL) 
#define llIIlIlI 	(1UL*1024UL*1024UL+4096UL) 
#define lIIlllII		(16UL*1024UL*1024UL+8192UL)  
#define lIllIlIl "\x2f\x64\x65\x76"
#define IIllIll "\x74\x75\x73\x62\x64\x5f\x63\x64\x65\x76" 
#define IlIllIIl \
"\x74\x75\x73\x62\x2d\x73\x74\x75\x62\x2d\x64\x72\x69\x76\x65\x72" 
#define llIllIl \
"\x74\x75\x73\x62\x2d\x76\x68\x63\x69\x2d\x64\x72\x69\x76\x65\x72" 
#endif 

