/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IlIIlllIl
#define IlIIlllIl
#include "apitypes.h"
#pragma pack(push,1)
enum{lllllIIl=(0x1466+2906-0x1fc0),
IIlIIIll,
IlIIIIII,
IIIlIIIl,
lllllIlI,
IIlIlllI,
IIIlIIII,
llIIlIII,
IIIIIIll,
lIIlIIll,
lIIllllII,llIIIlll,
IIIlllII,
llIIlIIl,
IlllIIlI,
lIIlIIllIl,
IIIlIllIII,
IIlllIlII,};enum{lIIllllll=(0xbb0+840-0xef8),lIlIllIllI,llIllllll,lIIIIIllI,
IIlIllIII,IlllIIIlll,lIlIIIllll,lIIlllIlI,IlIllIlII,IIIlIIllIl,lIIllIIIlI,
IIlIllIll,lllIllllll,lllIllIIII,IlIIIIIll,lIlllIIIll,lllIIIIII,llIlIIIlll};
#define IIIllI 			(0x613+8158-0x25f0)
#define lIIIIlI 		(0xaf4+5741-0x215f)
#define lIlIIllII          	(0x81c+6171-0x2033)
#define IIlIlllIII 			(0xe8+7196-0x1cfc)
typedef struct{union{struct{IlIIlI IIllll:(0xf50+314-0x105a);
IlIIlI lIIIlll:(0x1272+3308-0x1f4e);};IlIIlI IlIIlIllII;};IIIIl IlIll;
IIIIl IIIIIIl;
IIIIl Status;IIIIl Context;}__attribute__((packed))IlIllI,*IIIIIllIII;
#define IIIIlIllIl	(0x646+7605-0x23fb)
#define lIllllIll		(0xd52+1782-0x1447)
#define IlllIlIlI			(0x327+7671-0x211e)
#define llllllIlI	(0x126a+122-0x12e3)
#define IlIlIlIII	(0x1053+2917-0x1bb6)
#define IllllIIll	(0x76a+4685-0x19b4)
typedef union{struct{IlllIl llIlIIII;};struct{IlllIl IlIlIIlI:
(0x436+8704-0x2635);IlllIl IIlIIIlllI:(0x5b1+22-0x5c6);IlllIl IIIIIIIlI:
(0x35c+125-0x3d8);IlllIl IIllIllIl:(0x630+2365-0xf6c);IlllIl IIllIlIIlI:
(0x1603+2472-0x1faa);IlllIl lllIIIIIl:(0x1821+576-0x1a60);IlllIl IIlIIIIll:
(0x9f7+377-0xb6e);IlllIl IlIlllllI:(0x740+2397-0x109b);IlllIl llIIIIIlll:
(0xa4a+6764-0x24b4);IlllIl IIlllIIll:(0x1c44+815-0x1f71);IlllIl IllllIllI:
(0x5a5+835-0x8e6);};}IlIllIlIl,*IIIIIllIlI;typedef struct{IlIllI IlIIll;lIllIl 
llIIIII;
lIllIl IIIIIllI;
lIllIl lIIlllll;
lIllIl IllIIlll;IlllIl IIllIlIl;IIIIl IIllI;}__attribute__((packed))IIIllIIll,*
lIlIlIIIII;typedef struct{IlIllI IlIIll;lIllIl lllIlIll;lIllIl IIIllIlI;struct{
lIllIl IlllIlI;lIllIl IllIIII;}__attribute__((packed))lIlllll[
(0x8d8+3870-0x17f5)];}__attribute__((packed))IllIIIIlI,*IlIIlIIIII;typedef 
struct{IlIllI IlIIll;lIllIl IlllIlI;lIllIl IllIIII;}__attribute__((packed))
IIIlIIlIl,*IIIlIIIlIl;
#define IlIIlllIlI			(0x7d5+3466-0x155f)
#define IlIIIllIl				(0x588+4661-0x17bc)
#define llIIIIIIl				(0x2178+1290-0x2680)
#define llllIIllI			(0xf6a+3456-0x1ce7)
#define IIllIIlII		(0x611+6165-0x1e26)
#define llIIlIlIl		(0x735+3243-0x13df)
#define lIIIlIIIl		(0x2150+1429-0x26e3)
#define lIIIIIlIl			(0x1493+2919-0x1ff7)
#define lIllIIllII			(0xa77+3120-0x16a6)
#define IIlllIIIll			(0xb4+7300-0x1d38)
typedef struct{IlIllI IlIIll;lIllIl Endpoint;lIllIl Flags;union{struct{lIllIl 
lIllIlIlll:(0x1389+3460-0x2108);lIllIl IllIlllIll:(0x1619+2018-0x1df9);lIllIl 
IIIlIIlllI:(0x211d+1477-0x26e1);}__attribute__((packed))lllllllIll;lIllIl 
llIIIII;}__attribute__((packed));lIllIl lIlllIIIl;IlllIl llIlIIII;IlllIl 
IlllIllIl;IIIIl IIllI;}__attribute__((packed))lIllIIIll,*lIlIlIllII;typedef 
struct{IlIllI IlIIll;IIIIl IIllI;lIllIl Endpoint;lIllIl Flags;}__attribute__((
packed))lllIllIll,*IIIIllIIII;typedef struct{IlIllI IlIIll;IIIIl IIllI;IIIIl 
Interval;lIllIl Endpoint;lIllIl Flags;}__attribute__((packed))lIllIlIll,*
IlIlIlIlll;typedef struct{IlIllI IlIIll;lIllIl Flags;
lIllIl Endpoint;}__attribute__((packed))IlIllllll,*lIllIIllll;typedef struct{
IlIllI IlIIll;IIIIl llIIllIll;}__attribute__((packed))IlIIllIlll,*lllllIIIll;
#define IIIllllI(IlIlI) (sizeof(IlIIIllll) - sizeof(IllllIlI) + \
			sizeof(IllllIlI)*(IlIlI)->llIIl.llIIIIl)
typedef struct{IIIIl Offset;IIIIl Length;IIIIl Status;}__attribute__((packed))
IllllIlI,*IIllIllIlI;typedef struct{IlIllI IlIIll;lIllIl Endpoint;lIllIl Flags;
IIIIl Interval;IIIIl llIIIIIl;IIIIl llIIIIl;IIIIl IIllllIl;IIIIl IIllI;IllllIlI 
llIIIlI[(0xd5a+1795-0x145c)];}__attribute__((packed))IlIIIllll,*IlIllIlIlI;
#define IllllIlIIl(IlIIlIIlI) (sizeof(lllllIIll)-(0x674+939-0xa1e)+(IlIIlIIlI))
#define lIIllIIllI(lIlIlllll) ((lIlIlllll)->lllII.IlIll-(sizeof(lllllIIll)-\
(0x174+5526-0x1709)))
typedef struct{IlIllI IlIIll;lIllIl lIIIIlIllI[(0x16bc+540-0x18d7)];}
__attribute__((packed))lllllIIll,*lllIlIIIll;
#define IlIIlIIll		(0x69c+6913-0x219c)
#define lIlIIllIl		(0xe7d+2910-0x19d9)
typedef struct{IlIllI IlIIll;IIIIl IIllIIlI;}__attribute__((packed))IlllIlIll,*
lIlIIlllll;typedef struct{IlIllI IlIIll;}__attribute__((packed))IIIllllIl,*
lIlllIIllI;typedef struct{IlIllI IlIIll;}__attribute__((packed))IIIlIIIll,*
lIIlIlllII;typedef struct{IlIllI IlIIll;lIllIl Endpoint;lIllIl Flags;}
__attribute__((packed))IIlllllll,*lIlllllIll;
typedef union{IlIllI lllII;IIIllIIll IIlllI;IllIIIIlI IIIllll;IIIlIIlIl llIlllI;
lIllIIIll IIllIl;lllIllIll llIll;lIllIlIll llIIlI;IlIllllll llIIlII;IlIIllIlll 
IllIlIll;IlIIIllll llIIl;lllllIIll llIIIIIIIl;IlllIlIll IIIlllll;IIIllllIl 
IllIIIllI;IIIlIIIll IIIlllIII;IIlllllll lIlIllII;}__attribute__((packed))
llIIllIIlI,*IIlIl;
#pragma pack(pop)
#endif 

