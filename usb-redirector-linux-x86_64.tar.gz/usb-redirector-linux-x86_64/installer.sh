#!/bin/sh
#
# IncentivesPro USB Redirector for Linux installation script
#
# Copyright (c) 2008-2023, SimplyCore LLC
#

# Target directories (can be changed to customize the installation)
INSTALLDIR=/usr/local/usb-redirector  # root dir where the software will be installed
SHELLLINKDIR=/usr/local/bin           # directory to place symbolic links to the software

# Default kernel sources path
KERNELDIR="/lib/modules/$(uname -r)/build"

# How to install kernel sources (or kernel headers).
#
# Debian,Ubuntu: sudo apt-get install make gcc linux-headers-`uname -r`
# RedHat,Fedora,Scientific: yum install make gcc chkconfig kernel-devel-`uname -r`
# Proxmox VE: apt-get install build-essential pve-headers-`uname -r`
# SuSE: sudo zypper in make gcc kernel-devel
# Raspbian: sudo apt-get install make gcc raspberrypi-kernel-headers-`dpkg-query -f='${Version}' --show raspberrypi-kernel`
# Arch,Manjaro: sudo pacman -Syu make gcc linux-headers

# File names
PIDFILE=/var/run/usbsrvd.pid
STUBNAME=tusbd                     # name of the stub driver
DAEMONNAME=usbsrvd                 # name of the daemon executable
SHELLNAME=usbsrv                   # name of the shell executable
CLIENTSHELLNAME=usbclnt            # name of the client shell executable
INITSCRIPTNAME=rc.usbsrvd          # init script name
SYSTEMDUNITNAME=usbsrvd.service    # systemd unit name
UNINSTALLERNAME=uninstall.sh       # uninstaller script name

# System requirements
KERNELMIN='2.6.15'
KERNELMAX='6.5.6'

# Manufacturer
VENDORNAME='IncentivesPro'
PROGNAME='USB Redirector for Linux'
PROGVER='3.11.3'
SUPPORTEMAIL='support@incentivespro.com'

###############################################################################
#
# Helper subroutines

exit_on_file_exist()
{
  if [ -h "$1" ] || [ -f "$1" ] || [ -x "$1" ]; then
    echo "!!!  Previous installation detected. Please uninstall it first ($1)"
    exit 1
  fi
}

exit_on_dir_exist()
{
  if [ -d "$1" ]; then
    echo "!!!  Previous installation detected. Please uninstall it first ($1)"
    exit 1
  fi
}

exit_on_daemon_running()
{
  if [ -n "$(ps -A|grep "$1")" ]; then
    echo "!!!  Previous installation detected. Please uninstall it first ($1 daemon running)"
    exit 1
  fi
}

exit_on_file_not_exist()
{
  if [ ! -f "$1" ] && [ ! -x "$1" ] && [ ! -h "$1" ]; then
    echo "!!!  Required file $1 is missing. Installer cannot continue."
    exit 2
  fi
}

exit_on_error() {
  if [ $? -ne 0 ]; then
    echo "***  Cleaning up installation..."
    usbsrv_cleanup
    echo "***"
    echo "***  Installation failed!"
    echo "??? $1"
    exit 4
  fi
}

exit_with_error() 
{
    echo "***  Cleaning up installation..."
    usbsrv_cleanup
    echo "***"
    echo "***  INSTALLATION FAILED!"
    echo "??? $1"
    exit 4
}

set_tag() 
{
  local file_path="$1"
  local tag="$2"
  local value="$3"
  # Escape '/' with '\/'
  value=$(echo "$value" | sed 's/\//\\\//g')
  # Replace tag "$tag" with "$value" in file $file
  sed "s/$tag/$value/g" "$file_path" > settag.tmp
  mv -f settag.tmp "$file_path"
}

# $1 command name to check
syscall_exists()
{
  command -v "$1" >/dev/null 2>&1
}

###############################################################################
#
# System-depedent subroutines

check_distrib_syscalls()
{
  # RedHat/Fedora/Mandriva
  if [ "$SYS_DISTRIB_NAME" = "redhat" ] || [ "$SYS_DISTRIB_NAME" = "fedora" ] || [ "$SYS_DISTRIB_NAME" = "mandriva" ]; then
    ! syscall_exists "/sbin/chkconfig" && ERROR_MESSAGE="/sbin/chkconfig not found" && return 1
  # Debian/Ubuntu
  elif [ "$SYS_DISTRIB_NAME" = "debian" ] || [ "$SYS_DISTRIB_NAME" = "ubuntu" ]; then
    ! syscall_exists "update-rc.d" && ERROR_MESSAGE="update-rc.d not found" && return 1
  # SuSE
  elif [ "$SYS_DISTRIB_NAME" = "suse" ]; then
    ! syscall_exists "/sbin/insserv" && ERROR_MESSAGE="/sbin/insserv not found" && return 1
  # Gentoo
  elif [ "$SYS_DISTRIB_NAME" = "gentoo" ]; then
    ! syscall_exists "rc-update" && ERROR_MESSAGE="rc-update not found" && return 1
  fi
  return 0
}

detect_kernel()
{
  SYS_KERNEL_RELEASE=$(uname -r)
  SYS_KERNEL_VERSION=$(echo "$SYS_KERNEL_RELEASE"| sed 's/^\([0-9]\+\.[0-9]\+\.[0-9]\+\).*/\1/')

#  [ "$SYS_KERNEL_VERSION" = "$SYS_KERNEL_RELEASE" ] && SYS_KERNEL_VERSION=unknown

  return 0;
}

# digitize the kernel version so that we are able to compare it
parse_kernel_version()
{
  local kernel_min_major="$(echo "$KERNELMIN"| sed 's/^\([0-9]\+\)\..*/\1/')"
  local kernel_min_minor="$(echo "$KERNELMIN"| sed 's/^\([0-9]\+\)\.\([0-9]\+\)\..*/\2/')"
  local kernel_min_patch="$(echo "$KERNELMIN"| sed 's/^\([0-9]\+\)\.\([0-9]\+\)\.\([0-9]\+\).*/\3/')"
  local kernel_min_build="$(echo "$KERNELMIN"| sed 's/^\([0-9]\+\)\.\([0-9]\+\)\.\([0-9]\+\)\.\([0-9]\+\).*/\4/')"
  
  [ "$kernel_min_major" = "$KERNELMIN" ] && return 1
  [ "$kernel_min_minor" = "$KERNELMIN" ] && return 1
  [ "$kernel_min_patch" = "$KERNELMIN" ] && return 1
  [ "$kernel_min_build" = "$KERNELMIN" ] && kernel_min_build=0
  
  local kernel_max_major="$(echo "$KERNELMAX"| sed 's/^\([0-9]\+\)\..*/\1/')"
  local kernel_max_minor="$(echo "$KERNELMAX"| sed 's/^\([0-9]\+\)\.\([0-9]\+\)\..*/\2/')"
  local kernel_max_patch="$(echo "$KERNELMAX"| sed 's/^\([0-9]\+\)\.\([0-9]\+\)\.\([0-9]\+\).*/\3/')"
  local kernel_max_build="$(echo "$KERNELMAX"| sed 's/^\([0-9]\+\)\.\([0-9]\+\)\.\([0-9]\+\)\.\([0-9]\+\).*/\4/')"
  
  [ "$kernel_max_major" = "$KERNELMAX" ] && return 1
  [ "$kernel_max_minor" = "$KERNELMAX" ] && return 1
  [ "$kernel_max_patch" = "$KERNELMAX" ] && return 1
  [ "$kernel_max_build" = "$KERNELMAX" ] && kernel_max_build=0
  
  local kernel_cur_major="$(echo "$SYS_KERNEL_VERSION"| sed 's/^\([0-9]\+\)\..*/\1/')"
  local kernel_cur_minor="$(echo "$SYS_KERNEL_VERSION"| sed 's/^\([0-9]\+\)\.\([0-9]\+\)[\.-].*/\2/')"
  local kernel_cur_patch="$(echo "$SYS_KERNEL_VERSION"| sed 's/^\([0-9]\+\)\.\([0-9]\+\)\.\([0-9]\+\).*/\3/')"
  local kernel_cur_build="$(echo "$SYS_KERNEL_VERSION"| sed 's/^\([0-9]\+\)\.\([0-9]\+\)\.\([0-9]\+\)\.\([0-9]\+\).*/\4/')"

  [ "$kernel_cur_major" = "$SYS_KERNEL_VERSION" ] && return 1
  [ "$kernel_cur_minor" = "$SYS_KERNEL_VERSION" ] && return 1
  [ "$kernel_cur_patch" = "$SYS_KERNEL_VERSION" ] && kernel_cur_patch=0
  [ "$kernel_cur_build" = "$SYS_KERNEL_VERSION" ] && kernel_cur_build=0

  SYS_KERNEL_MIN_D=$(( kernel_min_major * 1000000000 + kernel_min_minor * 1000000 + kernel_min_patch * 1000 + kernel_min_build ))
  SYS_KERNEL_MAX_D=$(( kernel_max_major * 1000000000 + kernel_max_minor * 1000000 + kernel_max_patch * 1000 + kernel_max_build ))
  SYS_KERNEL_CUR_D=$(( kernel_cur_major * 1000000000 + kernel_cur_minor * 1000000 + kernel_cur_patch * 1000 + kernel_cur_build ))

  return 0
}

detect_distrib()
{
  SYS_DISTRIB_NAME='unknown'
  SYS_DISTRIB_MODVER='no'
  SYS_DISTRIB_INIT_TYPE=''
  SYS_DISTRIB_INIT_DIR=''
  SYS_DISTRIB_RUNLEVEL_DIR=''
  SYS_DISTRIB_INIT_RCLOCAL=''

  # Fedora (must be before RedHat)
  if [ -f /etc/fedora-release ]; then
    SYS_DISTRIB_NAME='fedora'
    SYS_DISTRIB_MODVER='no'
    SYS_DISTRIB_INIT_TYPE='sysv'
    SYS_DISTRIB_INIT_DIR='/etc/rc.d/init.d'
    SYS_DISTRIB_RUNLEVEL_DIR='/etc/rc.d'
  # Mandriva (must be before RedHat)
  elif [ -f /etc/mandriva-release ] || [ -f /etc/mandrake-release ] || [ -f /etc/mandrakelinux-release ]; then
    SYS_DISTRIB_NAME='mandriva'
    SYS_DISTRIB_MODVER='yes'
    SYS_DISTRIB_INIT_TYPE='sysv'
    SYS_DISTRIB_INIT_DIR='/etc/rc.d/init.d'
    SYS_DISTRIB_RUNLEVEL_DIR='/etc/rc.d'
  # RedHat/CentOS/Scientific
  elif [ -f /etc/redhat-release ]; then
    SYS_DISTRIB_NAME='redhat'
    SYS_DISTRIB_MODVER='yes'
    SYS_DISTRIB_INIT_TYPE='sysv'
    SYS_DISTRIB_INIT_DIR='/etc/rc.d/init.d'
    SYS_DISTRIB_RUNLEVEL_DIR='/etc/rc.d'
  # Ubuntu (must be before Debian)
  elif [ -f /etc/debian_version ] && [ -f /etc/lsb-release ] && [ -n "$(cat /etc/lsb-release|grep Ubuntu)" ]; then
    SYS_DISTRIB_NAME='ubuntu'
    SYS_DISTRIB_MODVER='yes'
    SYS_DISTRIB_INIT_TYPE='sysv'
    SYS_DISTRIB_INIT_DIR='/etc/init.d'
    SYS_DISTRIB_RUNLEVEL_DIR='/etc'
  # Raspbian (must be before Debian)
  elif [ -f /etc/debian_version ] && [ -f /etc/os-release ] && [ -n "$(cat /etc/os-release|grep Raspbian)" ]; then
    SYS_DISTRIB_NAME='raspbian'
    SYS_DISTRIB_MODVER='yes'
    SYS_DISTRIB_INIT_TYPE='sysv'
    SYS_DISTRIB_INIT_DIR='/etc/init.d'
    SYS_DISTRIB_RUNLEVEL_DIR='/etc'
  # Debian
  elif [ -f /etc/debian_version ]; then
    SYS_DISTRIB_NAME='debian'
    SYS_DISTRIB_MODVER='yes'
    SYS_DISTRIB_INIT_TYPE='sysv'
    SYS_DISTRIB_INIT_DIR='/etc/init.d'
    SYS_DISTRIB_RUNLEVEL_DIR='/etc'
  # SuSE
  elif [ -f /etc/SuSE-release ]; then
    SYS_DISTRIB_NAME='suse'
    SYS_DISTRIB_MODVER='yes'
    SYS_DISTRIB_INIT_TYPE='sysv'
    SYS_DISTRIB_INIT_DIR='/etc/init.d'
    SYS_DISTRIB_RUNLEVEL_DIR='/etc/init.d'
  # Gentoo
  elif [ -f /etc/gentoo-release ]; then
    SYS_DISTRIB_NAME='gentoo'
    SYS_DISTRIB_MODVER='no'
    SYS_DISTRIB_INIT_TYPE='sysv'
    SYS_DISTRIB_INIT_DIR='/etc/init.d'
    SYS_DISTRIB_RUNLEVEL_DIR='/etc/init.d'
  # Slackware
  elif [ -f /etc/slackware-version ]; then
    SYS_DISTRIB_NAME='slackware'
    SYS_DISTRIB_MODVER='no'
    SYS_DISTRIB_INIT_TYPE='sysv'
    SYS_DISTRIB_INIT_DIR='/etc/rc.d'
    SYS_DISTRIB_RUNLEVEL_DIR='/etc/rc.d'
  else
    # Other generic Linuxes
    SYS_DISTRIB_NAME='other'
    SYS_DISTRIB_MODVER='no'
    if [ -d /etc/init.d ]; then
      SYS_DISTRIB_INIT_TYPE='sysv'
      SYS_DISTRIB_INIT_DIR='/etc/init.d'
      SYS_DISTRIB_RUNLEVEL_DIR='/etc'
    elif [ -d /etc/rc.d/init.d ]; then
      SYS_DISTRIB_INIT_TYPE='sysv'
      SYS_DISTRIB_INIT_DIR='/etc/rc.d/init.d'
      SYS_DISTRIB_RUNLEVEL_DIR='/etc/rc.d'
    elif [ -f /etc/rc.local ]; then
      SYS_DISTRIB_INIT_TYPE='bsd'
      SYS_DISTRIB_INIT_RCLOCAL='/etc/rc.local'
    elif [ -f /etc/rc.d/rc.local ]; then
      SYS_DISTRIB_INIT_TYPE='bsd'
      SYS_DISTRIB_INIT_RCLOCAL='/etc/rc.d/rc.local'
    fi
  fi

  if [ -d /run/systemd/system ] && syscall_exists 'systemctl'; then
    # When systemd is present and running, prefer it over other init types
    if [ -d /lib/systemd/system ]; then
      SYS_DISTRIB_INIT_TYPE='systemd'
      SYS_DISTRIB_INIT_DIR='/lib/systemd/system'
    elif [ -d /usr/lib/systemd/system ]; then
      SYS_DISTRIB_INIT_TYPE='systemd'
      SYS_DISTRIB_INIT_DIR='/usr/lib/systemd/system'
    fi
  fi

  [ -z "$SYS_DISTRIB_INIT_TYPE" ] && return 1

  if [ "$SYS_DISTRIB_INIT_TYPE" = "systemd" ]; then
    [ -z "$SYS_DISTRIB_INIT_DIR" ] && return 1
    [ ! -d "$SYS_DISTRIB_INIT_DIR" ] && return 1
  elif [ "$SYS_DISTRIB_INIT_TYPE" = "sysv" ]; then
    [ -z "$SYS_DISTRIB_INIT_DIR" ] && return 1
    [ -z "$SYS_DISTRIB_RUNLEVEL_DIR" ] && return 1
    [ ! -d "$SYS_DISTRIB_INIT_DIR" ] && return 1
    [ ! -d "$SYS_DISTRIB_RUNLEVEL_DIR" ] && return 1
  elif [ "$SYS_DISTRIB_INIT_TYPE" = "bsd" ]; then
    [ -z "$SYS_DISTRIB_INIT_RCLOCAL" ] && return 1
    [ ! -f "$SYS_DISTRIB_INIT_RCLOCAL" ] && return 1
  fi

  return 0
}

detect_dkms()
{
  SYS_DKMS_VERSION=''

  if syscall_exists 'dkms'; then
    SYS_DKMS_VERSION=$(dkms --version 2>/dev/null | sed 's/.*:\s*\(.*\)/\1/g')
  fi

  return 0
}

# $1 source init script file path and name
# $2 destination init script name
# $3 start number (2 symbols)
# $4 stop number (2 symbols)
install_init_script() 
{
  local src_script_path="$1"
  local dst_script_name="$2"

  local dst_script_path

  uninstall_init_script "$2"

  if [ "$SYS_DISTRIB_INIT_TYPE" = "sysv" ]; then
    dst_script_path="$SYS_DISTRIB_INIT_DIR/$dst_script_name"
  elif [ "$SYS_DISTRIB_INIT_TYPE" = "bsd" ]; then
#    dst_script_name="rc.$dst_script_name"
    dst_script_path="/etc/rc.d/$dst_script_name"
  else
    ERROR_MESSAGE="unknown init type"
    return 1
  fi

  cp "$src_script_path" "$dst_script_path"

  if [ ! $? -eq 0 ]; then
    ERROR_MESSAGE="can not copy init script to $dst_script_path"
    return 1
  fi

  chmod 755 "$dst_script_path" 2>/dev/null

  if [ ! $? -eq 0 ]; then
    ERROR_MESSAGE="can not chmod init script $dst_script_path"
    return 1
  fi

  # RedHat/Fedora/Mandriva
  if [ "$SYS_DISTRIB_NAME" = "redhat" ] || [ "$SYS_DISTRIB_NAME" = "fedora" ] || [ "$SYS_DISTRIB_NAME" = "mandriva" ]; then

    /sbin/chkconfig --level 35 "$dst_script_name" on >/dev/null 2>&1 || return 1

  # Debian/Ubuntu
  elif [ "$SYS_DISTRIB_NAME" = "debian" ] || [ "$SYS_DISTRIB_NAME" = "ubuntu" ]; then

    update-rc.d "$dst_script_name" defaults "$3" "$4" >/dev/null 2>&1

  # SuSE
  elif [ "$SYS_DISTRIB_NAME" = "suse" ]; then

    /sbin/insserv "$dst_script_name" >/dev/null 2>&1

  # Gentoo
  elif [ "$SYS_DISTRIB_NAME" = "gentoo" ]; then

    rc-update add "$dst_script_name" default >/dev/null 2>&1

  # BSD
  elif [ "$SYS_DISTRIB_INIT_TYPE" = "bsd" ]; then
    echo "Installer can not correctly set up init script. The script has been copied"
    echo "to $dst_script_path. If you would like the software to start automatically"
    echo "at system boot, please add this script to $SYS_DISTRIB_INIT_RCLOCAL or"
    echo "start it manually"
  # Slackware and others
  elif [ "$SYS_DISTRIB_INIT_TYPE" = "sysv" ]; then
    # Must match with runlevels in uninstall_init_script()
    ln -fs "$dst_script_path" "$SYS_DISTRIB_RUNLEVEL_DIR/rc0.d/K$4$dst_script_name" >/dev/null 2>&1
    ln -fs "$dst_script_path" "$SYS_DISTRIB_RUNLEVEL_DIR/rc1.d/K$4$dst_script_name" >/dev/null 2>&1
    ln -fs "$dst_script_path" "$SYS_DISTRIB_RUNLEVEL_DIR/rc2.d/K$4$dst_script_name" >/dev/null 2>&1
    ln -fs "$dst_script_path" "$SYS_DISTRIB_RUNLEVEL_DIR/rc3.d/S$3$dst_script_name" >/dev/null 2>&1
    ln -fs "$dst_script_path" "$SYS_DISTRIB_RUNLEVEL_DIR/rc4.d/S$3$dst_script_name" >/dev/null 2>&1
    ln -fs "$dst_script_path" "$SYS_DISTRIB_RUNLEVEL_DIR/rc5.d/S$3$dst_script_name" >/dev/null 2>&1
    ln -fs "$dst_script_path" "$SYS_DISTRIB_RUNLEVEL_DIR/rc6.d/K$4$dst_script_name" >/dev/null 2>&1
  fi
  return 0
}

# $1 init script name
# Must match with uninstaller's uninstall_init_script()
uninstall_init_script()
{
  local dst_script_name="$1"
  local dst_script_path

  if [ "$SYS_DISTRIB_INIT_TYPE" = "sysv" ]; then
    dst_script_path="$SYS_DISTRIB_INIT_DIR/$dst_script_name"
  elif [ "$SYS_DISTRIB_INIT_TYPE" = "bsd" ]; then
#    dst_script_name="rc.$dst_script_name"
    dst_script_path="/etc/rc.d/$dst_script_name"
  else
    ERROR_MESSAGE="unknown init type"
    return 1
  fi

  rm -f "$dst_script_path" >/dev/null 2>&1

  # RedHat/Fedora/Mandriva
  if [ "$SYS_DISTRIB_NAME" = "redhat" ] || [ "$SYS_DISTRIB_NAME" = "fedora" ] || [ "$SYS_DISTRIB_NAME" = "mandriva" ]; then
 
    /sbin/chkconfig --del "$dst_script_name" >/dev/null 2>&1

  # Debian/Ubuntu
  elif [ "$SYS_DISTRIB_NAME" = "debian" ] || [ "$SYS_DISTRIB_NAME" = "ubuntu" ]; then

    update-rc.d -f "$dst_script_name" remove >/dev/null 2>&1

  # SuSE
  elif [ "$SYS_DISTRIB_NAME" = "suse" ]; then

    /sbin/insserv -r "$dst_script_name" >/dev/null 2>&1

  # Gentoo
  elif [ "$SYS_DISTRIB_NAME" = "gentoo" ]; then

    rc-update del "$dst_script_name" >/dev/null 2>&1

  # bsd
  elif [ "$SYS_DISTRIB_INIT_TYPE" = "bsd" ]; then
    # nothing to do
    echo "" >/dev/null
  # Slackware and others
  elif [ "$SYS_DISTRIB_INIT_TYPE" = "sysv" ]; then
    # Must match with runlevels in add_runlevels()
    rm "$SYS_DISTRIB_RUNLEVEL_DIR/rc0.d/K??$dst_script_name" >/dev/null 2>&1
    rm "$SYS_DISTRIB_RUNLEVEL_DIR/rc1.d/K??$dst_script_name" >/dev/null 2>&1
    rm "$SYS_DISTRIB_RUNLEVEL_DIR/rc2.d/K??$dst_script_name" >/dev/null 2>&1
    rm "$SYS_DISTRIB_RUNLEVEL_DIR/rc3.d/S??$dst_script_name" >/dev/null 2>&1
    rm "$SYS_DISTRIB_RUNLEVEL_DIR/rc4.d/S??$dst_script_name" >/dev/null 2>&1
    rm "$SYS_DISTRIB_RUNLEVEL_DIR/rc5.d/S??$dst_script_name" >/dev/null 2>&1
    rm "$SYS_DISTRIB_RUNLEVEL_DIR/rc6.d/K??$dst_script_name" >/dev/null 2>&1
  fi

  return 0
}

# $1 init script name
start_init_script()
{
  local name="$1"

  if [ "$SYS_DISTRIB_INIT_TYPE" = "sysv" ]; then
    "$SYS_DISTRIB_INIT_DIR/$name" start >/dev/null 2>&1
  elif [ "$SYS_DISTRIB_INIT_TYPE" = "bsd" ]; then
#    if [ -x "/etc/rc.d/rc.$name" ]; then
#      "/etc/rc.d/rc.$name" start >/dev/null 2>&1
#    fi
    if [ -x "/etc/rc.d/$name" ]; then
      "/etc/rc.d/$name" start >/dev/null 2>&1
    fi
  else
    ERROR_MESSAGE="unknown init type"
    return 1
  fi
  return 0
}

# $1 init script name
# Must match with uninstaller's stop_init_script()
stop_init_script() 
{
  local name="$1"

  if [ "$SYS_DISTRIB_INIT_TYPE" = "sysv" ]; then
    if [ -x "$SYS_DISTRIB_INIT_DIR/$name" ]; then
      "$SYS_DISTRIB_INIT_DIR/$name" stop >/dev/null 2>&1
    fi
  elif [ "$SYS_DISTRIB_INIT_TYPE" = "bsd" ]; then
#    if [ -x "/etc/rc.d/rc.$name" ]; then
#      "/etc/rc.d/rc.$name" stop >/dev/null 2>&1
#    fi
    if [ -x "/etc/rc.d/$name" ]; then
      "/etc/rc.d/$name" stop >/dev/null 2>&1
    fi
  else
    ERROR_MESSAGE="unknown init type"
    return 1
  fi
  return 0
}

# $1 source unit file path and name
# $2 destination unit name
install_systemd_unit() 
{
  local src_unit_path="$1"
  local dst_unit_name="$2"
  local dst_unit_path

  if [ "$SYS_DISTRIB_INIT_TYPE" = "systemd" ]; then
    dst_unit_path="$SYS_DISTRIB_INIT_DIR/$dst_unit_name"
  else
    ERROR_MESSAGE="unknown init type"
    return 1
  fi

  cp "$src_unit_path" "$dst_unit_path" 2>/dev/null

  if [ ! $? -eq 0 ]; then
    ERROR_MESSAGE="can not copy systemd unit file to $dst_unit_path"
    return 1
  fi

  chmod 644 "$dst_unit_path" 2>/dev/null

  if [ ! $? -eq 0 ]; then
    ERROR_MESSAGE="can not chmod systemd unit file $dst_unit_path"
    return 1
  fi

#  systemctl daemon-reload >/dev/null 2>&1
  systemctl enable "$dst_unit_name" >/dev/null 2>&1

  return 0
}

# $1 unit name
# Must match with uninstaller's uninstall_systemd_unit()
uninstall_systemd_unit() 
{
  local dst_unit_name="$1"
  local dst_unit_path

  if [ "$SYS_DISTRIB_INIT_TYPE" = "systemd" ]; then
    dst_unit_path="$SYS_DISTRIB_INIT_DIR/$dst_unit_name"
  else
    ERROR_MESSAGE="unknown init type"
    return 1
  fi

#  systemctl stop "$dst_unit_name" >/dev/null 2>&1
  systemctl disable "$dst_unit_name" >/dev/null 2>&1

  rm -f "/etc/systemd/system/$dst_unit_name" >/dev/null 2>&1
  rm -f "/usr/lib/systemd/system/$dst_unit_name" >/dev/null 2>&1
  rm -f "/lib/systemd/system/$dst_unit_name" >/dev/null 2>&1
  rm -f "$dst_unit_path" >/dev/null 2>&1

#  systemctl daemon-reload >/dev/null 2>&1

  return 0
}


# $1 unit name
start_systemd_unit()
{
  local name="$1"

  if [ "$SYS_DISTRIB_INIT_TYPE" = "systemd" ]; then

    systemctl start "$name"

  else
    ERROR_MESSAGE="unknown init type"
    return 1
  fi
  return 0
}

# $1 unit name
# Must match with uninstaller's stop_systemd_unit()
stop_systemd_unit() 
{
  local name="$1"

  if [ "$SYS_DISTRIB_INIT_TYPE" = "systemd" ]; then
    systemctl stop "$name"
  else
    ERROR_MESSAGE="unknown init type"
    return 1
  fi
  return 0
}

###############################################################################
#
# Installer subroutines

usbsrv_check_syscalls()
{
  ! syscall_exists 'sed' && ERROR_MESSAGE="'sed' not found" && return 1
  ! syscall_exists 'grep' && ERROR_MESSAGE="'grep' not found" && return 1
  ! syscall_exists 'chmod' && ERROR_MESSAGE="'chmod' not found" && return 1
  ! syscall_exists 'ln' && ERROR_MESSAGE="'ln' not found" && return 1
  ! syscall_exists '/sbin/insmod' && ERROR_MESSAGE="'insmod' not found" && return 1
  ! syscall_exists '/sbin/rmmod' && ERROR_MESSAGE="'rmmod' not found" && return 1
  ! syscall_exists 'gcc' && ERROR_MESSAGE="'gcc' not found, please install and try again" && return 1
  ! syscall_exists 'make' && ERROR_MESSAGE="'make' not found, please install and try again" && return 1
  ! syscall_exists 'mktemp' && ERROR_MESSAGE="'mktemp' not found, please install and try again" && return 1
  return 0
}

usbsrv_prepare_uninstaller()
{
  local tmpfile="$INSTALLDIR/$UNINSTALLERNAME.tmp"

  cp "./files/$UNINSTALLERNAME" "$tmpfile"

  set_tag "$tmpfile" '%VENDORNAME_TAG%'        "$VENDORNAME"      || return 1
  set_tag "$tmpfile" '%PROGNAME_TAG%'          "$PROGNAME"        || return 1
  set_tag "$tmpfile" '%PROGVER_TAG%'           "$PROGVER"         || return 1
  set_tag "$tmpfile" '%INSTALLDIR_TAG%'        "$INSTALLDIR"      || return 1
  set_tag "$tmpfile" '%SHELLLINKDIR_TAG%'      "$SHELLLINKDIR"	  || return 1
  set_tag "$tmpfile" '%STUBNAME_TAG%'          "$STUBNAME"        || return 1
  set_tag "$tmpfile" '%DAEMONNAME_TAG%'        "$DAEMONNAME"      || return 1
  set_tag "$tmpfile" '%SHELLNAME_TAG%'         "$SHELLNAME"       || return 1
  set_tag "$tmpfile" '%CLIENTSHELLNAME_TAG%'   "$CLIENTSHELLNAME" || return 1
  set_tag "$tmpfile" '%UNINSTALLERNAME_TAG%'   "$UNINSTALLERNAME" || return 1
  set_tag "$tmpfile" '%INITSCRIPTNAME_TAG%'    "$INITSCRIPTNAME"  || return 1
  set_tag "$tmpfile" '%SYSTEMDUNITNAME_TAG%'   "$SYSTEMDUNITNAME" || return 1
  set_tag "$tmpfile" '%SYS_DISTRIB_NAME_TAG%'          "$SYS_DISTRIB_NAME"         || return 1
  set_tag "$tmpfile" '%SYS_DISTRIB_MODVER_TAG%'        "$SYS_DISTRIB_MODVER"       || return 1
  set_tag "$tmpfile" '%SYS_DISTRIB_INIT_TYPE%'         "$SYS_DISTRIB_INIT_TYPE"    || return 1
  set_tag "$tmpfile" '%SYS_DISTRIB_INIT_DIR%'          "$SYS_DISTRIB_INIT_DIR"     || return 1
  set_tag "$tmpfile" '%SYS_DISTRIB_RUNLEVEL_DIR_TAG%'  "$SYS_DISTRIB_RUNLEVEL_DIR" || return 1
  set_tag "$tmpfile" '%SYS_DISTRIB_INIT_RCLOCAL_TAG%'  "$SYS_DISTRIB_INIT_RCLOCAL" || return 1
  set_tag "$tmpfile" '%SYS_KERNEL_RELEASE_TAG%'        "$SYS_KERNEL_RELEASE" || return 1
  set_tag "$tmpfile" '%SYS_KERNEL_VERSION_TAG%'        "$SYS_KERNEL_VERSION" || return 1
  return 0
}

usbsrv_prepare_init_script() 
{
  local tmpfile="$INSTALLDIR/$INITSCRIPTNAME.tmp"

  cp "./files/$INITSCRIPTNAME" "$tmpfile"

  set_tag "$tmpfile" '%VENDORNAME_TAG%' "$VENDORNAME" || return 1
  set_tag "$tmpfile" '%PROGNAME_TAG%'   "$PROGNAME"   || return 1
  set_tag "$tmpfile" '%PROGVER_TAG%'    "$PROGVER"    || return 1
  set_tag "$tmpfile" '%INSTALLDIR_TAG%' "$INSTALLDIR" || return 1
  set_tag "$tmpfile" '%PIDFILE_TAG%'    "$PIDFILE"    || return 1
  set_tag "$tmpfile" '%STUBNAME_TAG%'   "$STUBNAME"   || return 1
  set_tag "$tmpfile" '%DAEMONNAME_TAG%' "$DAEMONNAME" || return 1
  set_tag "$tmpfile" '%INITSCRIPTNAME_TAG%'    "$INITSCRIPTNAME"  || return 1
  return 0
}

usbsrv_prepare_systemd_unit() 
{
  local tmpfile="$INSTALLDIR/$SYSTEMDUNITNAME.tmp"

  cp "./files/$SYSTEMDUNITNAME" "$tmpfile"

  set_tag "$tmpfile" '%VENDORNAME_TAG%' "$VENDORNAME" || return 1
  set_tag "$tmpfile" '%PROGNAME_TAG%'   "$PROGNAME"   || return 1
  set_tag "$tmpfile" '%PROGVER_TAG%'    "$PROGVER"    || return 1
  set_tag "$tmpfile" '%INSTALLDIR_TAG%' "$INSTALLDIR" || return 1
  set_tag "$tmpfile" '%PIDFILE_TAG%'    "$PIDFILE"    || return 1
  set_tag "$tmpfile" '%STUBNAME_TAG%'   "$STUBNAME"   || return 1
  set_tag "$tmpfile" '%DAEMONNAME_TAG%' "$DAEMONNAME" || return 1
  return 0
}

usbsrv_check_previous_old_installation() 
{
 #exit_on_daemon_running "usbsrvd"
  exit_on_file_exist '/usr/local/usb-server/usbsrvd'
  exit_on_file_exist '/usr/local/usb-server/bin/tusbd.ko'
  exit_on_file_exist '/usr/local/usb-server/bin/usbsrv'
  exit_on_file_exist '/usr/local/usb-server/bin/usbclnt'
}

usbsrv_check_previous_installation() 
{
  #exit_on_daemon_running "$DAEMONNAME"
  exit_on_file_exist "$INSTALLDIR/bin/$DAEMONNAME"
  exit_on_file_exist "$INSTALLDIR/bin/$STUBNAME.ko"
  exit_on_file_exist "$INSTALLDIR/bin/$SHELLNAME"
  exit_on_file_exist "$INSTALLDIR/bin/$CLIENTSHELLNAME"
  exit_on_file_exist "$INSTALLDIR/$UNINSTALLERNAME"
  exit_on_file_exist "$SHELLLINKDIR/$SHELLNAME"
  exit_on_dir_exist  "/usr/src/$STUBNAME-$PROGVER"
}

usbsrv_check_source_files() 
{
  exit_on_file_not_exist "./files/$UNINSTALLERNAME"
  exit_on_file_not_exist "./files/$INITSCRIPTNAME"
  exit_on_file_not_exist "./files/$SYSTEMDUNITNAME"

  if [ "$1" = 'both' ]; then
    exit_on_file_not_exist "./files/$SHELLNAME"
    exit_on_file_not_exist "./files/$CLIENTSHELLNAME"
    exit_on_file_not_exist "./files/$DAEMONNAME"
  elif [ "$1" = 'server' ]; then
    exit_on_file_not_exist "./files/$SHELLNAME"
    exit_on_file_not_exist "./files/$DAEMONNAME-srv"
  else
    exit_on_file_not_exist "./files/$CLIENTSHELLNAME"
    exit_on_file_not_exist "./files/$DAEMONNAME-cl"
  fi
}

usbsrv_copy_files()
{
  if [ "$1" = 'both' ]; then
    cp "./files/$DAEMONNAME" "$INSTALLDIR/bin"
    exit_on_error "Cannot copy file $DAEMONNAME"
    cp "./files/$SHELLNAME" "$INSTALLDIR/bin"
    exit_on_error "Cannot copy file $SHELLNAME"
    cp "./files/$CLIENTSHELLNAME" "$INSTALLDIR/bin"
    exit_on_error "Cannot copy file $CLIENTSHELLNAME"
  elif [ "$1" = 'server' ]; then
    cp "./files/$DAEMONNAME-srv" "$INSTALLDIR/bin/$DAEMONNAME"
    exit_on_error "Cannot copy file $DAEMONNAME-srv"
    cp "./files/$SHELLNAME" "$INSTALLDIR/bin"
    exit_on_error "Cannot copy file $SHELLNAME"
  else
    cp "./files/$DAEMONNAME-cl" "$INSTALLDIR/bin/$DAEMONNAME"
    exit_on_error "Cannot copy file $DAEMONNAME-cl"
    cp "./files/$CLIENTSHELLNAME" "$INSTALLDIR/bin"
    exit_on_error "Cannot copy file $CLIENTSHELLNAME"
  fi

  if [ -n "$SYS_DKMS_VERSION" ]; then
    dkms install $STUBNAME/$PROGVER >>buildlog.txt 2>&1
    exit_on_error "Cannot install kernel module with dkms"
  else
    cp "$SYS_KERNEL_MODULE_FILE" "$INSTALLDIR/bin/$STUBNAME.ko"
    exit_on_error "Cannot copy file $SYS_KERNEL_MODULE_FILE"
  fi
  cp "$INSTALLDIR/$UNINSTALLERNAME.tmp" "$INSTALLDIR/$UNINSTALLERNAME"
  exit_on_error "Cannot copy file $UNINSTALLERNAME"
}

usbsrv_configure_kernel_module() 
{
  # Create temporary directory
  TMP_DIR=$(mktemp -q -d)
  if [ -z "$TMP_DIR" ] || [ ! -d "$TMP_DIR" ]; then
    exit_with_error "Cannot create temporary directory"
  fi

  # Copy kernel module source into temporary directory
  cp -R "./files/modules/src" "$TMP_DIR"
  exit_on_error "Cannot copy temporary files"

  if [ "$1" = 'both' ] || [ "$1" = 'server' ]; then
    # kernels 2.6.25-2.6.27.20 and 2.6.28-2.6.28.8 have a memory leak in ISO transfers on EHCI controllers
    # try to workaround

    if [ $SYS_KERNEL_CUR_D -ge 2006025000 ] && [ $SYS_KERNEL_CUR_D -le 2006027020 ] || \
       [ $SYS_KERNEL_CUR_D -ge 2006028000 ] && [ $SYS_KERNEL_CUR_D -le 2006028008 ]; then
      echo "!!!  Warning! Your kernel version has a bug with EHCI USB controllers which"
      echo "     leads to large memory leaks with isochronous devices like Webcams or"
      echo "     Sound cards."
      echo "     If you have patched your kernel against this bug - please manually"
      echo "     recompile the driver using 'make USE_EHCI_FIX=n' command. Otherwise"
      echo "     the installer will try to automatically walk around this bug (without"
      echo "     guaranties)."
      echo "     Affected kernels are 2.6.25-2.6.27.20 and 2.6.28-2.6.28.8."
      echo "     See http://patchwork.kernel.org/patch/13428/ for more information."
      echo "     P.S. You should not worry about this warning if you're not going to"
      echo "          use USB 2.0 isochronous devices on your system."

      set_tag "$TMP_DIR/src/$STUBNAME/Makefile" 'USE_EHCI_FIX ?= .*' 'USE_EHCI_FIX ?= y'
    else
      set_tag "$TMP_DIR/src/$STUBNAME/Makefile" 'USE_EHCI_FIX ?= .*' 'USE_EHCI_FIX ?= n'
    fi
  fi
   
  if [ "$1" = 'both' ]; then
    set_tag "$TMP_DIR/src/$STUBNAME/Makefile" 'STUB ?= .*' 'STUB ?= y'
    set_tag "$TMP_DIR/src/$STUBNAME/Makefile" 'VHCI ?= .*' 'VHCI ?= y'
  elif [ "$1" = 'server' ]; then
    set_tag "$TMP_DIR/src/$STUBNAME/Makefile" 'STUB ?= .*' 'STUB ?= y'
    set_tag "$TMP_DIR/src/$STUBNAME/Makefile" 'VHCI ?= .*' 'VHCI ?= n'
  else
    set_tag "$TMP_DIR/src/$STUBNAME/Makefile" 'STUB ?= .*' 'STUB ?= n'
    set_tag "$TMP_DIR/src/$STUBNAME/Makefile" 'VHCI ?= .*' 'VHCI ?= y'
  fi

  return 0
}

usbsrv_compile_kernel_module() 
{
  if [ -n "$SYS_DKMS_VERSION" ]; then
    echo "***  Compiling kernel module with dkms..."

    # build kernel module with dkms
    dkms build "$TMP_DIR/src" >buildlog.txt 2>&1

    if [ $? -eq 0 ]; then
      echo "***  Kernel module successfully compiled"
      # Store module location
      SYS_KERNEL_MODULE_FILE=''
    else
      cat /var/lib/dkms/$STUBNAME/$PROGVER/build/make.log >>buildlog.txt 2>&1
      return 5
    fi
  else
    echo "***  Compiling kernel module..."
 
	# clean sources before compiling 
    make -C "$TMP_DIR/src/$STUBNAME" "KERNELDIR=$KERNELDIR" clean >/dev/null 2>&1

    # make kernel module
    make -C "$TMP_DIR/src/$STUBNAME" "KERNELDIR=$KERNELDIR" >buildlog.txt 2>&1
 
    if [ $? -eq 0 ]; then
      echo "***  Kernel module successfully compiled"
      # Store module location
      SYS_KERNEL_MODULE_FILE="$TMP_DIR/src/$STUBNAME/$STUBNAME.ko"
    else
      return 5
    fi
  fi
  return 0
}

usbsrv_set_permissions()
{
  # Set permissions on copied files
  chmod 744 "$INSTALLDIR/bin/$DAEMONNAME"
  exit_on_error "Cannot chmod the daemon"
  chmod 755 "$INSTALLDIR/$UNINSTALLERNAME"
  exit_on_error "Cannot chmod the uninstaller script"

  if [ -f "$INSTALLDIR/bin/$STUBNAME.ko" ]; then
    chmod 644 "$INSTALLDIR/bin/$STUBNAME.ko"
    exit_on_error "Cannot chmod the kernel module"
    # Set SELinux labels
    syscall_exists 'chcon' && chcon -u system_u -t modules_object_t "$INSTALLDIR/bin/$STUBNAME.ko" >/dev/null 2>&1
  fi

  if [ "$1" = 'both' ] || [ "$1" = 'server' ]; then
    chmod 755 "$INSTALLDIR/bin/$SHELLNAME"
    exit_on_error "Cannot chmod the server shell"
  fi

  if [ "$1" = 'both' ] || [ "$1" = 'client' ]; then
    chmod 755 "$INSTALLDIR/bin/$CLIENTSHELLNAME"
    exit_on_error "Cannot chmod the client shell"
  fi

  if [ "$1" = 'both' ] || [ "$1" = 'server' ]; then
    ln -fs "$INSTALLDIR/bin/$SHELLNAME" "$SHELLLINKDIR/$SHELLNAME"
    exit_on_error "Cannot create link $SHELLLINKDIR/$SHELLNAME"
  fi

  if [ "$1" = 'both' ] || [ "$1" = 'client' ]; then
    ln -fs "$INSTALLDIR/bin/$CLIENTSHELLNAME" "$SHELLLINKDIR/$CLIENTSHELLNAME"
    exit_on_error "Cannot create link $SHELLLINKDIR/$CLIENTSHELLNAME"
  fi
}

usbsrv_install_daemon()
{
  if [ "$SYS_DISTRIB_INIT_TYPE" = "systemd" ]; then
    install_systemd_unit "$INSTALLDIR/$SYSTEMDUNITNAME.tmp" $SYSTEMDUNITNAME
  else
    install_init_script "$INSTALLDIR/$INITSCRIPTNAME.tmp" $INITSCRIPTNAME 99 01
  fi
}

usbsrv_start_daemon()
{
  if [ "$SYS_DISTRIB_INIT_TYPE" = "systemd" ]; then
    start_systemd_unit $SYSTEMDUNITNAME
  else
    start_init_script $INITSCRIPTNAME
  fi
}

###############################################################################
#
# Actual installer subroutine

usbsrv_install()
{
  echo " "
  echo "*** Installing $PROGNAME v$PROGVER"
  echo "***  Destination dir: $INSTALLDIR"

  echo "***  Checking installation..."

  # Make sure we have all required syscalls
  usbsrv_check_syscalls
  exit_on_error "Syscalls check failed: $ERROR_MESSAGE"

  # Make sure no components from old version are installed
  usbsrv_check_previous_old_installation

  # Make sure no components from previous installation are installed
  usbsrv_check_previous_installation
 
  # Make sure we have all required files in the current dir
  usbsrv_check_source_files "$1"

  echo "***  Detecting system..."

  # Try to detect current distribution name
  detect_distrib
  exit_on_error "Can not detect Linux distribution, possibly it is not supported."

  echo "***     distribution: $SYS_DISTRIB_NAME"
  echo "***     init: $SYS_DISTRIB_INIT_TYPE"

  check_distrib_syscalls
  exit_on_error "Syscalls check failed: $ERROR_MESSAGE"

  # Try to detect kernel version
  detect_kernel
  exit_on_error "Can not detect kernel version"

  echo "***     kernel: $SYS_KERNEL_RELEASE"

  parse_kernel_version
  exit_on_error "Can not parse kernel version."

  if [ $SYS_KERNEL_CUR_D -lt $SYS_KERNEL_MIN_D ] || [ $SYS_KERNEL_CUR_D -gt $SYS_KERNEL_MAX_D ]; then
    answer=''
    while [ "$answer" = '' ];
    do
      printf "!!! Your kernel version is not officially suppported! If you continue installing,\n    system stability may be affected or the program may fail to work correctly.\n>>> Would like to try installing anyway? [y/N] "
      read answer
      case "$answer" in
        'y' | 'Y') answer='y';;
        'n' | 'N') answer='n';;
        '') answer='n';;
         *) answer='';;
      esac
    done
    if [ "$answer" = 'n' ]; then
      exit_with_error "Sorry, your kernel version is not supported yet. Please contact us via $SUPPORTEMAIL for update."
    else
      echo "You're doing it at your own risk! %)"
    fi
  fi

  # Make sure kernel headers are present
  if [ ! -d "$KERNELDIR" ]; then
    exit_with_error "Kernel sources or kernel headers not found. Please install the corresponding package first."
  fi

  # Check if dkms installed and determine its version
  detect_dkms

  if [ -n "$SYS_DKMS_VERSION" ]; then
    echo "***     dkms: $SYS_DKMS_VERSION"
  else
    echo "***     dkms: not installed"
    answer=''
    while [ "$answer" = '' ];
    do
      printf "!!! Your system does not have DKMS installed. DKMS helps to recompile kernel modules\n    automatically after kernel updates. Without it, you would have to re-install\n    $PROGNAME manually each time the kernel is updated.\n>>> Would you like to continue without DKMS? [y/N] "
      read answer
      case "$answer" in
        'y' | 'Y') answer='y';;
        'n' | 'N') answer='n';;
        '') answer='n';;
         *) answer='';;
      esac
    done
    if [ "$answer" = 'n' ]; then
      exit_with_error "Please install DKMS package and try again."
    fi
  fi

  # Build kernel module from sources

  echo "***  Configuring kernel module..."

  usbsrv_configure_kernel_module "$1"
  exit_on_error "Cannot configure kernel module. Installation terminated. See buildlog.txt file for more information."

  usbsrv_compile_kernel_module "$1"
  exit_on_error "Cannot compile kernel module. Installation terminated. See buildlog.txt file for more information."

  echo "***  Creating directories..."

  # Create program directory
  mkdir -p "$INSTALLDIR/bin"
  exit_on_error "Cannot create directory $INSTALLDIR/bin"

  echo "***  Preparing scripts..."

  # Prepare uninstaller
  usbsrv_prepare_uninstaller
  exit_on_error "Can not prepare uninstaller script"

  # Prepare init script
  usbsrv_prepare_init_script
  exit_on_error "Can not prepare init script"

  # Prepare systemd unit
  usbsrv_prepare_systemd_unit
  exit_on_error "Can not prepare systemd unit"

  echo "***  Copying files..."
  
  usbsrv_copy_files "$1"
  usbsrv_set_permissions "$1"

  echo "***  Installing daemon..."

  usbsrv_install_daemon
  exit_on_error "Can not install daemon: $ERROR_MESSAGE"

  echo "***  Starting daemon..."

  usbsrv_start_daemon
  exit_on_error "Can not start daemon: $ERROR_MESSAGE"

  # Remove temporary files
  rm -f "$INSTALLDIR/$INITSCRIPTNAME.tmp"
  rm -f "$INSTALLDIR/$UNINSTALLERNAME.tmp"
  rm -f "$INSTALLDIR/$SYSTEMDUNITNAME.tmp"

  # Remove temporary directory
  if [ -n "$TMP_DIR" ] && [ -d "$TMP_DIR" ] && [ "$TMP_DIR" != '/' ]; then
    rm -Rf "$TMP_DIR"
  fi

  if [ "$1" = 'both' ] || [ "$1" = 'server' ]; then
    echo "***  Please allow incoming connections on 32032 port for the USB server to be able to accept connections from remote clients."
  fi

  echo "***  INSTALLATION SUCCESSFUL! To uninstall, run $INSTALLDIR/$UNINSTALLERNAME"
}

usbsrv_cleanup()
{
  # Remove init script
  stop_init_script "$INITSCRIPTNAME"
  uninstall_init_script "$INITSCRIPTNAME"

  # remove kernel module from dkms
  dkms remove $STUBNAME/$PROGVER --all >/dev/null 2>&1 && [ -d /usr/src/$STUBNAME-$PROGVER ] && rm -Rf "/usr/src/$STUBNAME-$PROGVER"

  # Remove program files and symbolic links
  rm -f "$INSTALLDIR/bin/$DAEMONNAME"
  rm -f "$INSTALLDIR/bin/$STUBNAME.ko"
  rm -f "$INSTALLDIR/bin/$SHELLNAME"
  rm -f "$INSTALLDIR/bin/$CLIENTSHELLNAME"
  rm -f "$INSTALLDIR/$UNINSTALLERNAME"

  # Check if this is a symbolic link.
  if [ -h "$SHELLLINKDIR/$SHELLNAME" ]; then 
    rm -f "$SHELLLINKDIR/$SHELLNAME "
  fi

  # Check if this is a symbolic link.
  if [ -h "$SHELLLINKDIR/$CLIENTSHELLNAME" ]; then 
    rm -f "$SHELLLINKDIR/$CLIENTSHELLNAME" 
  fi

  # Remove temporary files
  rm -f "$INSTALLDIR/$INITSCRIPTNAME.tmp"
  rm -f "$INSTALLDIR/$UNINSTALLERNAME.tmp"
  rm -f "$INSTALLDIR/$SYSTEMDUNITNAME.tmp"

  # Remove temporary directory
  if [ -n "$TMP_DIR" ] && [ -d "$TMP_DIR" ] && [ "$TMP_DIR" != '/' ]; then
    rm -Rf "$TMP_DIR"
  fi

  # Remove program directories  
  rmdir "$INSTALLDIR/bin" 2> /dev/null
  rmdir "$INSTALLDIR" 2> /dev/null
}


###############################################################################
#
# Script entry point

if [ "$(whoami)" != 'root' ]; then
  echo "$VENDORNAME $PROGNAME v$PROGVER installation script"
  echo "This script is intended to be run under root account!"
  exit 255
fi

case "$1" in
  'install')
    usbsrv_install both
    ;;
  'install-client')
    usbsrv_install client
    ;;
  'install-server')
    usbsrv_install server
    ;;
  *)
    echo "$VENDORNAME $PROGNAME v$PROGVER installation script"
    echo ""
    echo "Usage: installer.sh install           - install both client and server"
    echo "       installer.sh install-server    - install server only"
    echo "       installer.sh install-client    - install client only"
esac


